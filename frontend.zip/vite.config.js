import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import svgr from 'vite-plugin-svgr';

export default defineConfig({
  plugins: [
    react(),
    // for importing svg but not working so i am using this
    // import Search from "../../assets/img/search.svg?react";
    svgr({
      svgrOptions: {
        icon: true,
        svgo: true,
      },
    }),
  ],
});