// tailwind.config.js
module.exports = {
    content: [
        './index.html',
        './src/**/*.{js,ts,jsx,tsx}',
    ],
    darkMode: 'class', // Enable class-based dark mode
    theme: {
        extend: {
            colors: {
                dark: {
                    900: '#121212',
                },
            },
        },
    },
    plugins: [],
};