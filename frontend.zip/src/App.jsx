import "./App.scss";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  Outlet,
} from "react-router-dom";
import Login from "./pages/Public/auth/Login";
import Register from "./pages/Public/auth/Register";
import Reset from "./pages/Public/auth/Reset";
import RegainAccess from "./pages/Public/auth/RegainAccess";
import Main from "./pages/Main";
import ViewJob from "./pages/job/ViewJob";
import MyJobs from "./pages/myJobs/Main";
import Home from "./pages/Home/Main";
import MainLayout from "./pages/MainLayout";
import { useEffect, useState } from "react";
import LoadingBar from "react-top-loading-bar";
function RedirectByProfile() {
  const token = localStorage.getItem("ai-token");
  const userStr = localStorage.getItem("ai-user");
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  let profileType = null;
  if (userStr) {
    try {
      const user = JSON.parse(userStr);
      profileType = user.profile_type;
    } catch (e) {
      return <Navigate to="/login" replace />;
    }
  } else {
    return <Navigate to="/login" replace />;
  }
  if (profileType === "user") {
    return <Navigate to="/home" replace />;
  } else if (profileType === "company" || profileType === "hr") {
    return <Navigate to="/company/dashboard" replace />;
  } else {
    return <Navigate to="/login" replace />;
  }
}

import ProtectedRoute from "./pages/ProtectedRoute";
import PublicRoute from "./pages/PublicRoute";
import Landing from "./pages/Public/landing/Landing";
import LandingViewJob from "./pages/Public/landing/ViewJob";
import LandingMyJob from "./pages/Public/landing/MyJob";
import Profile from "./pages/Private/Profile/ProrfileMain";
import LandingHome from "./pages/Public/landing/Home/Home";
import ReportPage from "./pages/Public/landing/Report";
import CompanyLayout from "./pages/CompanyLayout";
import Dashboard from "./pages/company/Dashboard";
import JobsCompany from "./pages/company/Jobs";
import Applications from "./pages/company/Applications";
import Interviews from "./pages/company/Interviews";
import Recruiters from "./pages/company/Recruiters";
import JobDetailForm from "./pages/company/JobDetailForm";
import SingleJobView from "./pages/company/SingleJobView";
import ChangePassword from "./pages/company/ChangePassword";
import CompanyProfile from "./pages/company/Profile/Profile.jsx";

function App() {
  const [progress, setProgress] = useState(0);
  const token = localStorage.getItem("ai-token");
  const [landing, setLanding] = useState(false);

  useEffect(() => {
    if (!token) {
      setLanding(true);
    }
  }, [token]);

  return (
    <>
      <LoadingBar
        color="#FC6935"
        progress={progress}
        onLoaderFinished={() => setProgress(0)}
        height="4px"
      />
      <Router>
        <Routes>
          <Route
            path="/home"
            element={
              <MainLayout
                setProgress={setProgress}
                landing={landing}
                progress={progress}
              >
                {token ? <Outlet /> : <Navigate to="/home" />}
              </MainLayout>
            }
          >
            <Route
              index
              element={
                <LandingHome setProgress={setProgress} landing={landing} />
              }
            />
            <Route
              path="view-job"
              element={<Landing setProgress={setProgress} landing={landing} />}
            />
            <Route
              path="view-job/:id"
              element={
                <LandingViewJob setProgress={setProgress} progress={progress} landing={landing} />
              }
            />
            <Route
              path="my-job"
              element={
                <LandingMyJob setProgress={setProgress} landing={landing} />
              }
            />
          </Route>

          {/* Root path: redirect to /home or /company/dashboard based on user profile */}
          <Route
            path="/"
            element={
              <RedirectByProfile />
            }
          />

          {/* MainLayout nested protected routes */}
          <Route
            path="/"
            element={
              <MainLayout
                setProgress={setProgress}
                progress={progress}
                landing={landing}
              />
            }
          >
            <Route
                path="view-job"
                element={<Main setProgress={setProgress} progress={progress} />}
              />
              <Route
                path="view-job/:id"
                element={
                  <ViewJob setProgress={setProgress} progress={progress} />
                }
              />
            <Route element={<ProtectedRoute />}>
              <Route
                path="home"
                element={<Home setProgress={setProgress} progress={progress} />}
              />
            </Route>
            
            <Route element={<ProtectedRoute />}>
              <Route
                path="report"
                element={
                  <ReportPage setProgress={setProgress} landing={landing} />
                }
              />
            </Route>
            <Route element={<ProtectedRoute />}>
              <Route
                path="my-job"
                element={
                  <MyJobs setProgress={setProgress} progress={progress} />
                }
              />
            </Route>
            <Route element={<ProtectedRoute />}>
              <Route
                path="profile"
                element={
                  <Profile setProgress={setProgress} progress={progress} />
                }
              />
            </Route>
          </Route>
          {/* <Route element={<PublicRoute />}> */}
          <Route
            path="/login"
            element={<Login setProgress={setProgress} progress={progress} />}
          />
          <Route
            path="/signup"
            element={<Register setProgress={setProgress} progress={progress} />}
          />
          <Route
            path="/forgot-password"
            element={<Reset setProgress={setProgress} progress={progress} />}
          />
          <Route
            path="/reset-password"
            element={
              <RegainAccess setProgress={setProgress} progress={progress} />
            }
          />
          {/* </Route> */}
          <Route element={<ProtectedRoute />}>
            <Route path="/company" element={<CompanyLayout />} exact>
              <Route path="dashboard" element={<Dashboard />} />
              <Route
                path="jobs"
                element={<JobsCompany setProgress={setProgress} progress={progress} />}
              />
              <Route
                path="profile"
                element={<CompanyProfile setProgress={setProgress} progress={progress} />}
              />
              <Route
                path="job/:id"
                element={<SingleJobView progress={progress} setProgress={setProgress} />}
              />
              <Route
                path="update-job/:id"
                element={<JobDetailForm setProgress={setProgress} />}
              />
              <Route
                path="create-job"
                element={<JobDetailForm setProgress={setProgress} />}
              />
              <Route path="applications" element={<Applications progress={progress} setProgress={setProgress} />} />
              <Route path="interviews" element={<Interviews progress={progress} setProgress={setProgress} />} />
              <Route
                path="recruiters"
                element={<Recruiters setProgress={setProgress} />}
              />
              <Route
                path="change-password"
                element={<ChangePassword setProgress={setProgress} />}
              />
            </Route>
          </Route>
        </Routes>
      </Router>
    </>
  );
}

export default App;
