import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

function DashboardLoader() {
  const TableContentLoader = () => {
    return (
      <div className="bg-white rounded-3xl shadow-md p-6 overflow-auto">
        {/* Simulated header bar */}
        <div className="h-5 w-40 bg-gray-200 rounded mb-4"></div>

        <table className="min-w-full whitespace-nowrap">
          <thead>
            <tr>
              {[1, 2, 3, 4].map((_, i) => (
                <th key={i} className="px-4 py-3">
                  <div className="h-3 w-24 bg-gray-200 rounded"></div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[1, 2, 3, 4, 5].map((_, idx) => (
              <tr key={idx} className="border-t border-[#F4F4F5]">
                <td className="px-4 py-4">
                  <div className="w-6 h-4 bg-gray-200 rounded"></div>
                </td>
                <td className="px-4 py-4">
                  <div className="w-40 h-4 bg-gray-200 rounded mb-1"></div>
                </td>
                <td className="px-4 py-4">
                  <div className="w-24 h-4 bg-gray-200 rounded"></div>
                </td>
                <td className="px-4 py-4">
                  <div className="w-28 h-3 bg-gray-200 rounded mb-1"></div>
                  <div className="w-24 h-3 bg-gray-100 rounded"></div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };
  return (
    <div className="flex flex-col gap-1 overflow-x-auto rounded-[1.13rem]">
      <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-1">
        {Array(4)
          .fill(0)
          .map((_, idx) => (
            <div
              key={idx}
              className="bg-white rounded-3xl px-8 py-6 min-h-[120px]"
            >
              <div className="flex items-center space-x-4">
                {/* Hollow Circle */}
                <div className="w-20 h-20 rounded-full border-8 border-gray-200 text-4xl text-gray-200 flex items-center justify-center">
                  {Math.floor(Math.random() * 101)}
                </div>

                {/* Lines beside the circle */}
                <div className="flex flex-col space-y-2 flex-1">
                  <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                  <div className="h-3 bg-gray-100 rounded w-1/2"></div>
                </div>
              </div>
            </div>
          ))}
      </div>

      {/* Chart and Tables section - two per row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-1">
        {/* Jobs Overview Chart */}
        <div className="bg-white rounded-3xl shadow-md p-6">
          <div className="h-5 w-40 bg-gray-200 rounded mb-4"></div>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart
              data={[
                { name: "", Jobs: 100 },
                { name: "", Jobs: 140 },
                { name: "", Jobs: 120 },
                { name: "", Jobs: 160 },
                { name: "", Jobs: 90 },
                { name: "", Jobs: 110 },
              ]}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={false} />
              <YAxis hide />
              <Tooltip
                contentStyle={{ backgroundColor: "#fff", borderRadius: 8 }}
                labelFormatter={() => ""}
                formatter={() => ["", ""]}
              />
              <Bar
                dataKey="Jobs"
                fill="#e5e7eb"
                radius={[4, 4, 0, 0]}
                isAnimationActive={false}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Jobs Table */}
        <TableContentLoader />
        {/* Recent Applications Table */}
        <TableContentLoader />

        {/* Applications Overview Chart */}
        <div className="bg-white rounded-3xl shadow-md p-6">
          <div className="h-5 w-40 bg-gray-200 rounded mb-4"></div>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart
              data={[
                { name: "", Total: 150, Shortlisted: 60, Rejected: 30 },
                { name: "", Total: 120, Shortlisted: 70, Rejected: 40 },
                { name: "", Total: 100, Shortlisted: 65, Rejected: 45 },
                { name: "", Total: 140, Shortlisted: 55, Rejected: 35 },
                { name: "", Total: 130, Shortlisted: 60, Rejected: 38 },
                { name: "", Total: 90, Shortlisted: 50, Rejected: 30 },
              ]}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={false} />
              <YAxis hide />
              <Tooltip
                contentStyle={{ backgroundColor: "#fff", borderRadius: 8 }}
                labelFormatter={() => ""}
                formatter={() => ["", ""]}
              />
              <Bar
                dataKey="Total"
                fill="#e5e7eb"
                radius={[4, 4, 0, 0]}
                isAnimationActive={false}
              />{" "}
              <Bar
                dataKey="Shortlisted"
                fill="#e5e7eb"
                radius={[4, 4, 0, 0]}
                isAnimationActive={false}
              />{" "}
              <Bar
                dataKey="Rejected"
                fill="#e5e7eb"
                radius={[4, 4, 0, 0]}
                isAnimationActive={false}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recruiter List */}
        <TableContentLoader />

        {/* Interview List */}
        <TableContentLoader />
      </div>
    </div>
  );
}

export default DashboardLoader;
