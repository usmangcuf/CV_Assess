import React, { useState } from "react";
import { FaRegEye, FaRegEyeSlash } from "react-icons/fa";

export default function ShowPassword({
  label = "Password",
  fieldName = "",
  error = "",
  validation = () => {},
}) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="family-outfit flex flex-col items-baseline gap-[0.6rem] w-full relative">
      {label && (
        <label className="font-[500] text-[1rem] text-[#707070]">
          {label}*
        </label>
      )}

      <div className="relative w-full">
        <input
          type={showPassword ? "text" : "password"}
          placeholder={
            label === "Password"
              ? "Enter password"
              : label === "Repeat Password"
              ? "Enter password again"
              : label === "New Password"
              ? "Enter new password"
              : label === "Repeat Password"
              ? "Enter password again"
              : label
          }
          {...(validation ? validation(fieldName) : {})}
          className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full pr-[2.5rem]" // Adjust padding for icon
        />
        <span
          className="absolute right-4 top-1/2 transform -translate-y-1/2 cursor-pointer text-[#707070]"
          onClick={() => setShowPassword(!showPassword)}
        >
          {showPassword ? <FaRegEyeSlash /> : <FaRegEye />}
        </span>
      </div>

      {error && (
        <span className="text-[0.8rem] text-red-600 pl-[1.5rem]">
          {error.charAt(0).toUpperCase() + error.slice(1)}
        </span>
      )}
    </div>
  );
}
