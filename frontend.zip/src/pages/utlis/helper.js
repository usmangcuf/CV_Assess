
export function formatDate(dateString) {
    if (!dateString) return '';

    const date = new Date(dateString);
    const options = { month: 'short', day: 'numeric', year: '2-digit' };
    return date.toLocaleDateString('en-US', options);
}

export function formatName(name){
    if(!name) return "";
    return name.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase())
}