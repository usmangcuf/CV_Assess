export const JobLoader = () => (
  <div className="p-[1.5rem] rounded-[1rem] border border-[#94949470] animate-pulse">
    <div className="flex justify-between">
      <div className="h-8 bg-gray-300 w-62 mb-6 rounded"></div>
      <div className="rounded-full bg-gray-300 w-8 h-8"></div>
    </div>
    <div className="flex gap-3">
      <div className="flex justify-between gap-2">
        <div className="rounded-full bg-gray-300 w-7 h-7"></div>
        <div className="h-7 bg-gray-300 w-42 rounded"></div>
      </div>
      <div className="flex justify-between gap-3">
        <div className="rounded-full bg-gray-300 w-7 h-7"></div>
        <div className="h-7 bg-gray-300 w-42 rounded"></div>
      </div>
      <div className="flex justify-between gap-3">
        <div className="rounded-full bg-gray-300 w-7 h-7"></div>
        <div className="h-7 bg-gray-300 w-42 rounded"></div>
      </div>
    </div>
    <div className="flex flex-col gap-2.5 mt-9">
      <div className="h-3 bg-gray-300 w-full rounded"></div>
      <div className="h-3 bg-gray-300 w-full rounded"></div>
      <div className="h-3 bg-gray-300 w-full rounded"></div>
      <div className="h-3 bg-gray-300 w-full rounded"></div>
    </div>
    <div className="flex justify-between items-center mt-6">
      <div className="flex items-center gap-6">
        <div className="rounded-full bg-gray-300 w-8 h-8"></div>
        <div className="h-4 w-20 bg-gray-300 rounded"></div>
      </div>
      <div className="flex -space-x-2">
        <div className="rounded-full bg-gray-300 w-8 h-8"></div>
        <div className="rounded-full bg-gray-300 w-8 h-8"></div>
        <div className="rounded-full bg-gray-300 w-8 h-8"></div>
      </div>
      <div className="flex justify-between items-center">
        <div className="h-8 w-20 bg-gray-300 rounded-[3.1rem]"></div>
      </div>
    </div>
  </div>
);

export const RolesLoader = () => (
  <div className="animate-pulse">
    <div className="h-10.5 w-48 rounded-full bg-gray-300"></div>
  </div>
);

export const ViewJobLoader = () => (
  <div className="animate-pulse">
    <div className="flex justify-between">
      <div className="h-6 w-48 rounded-full flex justify-between">
        <div className="bg-gray-300 h-full w-6 rounded-full"></div>
        <div className="bg-gray-300 h-full w-40 rounded-full"></div>
      </div>
      <div className="h-6 w-48 rounded-full flex justify-between">
        <div className="bg-gray-300 h-full w-6 rounded-full"></div>
        <div className="bg-gray-300 h-full w-40 rounded-full"></div>
      </div>
    </div>

    <div className="bg-gray-300 h-10 w-full rounded-[0.65rem] mt-14"></div>

    <div className="bg-gray-300 h-6 w-3xs rounded-[0.65rem] mt-9"></div>

    <div className="h-7 mt-10 flex gap-3">
      <div className="bg-gray-300 rounded-[0.65rem] h-full w-full"></div>
      <div className="bg-gray-300 rounded-[0.65rem] h-full w-full"></div>
      <div className="bg-gray-300 rounded-[0.65rem] h-full w-full"></div>
      <div className="bg-gray-300 rounded-[0.65rem] h-full w-full"></div>
      <div className="bg-gray-300 rounded-[0.65rem] h-full w-full"></div>
    </div>

    <div className="h-7 w-50 mt-10 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-65 w-full mt-10 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-6 w-40 mt-10 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2 w-110 mt-8 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2 w-150 mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2 w-110 mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2 w-110 mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2 w-155 mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2 w-110 mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2 w-134 mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2 w-145 mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="mt-10 bg-gray-300 h-7.5 w-60 rounded-[0.65rem]"></div>

    <div className="p-[1.5rem] rounded-[1rem] border border-[#94949470] mt-10">
      <div className="flex justify-between">
        <div className="flex justify-between gap-2">
          <div className="rounded-full bg-gray-300 w-7 h-7"></div>
          <div className="h-7 bg-gray-300 w-42 rounded"></div>
        </div>
        <div className="h-7 bg-gray-300 w-42 rounded"></div>
      </div>
      <div className="flex flex-col gap-2.5 mt-9">
        <div className="h-3 bg-gray-300 w-full rounded"></div>
        <div className="h-3 bg-gray-300 w-full rounded"></div>
        <div className="h-3 bg-gray-300 w-full rounded"></div>
        <div className="h-3 bg-gray-300 w-full rounded"></div>
      </div>
    </div>

    <div className="h-7 w-47 mt-7 bg-gray-300 rounded-[0.65rem]"></div>
  </div>
);

export const ViewJobLoaderSide = () => (
  <div className="p-6 rounded-2xl border border-[#94949470] animate-pulse">
    <div className="h-8 bg-gray-300 w-62 mb-6 rounded"></div>
    <div className="h-2.5 w-full mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2.5 w-full mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2.5 w-full mt-3 bg-gray-300 rounded-[0.65rem]"></div>
    <div className="h-2.5 w-50 mt-3 bg-gray-300 rounded-[0.65rem]"></div>

    <div className="flex items-center mt-6 gap-8">
      <div className="flex -space-x-2">
        <div className="rounded-full bg-gray-300 w-8 h-8"></div>
        <div className="rounded-full bg-gray-300 w-8 h-8"></div>
        <div className="rounded-full bg-gray-300 w-8 h-8"></div>
      </div>
      <div className="rounded-[0.65rem] bg-gray-300 w-30 h-4"></div>
    </div>

    <div className="h-10 w-full mt-7 bg-gray-300 rounded-[3.1rem]"></div>

    <div className="flex gap-4 mt-7">
      <div className="h-10 w-full bg-gray-300 rounded-[3.1rem]"></div>
      <div className="h-10 w-full bg-gray-300 rounded-[3.1rem]"></div>
    </div>

    <div className="h-7 w-35 mt-10 bg-gray-300 rounded-[3.1rem]"></div>

    <div className="h-7 w-full mt-10 bg-gray-300 rounded-[3.1rem]"></div>
    <div className="h-7 w-full mt-3 bg-gray-300 rounded-[3.1rem]"></div>
  </div>
);

export const ReportLoader = () => (
  <div className="bg-[#f8f9fb] min-h-screen p-4 md:p-8 flex flex-col md:flex-row gap-6 w-full">
    <div className="flex-1 flex flex-col gap-6">
      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className="bg-white rounded-2xl shadow flex items-center px-8 py-6 gap-6 min-h-[120px] min-w-[280px]"
          >
            <div className="w-20 h-20 bg-gray-200 rounded-full animate-pulse" />
            <div className="flex flex-col">
              <div className="h-5 w-32 bg-gray-200 rounded mb-2 animate-pulse" />
              <div className="h-4 w-24 bg-gray-100 rounded animate-pulse" />
            </div>
          </div>
        ))}
      </div>

      {/* Chart Section */}
      <div className="bg-[#f8f9fb] rounded-3xl shadow p-6">
        <div className="h-6 w-40 bg-gray-300 rounded mb-4 animate-pulse" />
        <div className="w-full h-72 bg-white rounded-xl animate-pulse" />
        <div className="flex gap-8 mt-4 justify-center">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="h-4 w-24 bg-gray-200 rounded animate-pulse"
            />
          ))}
        </div>
      </div>

      {/* Horizontal Cards */}
      <div>
        <div className="h-5 w-40 bg-gray-300 rounded mb-3 animate-pulse" />
        <div className="flex gap-4 overflow-x-auto pb-2">
          {[...Array(4)].map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-xl shadow flex flex-col items-center px-6 py-4 min-w-[160px]"
            >
              <div className="w-10 h-10 bg-gray-300 rounded-full mb-2 animate-pulse" />
              <div className="h-4 w-24 bg-gray-200 rounded mb-1 animate-pulse" />
              <div className="h-3 w-20 bg-gray-100 rounded animate-pulse" />
            </div>
          ))}
        </div>
      </div>

      {/* Recommended Jobs */}
      <div>
        <div className="h-5 w-40 bg-gray-300 rounded mb-3 animate-pulse" />
        <div className="flex flex-col gap-4">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="p-6 border-1 rounded-xl bg-white animate-pulse"
            >
              <div className="flex justify-between items-center mb-4">
                <div className="h-5 w-48 bg-gray-200 rounded animate-pulse" />
                <div className="w-6 h-6 bg-gray-200 rounded-full animate-pulse" />
              </div>
              <div className="flex gap-4">
                <div className="h-4 w-32 bg-gray-100 rounded animate-pulse" />
                <div className="h-4 w-32 bg-gray-100 rounded animate-pulse" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

export const CompanyJobLoader = () => (
  <>
    <div className="flex items-stretch gap-2.5 animate-pulse">
      <div className="flex items-start justify-between w-[70%] bg-white px-6 py-6 rounded-[1.13rem]">
        <div className="flex flex-col gap-9">
          <div className="flex items-center gap-4">
            <div className="w-5 h-5 bg-gray-200 rounded-full"></div>
            <div className="h-4 bg-gray-200 rounded w-24"></div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-5 h-5 bg-gray-200 rounded-full"></div>
            <div className="h-4 bg-gray-200 rounded w-20"></div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-5 h-5 bg-gray-200 rounded-full"></div>
            <div className="h-4 bg-gray-200 rounded w-32"></div>
          </div>
        </div>

        <div className="flex flex-col gap-9 border-l border-gray-200 pl-10">
          <div className="flex items-center gap-4">
            <div className="w-5 h-5 bg-gray-200 rounded-full"></div>
            <div className="h-4 bg-gray-200 rounded w-28"></div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-5 h-5 bg-gray-200 rounded-full"></div>
            <div className="h-4 bg-gray-200 rounded w-24"></div>
          </div>
          <div className="h-6 bg-gray-200 rounded-full w-16"></div>
        </div>

        <div className="flex flex-col gap-9 border-l border-gray-200 pl-10">
          <div className="flex items-center gap-4">
            <div className="w-5 h-5 bg-gray-200 rounded-full"></div>
            <div className="h-4 bg-gray-200 rounded w-20"></div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-5 h-5 bg-gray-200 rounded-full"></div>
            <div className="h-4 bg-gray-200 rounded w-12"></div>
          </div>
          <div className="h-4"></div>
        </div>
      </div>

      <div className="flex items-center justify-between w-[30%] bg-white px-6 py-6 rounded-[1.13rem]">
        <div className="flex flex-col gap-4 w-full">
          <div className="h-10 bg-gray-200 rounded-full w-full"></div>
          <div className="h-10 bg-gray-200 rounded-full w-full"></div>
          <div className="h-10 bg-gray-200 rounded-full w-full"></div>
        </div>
      </div>
    </div>

    <div className="mt-1 bg-white rounded-[1.13rem] px-8 py-8 animate-pulse">
      <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>

      <div className="space-y-3 mb-6">
        <div className="h-4 bg-gray-200 rounded w-full"></div>
        <div className="h-4 bg-gray-200 rounded w-full"></div>
        <div className="h-4 bg-gray-200 rounded w-5/6"></div>
        <div className="h-4 bg-gray-200 rounded w-2/3"></div>
      </div>

      <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>

      <div className="space-y-3 mb-6">
        {[...Array(7)].map((_, i) => (
          <div key={i} className="flex items-center">
            <div className="w-2 h-2 bg-gray-200 rounded-full mr-2"></div>
            <div className="h-3 bg-gray-200 rounded w-full"></div>
          </div>
        ))}
      </div>

      <div className="h-8 bg-gray-200 rounded w-1/6 mb-6"></div>

      <div className="flex flex-wrap gap-3 mt-7">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="h-8 bg-gray-200 rounded-full w-24"></div>
        ))}
      </div>
    </div>
  </>
);

export const ApplicationLoader = () => {
  <div className="bg-[#F6F3EA] overflow-y-auto family-outfit animate-pulse">
    {/* Header Shimmer */}
    <div
      className="flex items-center mb-1 justify-between px-6 py-2 pb-5 bg-[#FFFFFF]"
      style={{ borderBottomLeftRadius: 18, borderBottomRightRadius: 18 }}
    >
      <div className="h-8 w-48 bg-gray-200 rounded"></div>
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="h-10 w-56 bg-gray-200 rounded-full"></div>
        </div>
      </div>
    </div>

    {/* Table Shimmer */}
    <div className="bg-white rounded-[1.13rem] px-6 py-4 overflow-x-auto">
      {/* Table Header Shimmer */}
      <div className="grid grid-cols-8 gap-4 mb-4">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="h-6 bg-gray-200 rounded"></div>
        ))}
      </div>

      {/* Table Rows Shimmer */}
      <div className="space-y-4">
        {[...Array(5)].map((_, rowIndex) => (
          <div
            key={rowIndex}
            className="grid grid-cols-8 gap-4 items-center py-4 border-t border-[#F4F4F5]"
          >
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="space-y-1">
              <div className="h-3 bg-gray-200 rounded"></div>
              <div className="h-3 bg-gray-200 rounded w-3/4"></div>
            </div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-6 bg-gray-200 rounded-full w-16"></div>
            <div className="h-8 w-8 bg-gray-200 rounded-full mx-auto"></div>
          </div>
        ))}
      </div>

      {/* Pagination Shimmer */}
      <div className="flex items-center justify-between mt-6">
        <div className="h-10 w-24 bg-gray-200 rounded-full"></div>
        <div className="flex gap-2">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-8 w-8 bg-gray-200 rounded-full"></div>
          ))}
        </div>
        <div className="h-10 w-20 bg-gray-200 rounded-full"></div>
      </div>
    </div>
  </div>;
};

export const Shimmer = () => {
  return (
    <div className="bg-[#F6F3EA] animate-pulse w-fit">
      <div className="h-9 w-100 bg-gray-300 rounded mb-3 animate-pulse" />
    </div>
  );
};
