import IMG_dashboard from '../../assets/dashboard/dashboard.svg'
import IMG_applications from '../../assets/dashboard/applications.svg'
import IMG_hr from '../../assets/dashboard/hr.svg'
import IMG_interviews from '../../assets/dashboard/interviews.svg'
import IMG_jobs from '../../assets/dashboard/jobs.svg'
import IMG_createJob from '../../assets/dashboard/createJob.svg'

export {
    IMG_applications,
    IMG_dashboard,
    IMG_hr,
    IMG_interviews,
    IMG_jobs,
    IMG_createJob
}