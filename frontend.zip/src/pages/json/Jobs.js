export const jobs = [
    {
        "id": 1,
        "title": "Graphic Designer",
        "company": "Google",
        "location": "United States",
        "type": "Remote",
        "salary": {
            "min": "1000",
            "max": "30000"
        },
        "posted": "1 day ago",
        "companyLogo": "/assets/img/google.svg",
        "description": "We are looking for a creative Graphic Designer to join our team at Google. You will be responsible for creating visually appealing designs that align with our brand identity.",
        "applicants": [
            "/assets/img/user1.png",
            "/assets/img/user2.png",
            "/assets/img/user3.png"
        ],
        "isSaved": true
    },
    {
        "id": 2,
        "title": "Frontend Developer",
        "company": "Microsoft",
        "location": "United States",
        "type": "Remote",
        "salary": {
            "min": "12000",
            "max": "320000"
        },
        "posted": "2 days ago",
        "companyLogo": "/assets/img/microsoft.svg",
        "description": "We are seeking a skilled Frontend Developer to join Microsoft’s development team. You will be responsible for building and maintaining user-friendly interfaces using modern web technologies.",
        "applicants": [
            "/assets/img/user1.png",
            "/assets/img/user2.png"
        ],
        "applied": true,
        "isSaved": true
    },
    {
        "id": 3,
        "title": "Backend Developer",
        "company": "Amazon",
        "location": "Canada",
        "type": "Hybrid",
        "salary": {
            "min": "8000",
            "max": "250000"
        },
        "posted": "5 days ago",
        "companyLogo": "/assets/img/amazon.svg",
        "description": "Join Amazon as a Backend Developer and work on large-scale applications. Strong knowledge of Node.js, Express.js, and databases is required.",
        "applicants": [
            "/assets/img/user3.png",
            "/assets/img/user4.png"
        ],
        "isSaved": true
    },
    {
        "id": 4,
        "title": "Full Stack Developer",
        "company": "Facebook",
        "location": "United Kingdom",
        "type": "On-site",
        "salary": {
            "min": "15000",
            "max": "300000"
        },
        "posted": "3 days ago",
        "companyLogo": "/assets/img/facebook.svg",
        "description": "We are hiring a Full Stack Developer at Facebook. Work with both frontend and backend technologies to build scalable applications.",
        "applicants": [
            "/assets/img/user2.png",
            "/assets/img/user5.png",
            "/assets/img/user6.png"
        ]
    },
    {
        "id": 5,
        "title": "UI/UX Designer",
        "company": "Apple",
        "location": "United States",
        "type": "Remote",
        "salary": {
            "min": "5000",
            "max": "100000"
        },
        "posted": "7 days ago",
        "companyLogo": "/assets/img/apple.svg",
        "description": "Apple is seeking a UI/UX Designer to enhance user experiences across our digital products. Experience with Figma and Adobe XD is a plus.",
        "applicants": [
            "/assets/img/user7.png",
            "/assets/img/user8.png"
        ],
        "applied": true
    },
    {
        "id": 6,
        "title": "Data Scientist",
        "company": "Tesla",
        "location": "Germany",
        "type": "Hybrid",
        "salary": {
            "min": "18000",
            "max": "350000"
        },
        "posted": "4 days ago",
        "companyLogo": "/assets/img/tesla.svg",
        "description": "Tesla is looking for a Data Scientist to analyze large datasets and provide insights that drive business decisions. Experience with Python and Machine Learning is required.",
        "applicants": [
            "/assets/img/user9.png",
            "/assets/img/user10.png"
        ]
    },
    {
        "id": 7,
        "title": "Software Engineer",
        "company": "Netflix",
        "location": "United States",
        "type": "Remote",
        "salary": {
            "min": "12000",
            "max": "270000"
        },
        "posted": "2 days ago",
        "companyLogo": "/assets/img/netflix.svg",
        "description": "Netflix is hiring a Software Engineer to work on high-performance streaming applications. Experience with JavaScript and React is required.",
        "applicants": [
            "/assets/img/user3.png",
            "/assets/img/user11.png"
        ],
        "isSaved": true
    },
    {
        "id": 8,
        "title": "Cyber Security Analyst",
        "company": "IBM",
        "location": "United States",
        "type": "On-site",
        "salary": {
            "min": "10000",
            "max": "290000"
        },
        "posted": "6 days ago",
        "companyLogo": "/assets/img/ibm.svg",
        "description": "IBM is looking for a Cyber Security Analyst to protect company assets and data from cyber threats. Experience with penetration testing and network security is a plus.",
        "applicants": [
            "/assets/img/user12.png",
            "/assets/img/user13.png"
        ],
        "applied": true
    }
];
