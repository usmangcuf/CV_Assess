import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Roles from "./common/Roles";
import Search from "./common/Search";
import Filter from "./components/Filter";
import JobCard from "./job/JobCard";
import { api } from "./utlis/customAPI";
import { Shimmer } from "./utlis/shimmer";

export default function Main({ setProgress, progress }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const prevQueryRef = useRef({});
  const firstLoadRef = useRef(true);
  // This holds *all* query params: search form + filters
  const [query, setQuery] = useState({});

  // 1) When URL changes, parse all params into `query`
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const newQuery = {};
    [
      "keyword",
      "location",
      "job_type",
      "level",
      "min_salary",
      "max_salary",
      "search",
      "title",
      "address",
    ].forEach((key) => {
      const val = params.get(key);
      if (val) newQuery[key] = val;
    });

    const firstLoad = Object.keys(prevQueryRef.current).length === 0;

    const isDifferent =
      JSON.stringify(prevQueryRef.current) !== JSON.stringify(newQuery);

    if (firstLoad || isDifferent) {
      prevQueryRef.current = newQuery;
      setQuery(newQuery);
      fetchJobs(newQuery);
    }
  }, [location.search]);

  // 3) fire your API
  const fetchJobs = (q) => {
    setLoading(true);
    setProgress(20);
    const params = new URLSearchParams(q).toString();

    api
      .get(`/candidate/all-jobs?${params}`)
      .then((res) => {
        setProgress(59);
        setJobs(res.data);
      })
      .catch(console.error)
      .finally(() => {
        setProgress(100);
        setLoading(false);
      });
  };

  const cleanParams = (raw) =>
    Object.entries(raw).reduce((acc, [k, v]) => {
      if (v !== "" && v != null && !(Array.isArray(v) && v.length === 0)) {
        acc[k] = v;
      }
      return acc;
    }, {});

  const handleFilterChange = (newFilters) => {
    const merged = { ...query, ...newFilters };
    const cleaned = cleanParams(merged);
    const params = new URLSearchParams(cleaned).toString();
    navigate(`?${params}`, { replace: true });
  };

  return (
    <div className="portal-main family-outfit mt-[5.8rem]">
      <div className="bg-[#F6F3EA]">
        <div className="px-[5rem] py-[2rem] pb-[1.5rem]">
          <h1 className="text-[#000] font-semibold text-[2.25rem] pb-[1.5rem]">
            Find the Career That Fits You
          </h1>
          <Search
            query={query}
            setQuery={handleFilterChange}
            progress={progress}
          />
        </div>
      </div>

      <div className="px-[5rem] mt-[1.5rem] mb-[1.5rem]">
        <Roles
          selectedRole={query.title}
          setSelectedRole={(val) => handleFilterChange({ title: val })}
          loading={loading}
        />
        <div className="mt-[2.25rem] flex gap-[1.5rem]">
          <div className="jobs w-[75%]">
            {loading ? (
              <Shimmer />
            ) : (
              <h1 className="text-[#000] font-semibold text-[2.25rem]">
                Recommended Jobs For You!
              </h1>
            )}

            <div className="mt-[1.5rem]">
              {jobs?.jobs?.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <img
                    src="https://cdn-icons-png.flaticon.com/512/4076/4076478.png"
                    alt="No jobs found"
                    className="w-32 h-32 opacity-50 mb-4"
                  />
                  <h3 className="text-xl font-semibold text-gray-600">
                    No jobs found
                  </h3>
                  <p className="text-gray-500 mt-2">
                    {"There are no jobs available."}
                  </p>
                </div>
              ) : (
                <JobCard
                  data={jobs?.jobs}
                  loading={loading}
                  setProgress={setProgress}
                  progress={progress}
                />
              )}
            </div>
          </div>
          <aside className="w-full lg:w-[25%]">
            <Filter
              onFilterChange={handleFilterChange}
              currentQuery={query}
              loading={loading}
            />
          </aside>
        </div>
      </div>
    </div>
  );
}
