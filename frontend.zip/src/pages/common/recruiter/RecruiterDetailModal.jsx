import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Modal, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import Select from "react-select";
import * as yup from "yup";
import { api } from "../../utlis/customAPI";

export default function RecruiterDetailModal({
  open,
  handleClose,
  setProgress,
  recruiter,
  handleRefreshRecruitersList,
}) {
  const isEdit = !!recruiter;
  const [isLoading, setIsLoading] = useState(false);
  const formSchema = yup.object().shape({
    first_name: yup.string().required("First name is required"),
    last_name: yup.string().required("Last name is required"),
    email: yup.string().email("Invalid email").required("Email is required"),
    gender: yup.string().required("Gender is required"),
  });
  const defaultValues = {
    first_name: "",
    last_name: "",
    email: "",
    gender: "",
  };
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm({
    resolver: yupResolver(formSchema),
    defaultValues,
  });

  // Populate form if recruiter exists
  useEffect(() => {
    if (isEdit) {
      reset(
        recruiter
          ? {
              first_name: recruiter.first_name || "",
              last_name: recruiter.last_name || "",
              email: recruiter.email || "",
              gender: recruiter.gender || "",
            }
          : defaultValues
      );
    }
  }, [isEdit, open]);

  const onSubmit = async (data) => {
    setProgress(40);
    setIsLoading(true);
    try {
      let response;
      if (isEdit) {
        response = await api.put(`/company/update_hr/${recruiter._id}`, data);
        toast.success("Recruiter updated successfully!");
      } else {
        response = await api.post("/company/add-hr", data);
        toast.success("Recruiter added successfully!");
      }
      handleRefreshRecruitersList(
        isEdit ? "update" : "add",
        response?.data?.hr
      );
      setProgress(80);
      reset();
      handleClose();
    } catch (err) {
      console.error(err);
      toast.error(err?.response.data?.message || "Something went wrong!");
    } finally {
      setProgress(100);
      setIsLoading(false);
    }
  };

  const genderOptions = [
    { label: "Male", value: "male" },
    { label: "Female", value: "female" },
    { label: "Other", value: "other" },
  ];

  const selectedGender = genderOptions.find(
    (option) => option.value === watch("gender")
  );

  return (
    <Modal
      open={open}
      onClose={handleClose}
      aria-labelledby="recruiter-modal-title"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "50%",
          bgcolor: "background.paper",
          border: "1px solid #ccc",
          p: 4,
          borderRadius: 2,
        }}
      >
        <Typography id="recruiter-modal-title" variant="h5" component="h2">
          {isEdit ? "Edit Recruiter" : "Add New Recruiter"}
        </Typography>

        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col gap-4 mt-4"
        >
          {/* First Name */}
          <div className="flex flex-col gap-1">
            <input
              type="text"
              placeholder="First Name"
              {...register("first_name")}
              className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
            />
            {errors.first_name && (
              <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                {errors.first_name.message}
              </p>
            )}
          </div>

          {/* Last Name */}
          <div className="flex flex-col gap-1">
            <input
              type="text"
              placeholder="Last Name"
              {...register("last_name")}
              className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
            />
            {errors.last_name && (
              <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                {errors.last_name.message}
              </p>
            )}
          </div>

          {/* Email */}
          <div className="flex flex-col gap-1">
            <input
              type="email"
              placeholder="Email"
              {...register("email")}
              disabled={isEdit}
              className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
            />
            {errors.email && (
              <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                {errors.email.message}
              </p>
            )}
          </div>

          {/* Gender */}
          <div className="flex flex-col gap-1">
            <Select
              options={genderOptions}
              value={selectedGender}
              onChange={(selected) => setValue("gender", selected?.value)}
              placeholder="Select Gender"
              className="custom-selector"
              classNamePrefix="react-select"
            />
            {errors.gender && (
              <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                {errors.gender.message}
              </p>
            )}
          </div>

          <div className="flex justify-end gap-4 mt-4">
            <button
              type="button"
              onClick={() => {
                handleClose(); // close modal
              }}
              disabled={isLoading}
              className="border border-[#FC6935] cursor-pointer text-[#FC6935] rounded-full px-[25px] py-[11px] font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
            >
              {isEdit ? "Update Recruiter" : "Add Recruiter"}
            </button>
          </div>
        </form>
      </Box>
    </Modal>
  );
}
