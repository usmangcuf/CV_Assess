import { useEffect, useState } from "react";

export default function Search({ query, setQuery, progress }) {
  const [keyword, setKeyword] = useState("");
  const [address, setAddress] = useState("");

  // ★ Sync local state whenever `query` prop changes
  useEffect(() => {
    setKeyword(query.keyword || "");
    setAddress(query.address || "");
  }, [query.keyword, query.address]);

  const handleSearch = (e) => {
    e.preventDefault();
    setQuery({
      keyword,
      address,
    });
  };

  return (
    <form
      onSubmit={handleSearch}
      className="bg-white rounded-full text-[#707070] py-[12px] pl-[3rem] pr-[0.75rem] flex justify-between sec_search"
    >
      <div className="flex items-center gap-[1.5rem]">
        <i className="search-icon"></i>
        <input
          type="text"
          name="keyword"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          placeholder="Search by job title, skill, or keyword"
          className="outline-none w-[18.75rem]"
        />
      </div>

      <div className="flex items-center gap-[1.5rem] pl-[2rem] border-l border-l-[#F7F7F7]">
        <i className="world-icon"></i>
        <input
          type="text"
          name="address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Search by location or city"
          className="outline-none"
        />
      </div>

      <button
        type="submit"
        className="bg-[#FC6935] text-white font-medium text-[1.25rem] rounded-full cursor-pointer py-[0.8rem] px-[3.5rem]"
        disabled={progress}
      >
        Search
      </button>
    </form>
  );
}
