import { useState } from "react";
import CustomEditor from "../../components/CustomEditor";
import AIContentGenerateModal from "./AIContentGenerateModal";
import { Tooltip } from "@mui/material";

function JobDetails({ formData, handleChange, errors }) {
  const [isOpenAIModal, setIsOpenAIModal] = useState(false);
  const [aiContentType, setAiContentType] = useState("");

  const handleOpenAIModal = (e, type) => {
    e.preventDefault();
    setAiContentType(type);
    setIsOpenAIModal(true);
  };

  return (
    <>
      {/* Description */}
      <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
        <label className="font-medium text-[1rem] text-[#707070]">
          Description
        </label>
        <div className="w-full relative !min-h-[400px]">
          <CustomEditor
            value={formData.description}
            onChange={(value) => handleChange("description", value)}
            placeholder="Provide a detailed overview of the job, including expectations and scope..."
          />
          <Tooltip
            title="Let AI assist you in writing a professional job description."
            placement="top"
          >
            <button
              onClick={(e) => handleOpenAIModal(e, "description")}
              className="bg-[#FC6935] text-white cursor-pointer px-[25px] py-[11px] rounded-full font-semibold absolute bottom-5 right-5 z-10"
            >
              Generate AI
            </button>
          </Tooltip>
        </div>
        {errors?.description && (
          <span className="text-[0.8rem] text-red-600 pl-[1.5rem] capitalize">
            {errors?.description}
          </span>
        )}
      </div>

      {/* Responsibilities */}
      <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
        <label className="font-medium text-[1rem] text-[#707070]">
          Responsibilities
        </label>
        <div className="w-full relative !min-h-[400px]">
          <CustomEditor
            value={formData.key_responsibilities}
            onChange={(value) => handleChange("key_responsibilities", value)}
            placeholder="Describe the key responsibilities and duties of this role..."
          />
          <Tooltip
            title="Let AI generate tailored responsibilities for this job role."
            placement="top"
          >
            <button
              onClick={(e) => handleOpenAIModal(e, "key_responsibilities")}
              className="bg-[#FC6935] text-white cursor-pointer px-[25px] py-[11px] rounded-full font-semibold absolute bottom-5 right-5 z-10"
            >
              Generate AI
            </button>
          </Tooltip>
        </div>
      </div>

      {/* AI Modal */}
      {isOpenAIModal && (
        <AIContentGenerateModal
          fieldLabel={aiContentType}
          jobTitle={formData.title}
          onClose={() => setIsOpenAIModal(false)}
          onChange={(value) => handleChange(aiContentType, value)}
        />
      )}
    </>
  );
}

export default JobDetails;
