import CurrencyInput from "react-currency-input-field";
import DatePicker from "react-datepicker";
import Select from "react-select";
import CreatableSelect from "react-select/creatable";
import {
  educationDegrees,
  employmentTypes,
  experienceLevels,
  jobLocationOptions,
  jobPayTypes,
} from "../../json/jobFormUtils";

function JobBasicInfoForm({ formData, handleChange, errors }) {
  return (
    <>
      {/* Job Title */}
      <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
        <label className="font-medium text-[1rem] text-[#707070]">
          Job Title
        </label>
        <input
          className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
          placeholder="Job Title"
          value={formData.title || ""}
          onChange={(e) => handleChange("title", e.target.value)}
        />
        {errors?.title && (
          <span className="text-[0.8rem] text-red-600 pl-[1.5rem] capitalize">
            {errors?.title}
          </span>
        )}
      </div>

      {/* Education Level */}
      <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
        <label className="font-medium text-[1rem] text-[#707070]">
          Education Level
        </label>
        <Select
          className="custom-selector"
          classNamePrefix="react-select"
          options={educationDegrees?.map((degree) => ({
            label: degree,
            value: degree,
          }))}
          value={educationDegrees
            ?.map((degree) => ({ label: degree, value: degree }))
            .find((opt) => opt.value === formData.education)}
          onChange={(selected) => handleChange("education", selected?.value)}
          placeholder="Select Education Level"
        />
      </div>

      {/* Skills */}
      <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
        <label className="font-medium text-[1rem] text-[#707070]">Skills</label>
        <CreatableSelect
          isMulti
          className="custom-selector"
          classNamePrefix="react-select"
          options={[]} // No predefined options
          value={formData.skills.map((skill) => ({
            label: skill,
            value: skill,
          }))}
          onChange={(selectedOptions) =>
            handleChange(
              "skills",
              selectedOptions.map((opt) => opt.value)
            )
          }
          placeholder="Add Skills"
          noOptionsMessage={() => "Type and press enter to add skill"}
          styles={{
            multiValue: (base) => ({
              ...base,
              backgroundColor: "#FC69351A", // chip background
              borderRadius: "20px",
              padding: "2px 6px",
            }),
            multiValueLabel: (base) => ({
              ...base,
              color: "#FC6935", // chip text
              fontWeight: "bold",
            }),
            multiValueRemove: (base) => ({
              ...base,
              color: "#FC6935",
              ":hover": {
                backgroundColor: "#e0521f",
                color: "white",
              },
            }),
          }}
        />
      </div>

      {/* Job Location */}
      <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
        <label className="font-medium text-[1rem] text-[#707070]">
          Job Location
        </label>

        <Select
          className="custom-selector"
          classNamePrefix="react-select"
          options={jobLocationOptions}
          value={jobLocationOptions.find(
            (opt) => opt.value === formData.job_location
          )}
          onChange={(selected) => handleChange("job_location", selected?.value)}
          placeholder="Select Job Location"
        />
        {errors?.job_location && (
          <span className="text-[0.8rem] text-red-600 pl-[1.5rem] capitalize">
            {errors?.job_location}
          </span>
        )}
      </div>

      {/* Address */}
      <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
        <label
          htmlFor="address"
          className="font-medium text-[1rem] text-[#707070]"
        >
          Address
        </label>

        <textarea
          id="address"
          name="address"
          value={formData.address || ""}
          placeholder="Type Address..."
          onChange={(e) => handleChange("address", e.target.value)}
          className="resize-none max-h-[200px] border border-[#D5D8DC] rounded-[1rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
        />
      </div>

      {/* Employment Type */}
      <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
        <label className="font-medium text-[1rem] text-[#707070]">
          Employment Type
        </label>
        <div className="flex flex-wrap w-full gap-4">
          {employmentTypes?.map(({ label, value }) => (
            <label
              key={value}
              className="flex items-center gap-3 flex-grow font-medium text-[1rem] text-[#707070]"
            >
              <input
                type="checkbox"
                name="job_type"
                checked={formData.job_type === value}
                onChange={() => handleChange("job_type", value)}
                className="w-[1rem] h-[1rem]"
              />
              {label}
            </label>
          ))}
        </div>
        {errors?.job_type && (
          <span className="text-[0.8rem] text-red-600 pl-[1.5rem] capitalize">
            {errors?.job_type}
          </span>
        )}
      </div>

      {/* Experience Level */}
      <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
        <label className="font-medium text-[1rem] text-[#707070]">
          Experience Level
        </label>
        <div className="flex flex-wrap w-full gap-4">
          {experienceLevels?.map(({ label, value }) => (
            <label
              key={value}
              className="flex items-center gap-3 flex-grow font-medium text-[1rem] text-[#707070]"
            >
              <input
                type="checkbox"
                checked={formData.level === value}
                onChange={() => handleChange("level", value)}
                className="w-[1rem] h-[1rem]"
              />
              {label}
            </label>
          ))}
        </div>
        {errors?.level && (
          <span className="text-[0.8rem] text-red-600 pl-[1.5rem] capitalize">
            {errors?.level}
          </span>
        )}
      </div>

      {/* Start/End Dates */}
      <div className="grid grid-cols-2 gap-4">
        <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
          <label className="font-medium text-[1rem] text-[#707070]">
            Start Date
          </label>
          <DatePicker
            selected={formData.start_date || null}
            onChange={(date) => handleChange("start_date", date)}
            placeholderText="Start Date"
            className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
            dateFormat="yyyy-MM-dd"
            wrapperClassName="w-full"
            minDate={new Date()}
          />
        </div>
        <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
          <label className="font-medium text-[1rem] text-[#707070]">
            End Date
          </label>
          <DatePicker
            selected={formData.end_date || null}
            onChange={(date) => handleChange("end_date", date)}
            placeholderText="End Date"
            className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
            dateFormat="yyyy-MM-dd"
            wrapperClassName="w-full"
            minDate={new Date()}
          />
        </div>
      </div>

      {/* Pay Type and Salary */}
      <div className="grid grid-cols-3 gap-4">
        <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
          <label className="font-medium text-[1rem] text-[#707070]">
            Pay Type
          </label>
          <Select
            className="custom-selector"
            classNamePrefix="react-select"
            options={jobPayTypes}
            value={jobPayTypes?.find((opt) => opt.value === formData.pay_type)}
            onChange={(selected) => handleChange("pay_type", selected?.value)}
            placeholder="Select Pay Type"
          />
        </div>
        <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
          <label className="font-medium text-[1rem] text-[#707070]">Min</label>
          <CurrencyInput
            id="min_salary"
            name="min_salary"
            placeholder="0.00"
            value={formData.min_salary || ""}
            decimalsLimit={2}
            onValueChange={(value) => handleChange("min_salary", value)}
            className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
          />
        </div>
        <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
          <label className="font-medium text-[1rem] text-[#707070]">Max</label>
          <CurrencyInput
            id="max_salary"
            name="max_salary"
            placeholder="0.00"
            value={formData.max_salary || ""}
            decimalsLimit={2}
            onValueChange={(value) => handleChange("max_salary", value)}
            className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
          />
        </div>
      </div>
    </>
  );
}

export default JobBasicInfoForm;
