import { Box, Modal, Tooltip } from "@mui/material";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { FaCopy } from "react-icons/fa6";
import CustomEditor from "../../components/CustomEditor";
import { api } from "../../utlis/customAPI";
const AIContentGenerateModal = ({
  fieldLabel,
  jobTitle,
  onClose,
  onChange,
}) => {
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const payload = {
          title: jobTitle,
          description: fieldLabel === "description",
          key_responsibilities: fieldLabel === "key_responsibilities",
        };

        const response = await api.post("/ai/generate", payload);

        setContent(response.data.html);
      } catch (error) {
        toast.error(
          error?.response?.data?.message ||
            "Something went wrong while generating content."
        );
        console.error("Generation Error:", error);
      } finally {
        setLoading(false);
      }
    };

    if (jobTitle && fieldLabel) {
      fetchData();
    }
  }, [fieldLabel, jobTitle]);

  const handleSave = () => {
    onChange(content);
    onClose();
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(content);
      toast.success("Copied to clipboard!");
    } catch (err) {
      toast.error("Failed to copy content.");
    }
  };

  return (
    <Modal
      open={true}
      onClose={onClose}
      aria-labelledby="keep-mounted-modal-title"
      aria-describedby="keep-mounted-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "50%",
          bgcolor: "background.paper",
          border: "1px solid #ccc",
          p: 4,
          borderRadius: 2,
        }}
      >
        <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
          <label className="font-medium text-[1.3rem] text-[#707070] capitalize">
            Generate {fieldLabel.replace(/_/g, " ")}
          </label>
          <div className="w-full relative !min-h-[400px]">
            {loading && (
              <div className="absolute inset-0 z-10 bg-white/60 flex items-center justify-center rounded">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-orange-500 border-solid"></div>
              </div>
            )}
            <CustomEditor
              value={content}
              onChange={setContent}
              placeholder={`Generating AI content for ${fieldLabel.replace(
                /_/g,
                " "
              )}...`}
            />
          </div>
        </div>
        <div className="modal-footer flex gap-2 mt-4 items-center">
          <button
            type="button"
            onClick={onClose}
            className="border border-[#FC6935] cursor-pointer text-[#FC6935] rounded-full px-[25px] py-[11px] font-semibold"
          >
            Cancel
          </button>

          <>
            <Tooltip title="Copy to clipboard" placement="top">
              <button
                onClick={handleCopy}
                disabled={!content.trim()}
                className="border border-[#FC6935] text-[#FC6935] rounded-full p-[14px] font-semibold ms-auto
               disabled:border-gray-200 disabled:text-gray-300 disabled:cursor-not-allowed"
              >
                <FaCopy size={18} />
              </button>
            </Tooltip>

            <button
              onClick={handleSave}
              disabled={loading || !content.trim()}
              className="bg-[#FC6935] text-white px-[25px] py-[11px] rounded-full font-semibold cursor-pointer
             disabled:bg-gray-200 disabled:text-gray-300 disabled:cursor-not-allowed"
            >
              Save
            </button>
          </>
        </div>
      </Box>
    </Modal>
  );
};

export default AIContentGenerateModal;
