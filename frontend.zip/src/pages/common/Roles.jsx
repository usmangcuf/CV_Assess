import { useEffect, useRef, useState } from "react";
import { AiOutlineLeft, AiOutlineRight } from "react-icons/ai";
import { RolesLoader } from "../utlis/shimmer";

export default function Roles({ loading, selectedRole, setSelectedRole }) {
  const roles = [
    "Product Designer",
    "Illustration",
    "Research",
    "Senior Dev",
    "Project Management",
    "Designer",
    "UI Designer",
    "React Developer",
    "Mobile Developer",
    "Sopify Developer",
    "Wordpress Developer",
    "Backend Developer",
    "MERN Stack Developer",
    "Full Stack Developer",
    "PHP Developer",
    "Python Developer",
    "Java Developer",
    "C++ Developer",
    "AI Engineer",
    "Data Scientist",
    "Office Manager",
  ];

  const carouselRef = useRef(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const scrollAmount = 200;

  const checkScroll = () => {
    if (carouselRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = carouselRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft + clientWidth < scrollWidth);
    }
  };

  const scrollLeft = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollLeft -= scrollAmount;
      setTimeout(checkScroll, 300);
    }
  };

  const scrollRight = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollLeft += scrollAmount;
      setTimeout(checkScroll, 300);
    }
  };

  useEffect(() => {
    checkScroll();
  }, []);

  return (
    <div className="relative w-full">
      {canScrollLeft && (
        <button
          onClick={scrollLeft}
          className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-white p-2 rounded-full shadow-md cursor-pointer"
        >
          <AiOutlineLeft size={24} />
        </button>
      )}

      <div
        ref={carouselRef}
        className="flex gap-6 overflow-x-auto scroll-smooth whitespace-nowrap no-scrollbar"
        onScroll={checkScroll}
      >
        {loading
          ? [...Array(5)].map((_, i) => <RolesLoader key={i} />)
          : roles.map((role, i) => (
              <div key={i}>
                <div
                  className={`px-6 py-2 border border-[#FC6935] rounded-full text-[#FC6935] text-[1rem] font-medium w-fit cursor-pointer transition-all duration-300 ease-in-out hover:bg-[#FC6935] hover:text-white ${
                    selectedRole === role ? "bg-[#FC6935] text-white" : ""
                  }`}
                  onClick={() => {
                    if (selectedRole === role) {
                      setSelectedRole(null);
                    } else {
                      setSelectedRole(role);
                    }
                  }}
                >
                  {role}
                </div>
              </div>
            ))}
      </div>

      {canScrollRight && (
        <button
          onClick={scrollRight}
          className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-white p-2 rounded-full shadow-md cursor-pointer"
        >
          <AiOutlineRight size={24} />
        </button>
      )}
    </div>
  );
}
