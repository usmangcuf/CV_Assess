import React, { useState } from 'react';
import Select from 'react-select';

const SearchSection = () => {
    const [keyword, setKeyword] = useState('');
    const [location, setLocation] = useState(null);
    const [language, setLanguage] = useState(null);

    const locationOptions = [
        { value: 'pakistan', label: 'Pakistan' },
        { value: 'india', label: 'India' },
        { value: 'china', label: 'China' }
    ];

    const languageOptions = [
        { value: 'english', label: 'English' },
        { value: 'urdu', label: 'Urdu' },
        { value: 'spanish', label: 'Spanish' }
    ];

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log({ keyword, location, language });
    };

    return (
        <div className="w-[80%] mx-auto p-10 rounded-[0.5rem] border border-[#ACB2B980] mt-17.5 mb-17.5">
            <h2 className="text-3xl font-bold mb-6 text-center">Find Your Perfect Match</h2>

            <form onSubmit={handleSubmit} className="flex justify-between items-center">
                <div className="w-[25%]">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Keyword</label>
                    <input
                        type="text"
                        placeholder="Job titles, skill, or keywords"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={keyword}
                        onChange={(e) => setKeyword(e.target.value)}
                    />
                </div>

                <div className='w-[25%]'>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Location:</label>
                    <Select
                        options={locationOptions}
                        value={location}
                        onChange={setLocation}
                        className="w-full"
                        placeholder="Select location"
                        isSearchable
                    />
                </div>

                <div className='w-[25%]'>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Language:</label>
                    <Select
                        options={languageOptions}
                        value={language}
                        onChange={setLanguage}
                        className="w-full"
                        placeholder="Select language"
                        isSearchable
                    />
                </div>
                <div className='mt-5'>
                    <button 
                        type="submit" 
                        className="h-fit bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
                    >
                        Submit
                    </button>
                </div>
            </form>
        </div>
    );
};

export default SearchSection;