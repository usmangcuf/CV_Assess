import React from 'react'
import cube from "../../assets/img/cube.svg";

export default function HowItWork() {
    return (
        <div className="container mx-auto px-4 py-8 pt-0 flex flex-col mt-18">
            <h1 className='text-3xl font-bold mb-2 text-center'>How It Works</h1>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-15">
                <div className="p-4 gap-4 rounded-[0.5rem] min-w-0 flex items-center flex-col">
                    <div className="flex-shrink-0">
                        <img src={cube} alt="" className="w-10 h-10" />
                    </div>
                    <div className="min-w-0">
                        <span className='font-bold text-xl block text-center'>Create Your Profile</span>
                        <p className='font-normal text-[1rem] mt-4 break-words text-center'>
                            Sign up and build your professional profile showcasing your skills and experience
                        </p>
                    </div>
                </div>
                <div className="p-4 gap-4 rounded-[0.5rem] min-w-0 flex items-center flex-col">
                    <div className="flex-shrink-0">
                        <img src={cube} alt="" className="w-10 h-10" />
                    </div>
                    <div className="min-w-0">
                        <span className='font-bold text-xl block text-center'>Create Your Profile</span>
                        <p className='font-normal text-[1rem] mt-4 break-words text-center'>
                            Sign up and build your professional profile showcasing your skills and experience
                        </p>
                    </div>
                </div>
                <div className="p-4 gap-4 rounded-[0.5rem] min-w-0 flex items-center flex-col">
                    <div className="flex-shrink-0">
                        <img src={cube} alt="" className="w-10 h-10" />
                    </div>
                    <div className="min-w-0">
                        <span className='font-bold text-xl block text-center'>Create Your Profile</span>
                        <p className='font-normal text-[1rem] mt-4 break-words text-center'>
                            Sign up and build your professional profile showcasing your skills and experience
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )
}