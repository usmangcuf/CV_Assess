import React from 'react';

const HeroSection = () => {
    return (
        <div className="max-w-4xl m-auto mt-24 mb-18 flex flex-col justify-center items-center bg-[#EEF0F1] px-5 py-10 rounded-3xl">
            <div className="text-center">
                <h1 className="text-3xl font-bold">
                    Ready to get started?
                </h1>

                <p className="text-[1rem] font-normal pt-6">
                    Join thousands of professionals and businesses already connecting on our platform
                </p>

                <div className="flex flex-col sm:flex-row justify-center gap-4 pt-6">
                    <button className="rounded-[3.1rem] text-white bg-[#FC6935] px-[1.5rem] py-[0.6rem] text-[1rem] cursor-pointer">
                        Create Profile
                    </button>

                    <button className="rounded-[3.1rem] text-[#FC6935] border border-[#FC6935] px-[1.5rem] py-[0.6rem] text-[1rem] cursor-pointer">
                        Explore more
                    </button>
                </div>
            </div>
        </div>
    );
};

export default HeroSection;