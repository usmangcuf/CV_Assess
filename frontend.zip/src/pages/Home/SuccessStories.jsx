import React, { useState } from 'react';
import img from "../../assets/img/user.png";
import { Rating } from 'react-simple-star-rating';

const testimonials = [
    {
        quote: "This platform helped me land my dream job at a top tech company within two weeks! The interview process was seamless.",
        name: "Sarah Johnson",
        role: "Frontend Developer",
        rating: 5
    },
    {
        quote: "As a hiring manager, I found the perfect candidate for our team in just 3 days. Highly recommend this platform!",
        name: "Michael Chen",
        role: "Engineering Manager",
        rating: 4.5
    },
    {
        quote: "Transitioning careers was daunting, but the resources here helped me showcase my transferable skills effectively.",
        name: "David Rodriguez",
        role: "Product Designer",
        rating: 4
    },
    {
        quote: "The personalized job recommendations saved me hours of searching. Got multiple offers within a month.",
        name: "Emily Wilson",
        role: "Data Scientist",
        rating: 4.5
    },
    {
        quote: "Our startup found three key hires through this platform. The quality of candidates exceeded our expectations.",
        name: "Jessica Lee",
        role: "CEO, TechStart",
        rating: 5
    },
    {
        quote: "After months of unsuccessful applications elsewhere, I got my first interview request within 24 hours here.",
        name: "Robert Smith",
        role: "Backend Engineer",
        rating: 4
    }
];

export default function SuccessStories() {
    const [currentIndex, setCurrentIndex] = useState(1); // Start with center item active

    const visibleTestimonials = [];
    // Get the 3 visible testimonials based on currentIndex
    for (let i = -1; i <= 1; i++) {
        const index = (currentIndex + i + testimonials.length) % testimonials.length;
        visibleTestimonials.push(testimonials[index]);
    }

    return (
        <div className="container mx-auto px-4 py-8 pt-0 flex flex-col mt-18">
            <h1 className='text-3xl font-bold mb-2 text-center'>Success Stories</h1>
            <span className="text-center block text-[1rem] font-normal mb-10">
                Hear from professionals and businesses who found success on our platform
            </span>

            <div className="mt-15 relative">
                <div className="flex items-center justify-center gap-4">
                    {visibleTestimonials.map((testimonial, idx) => (
                        <div
                            key={`${testimonial.name}-${idx}`}
                            className={`px-4 py-5 rounded-[0.5rem] w-full max-w-sm flex flex-col border border-[#ACB2B980] transition-all duration-300 
                ${idx === 1 ? 'shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] scale-105' : 'opacity-80 scale-95'}`}
                        >
                            <Rating
                                initialValue={testimonial.rating}
                                readonly={true}
                                allowHover={false}
                                className="rating-stars"
                            />
                            <div className="min-w-0">
                                <p className='font-normal text-[1rem] mt-4 break-words'>
                                    "{testimonial.quote}"
                                </p>
                            </div>
                            <div className="flex gap-4 mt-3">
                                <img src={img} className='w-9 h-9 rounded-full' alt={testimonial.name} />
                                <div className="flex flex-col">
                                    <span className='text-[1rem] font-semibold'>{testimonial.name}</span>
                                    <span className='text-[0.9rem] font-normal'>{testimonial.role}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Pagination dots */}
                <div className="flex justify-center gap-2 mt-15">
                    {testimonials.map((_, idx) => (
                        <button
                            key={idx}
                            onClick={() => setCurrentIndex(idx)}
                            className={`w-3 h-3 rounded-full transition-all cursor-pointer ${currentIndex === idx ? 'bg-[#707070]' : 'bg-[#ACB2B980]'}`}
                            aria-label={`Go to testimonial ${idx + 1}`}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
}