import React from 'react'
import User1 from "../../assets/img/user1.png";
import User2 from "../../assets/img/user2.png";
import User3 from "../../assets/img/user3.png";
import Home from "../../assets/img/home-main.png";
import Match from "./Match";
import TopCatgoires from "./TopCatgoires";
import FeaturedJob from "./FeaturedJob";
import HowItWork from "./HowItWork";
import SuccessStories from './SuccessStories';
import GetReady from './getReady';
import Footer from './Footer';
import { useNavigate } from 'react-router-dom';
export default function Report() {
    const navigate = useNavigate(); 
    const applicants = [
        { id: 1, img: User1 },
        { id: 2, img: User2 },
        { id: 3, img: User3 },
        { id: 2, img: User2 },
        { id: 3, img: User3 },
    ];
    return (
        <div className="portal-main home family-outfit mt-[5.8rem]">
            <div className="px-[5rem]">
                <div className="mt-28 mb-5 flex items-center gap-20">
                    <div className="w-1/2">
                        <h1 className='text-[3rem] leading-13.5 font-bold'>Find the perfect talent for your next project</h1>
                        <p className='text-[1.12rem] font-normal pt-6'>Connect with skilled professionals or showcase your expertise to find your next opportunity.</p>
                        <div className="flex items-center gap-4 pt-8">
                            <button className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer" onClick={() => navigate("/profile")}>
                                Find Talent
                            </button>
                            <button className="rounded-[3.1rem] text-[#FC6935] border border-[#FC6935] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer" onClick={() => navigate("/profile")}>
                                Find Work
                            </button>
                        </div>
                    </div>
                    <div className="w-1/2">
                        <div className="bg-home-main relative">
                            <img src={Home} className='w-available h-available' />
                            <div className='bg-[#F7F7F7] rounded-[0.5rem] flex items-center py-5 px-12 gap-6 absolute bottom-[1.8rem] left-[1.8rem]'>
                                <div className="flex -space-x-5">
                                    {applicants?.map((applicant) => (
                                        <img
                                            key={applicant.id}
                                            src={applicant.img}
                                            alt="Applicant"
                                            className={`w-10 h-10 rounded-full border-2 cursor-pointer border-[#94949470] object-cover`}
                                        />
                                    ))}
                                </div>
                                <div className="flex flex-col gap-2.5">
                                    <span className='text-[1rem] font-normal'>Join 1000+ professionals</span>
                                    <span className='text-[0.8rem] font-normal'>Find work or talent everyday</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <Match />
                <TopCatgoires />
                <FeaturedJob />
                <HowItWork />
                <SuccessStories />
                <GetReady />
                <Footer />
            </div>
        </div>
    )
}
