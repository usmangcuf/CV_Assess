import { Navigate, Outlet } from "react-router-dom";

const PublicRoute = () => {
  const token = localStorage.getItem("ai-token");

  if (token) {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
};

export default PublicRoute;
