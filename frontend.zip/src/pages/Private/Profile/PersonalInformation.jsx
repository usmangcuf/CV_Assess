import React, { useRef } from "react";
import { RiUploadCloud2Line } from "react-icons/ri";
import { CiCamera } from "react-icons/ci";
import ViewIcon from "../../../assets/img/preview.svg";
import Select from "react-select";
import toast from "react-hot-toast";
import "./profileStyle.scss";

const PersonalInformation = ({ data, updateData, onNext, isFirst }) => {
  const fileInputRef = useRef(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    updateData({
      ...data,
      [name]: value,
    });
  };

  const triggerFileUpload = () => {
    fileInputRef.current.click();
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.match('image.*')) {
        toast.error('Please select an image file (PNG, JPG, JPEG)');
        return;
      }
  
      if (file.size > 2 * 1024 * 1024) {
        toast.error('File size should be less than 2MB');
        return;
      }
  
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64Image = reader.result;
  
        updateData({
          ...data,
          image_url: base64Image,
          imageFile: file,
        });
      };
  
      reader.readAsDataURL(file);
    }
  };
  
  const handlePayRateChange = (e) => {
    const { name, value } = e.target;
    updateData({
      ...data,
      pay_rate: {
        ...data.pay_rate,
        [name]: name === "amount" ? Number(value) : value,
      },
    });
  };
  const genderOptions = [
    { value: "Male", label: "Male" },
    { value: "Female", label: "Female" },
  ];

  const periodOptions = [
    { value: "hourly", label: "Per Hour" },
    { value: "daily", label: "Per Day" },
    { value: "weekly", label: "Per Week" },
    { value: "monthly", label: "Per Month" },
    { value: "yearly", label: "Per Year" },
  ];

  const languageOptions = [
    { value: "Urdu", label: "Urdu" },
    { value: "English", label: "English" },
    { value: "Spanish", label: "Spanish" },
    { value: "French", label: "French" },
  ];

  const currencyOptions = [
    { value: "USD", label: "USD" },
    { value: "EUR", label: "EUR" },
    { value: "PKR", label: "PKR" },
    { value: "INR", label: "INR" },
    { value: "CAD", label: "CAD" },
    { value: "AUD", label: "AUD" },
  ];

  return (
    <div className="">
      <div className="flex justify-between items-start">
        <h1 className="text-2xl font-semibold text-[#171725] mb-6">
          Personal Information
        </h1>
        <div className="flex items-center gap-1">
          <img src={ViewIcon} alt="Preview" />{" "}
          <span className="text-[1rem] font-semibold text-[#FC6935]">
            View Preview
          </span>
        </div>
      </div>

      <div className="mb-8 flex items-center gap-8">
        {data?.image_url ? (
          <img
            src={data.image_url}
            className="w-25 h-25 bg-[#D9D9D9] rounded-full flex items-center justify-center object-cover"
            alt="Profile"
          />
        ) : (
          <div className="w-25 h-25 bg-[#D9D9D9] rounded-full flex items-center justify-center">
            <CiCamera className="w-6 h-6" />
          </div>
        )}
        <div className="">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/png, image/jpeg, image/jpg"
            className="hidden"
          />
          <button
            onClick={triggerFileUpload}
            className="flex items-center bg-[#FC6935] text-white text-[1rem] font-semibold rounded-full cursor-pointer px-4 py-2 transition-colors"
          >
            <RiUploadCloud2Line />
            &nbsp; Upload
          </button>
          <p className="text-[#707070] text-sm mt-1">PNG, JPG,JPEG (2MB)</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Full Name</h2>
          <input
            type="text"
            name="full_name"
            value={data?.full_name || ""}
            onChange={handleInputChange}
            placeholder="Full Name"
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          />
        </div>

        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Email*</h2>
          <input
            type="text"
            readOnly
            disabled
            value={data?.email || ""}
            placeholder="Enter email address"
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          />
        </div>

        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Date of Birth</h2>
          <input
            type="date"
            name="date_of_birth"
            value={data?.date_of_birth || ""}
            onChange={handleInputChange}
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          />
        </div>

        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Gender</h2>
          <Select
            options={genderOptions}
            value={genderOptions.find((option) => option.value === data?.gender)}
            onChange={(selectedOption) =>
              updateData({ ...data, gender: selectedOption.value })
            }
            className="react-select-container"
            classNamePrefix="react-select"
          />
        </div>

        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Address</h2>
          <input
            name="address"
            value={data?.address || ""}
            onChange={handleInputChange}
            placeholder="Address"
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          />
        </div>

        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-3">Pay Rate</h2>
          <div className="flex items-center gap-3">
            <Select
              options={periodOptions}
              value={periodOptions.find((option) => option.value === data?.pay_rate?.period)}
              onChange={(selectedOption) =>
                updateData({
                  ...data,
                  pay_rate: {
                    ...data.pay_rate,
                    period: selectedOption.value,
                  },
                })
              }
              className="w-[33%] react-select-container"
              classNamePrefix="react-select"
            />

            <Select
              options={currencyOptions}
              value={currencyOptions.find(option => option.value === data?.pay_rate?.currency)}
              onChange={(selectedOption) =>
                updateData({
                  ...data,
                  pay_rate: {
                    ...data.pay_rate,
                    currency: selectedOption.value,
                  },
                })
              }
              className="w-[33%] react-select-container"
              classNamePrefix="react-select"
            />
            <div className="relative w-[33%]">
              <input
                type="number"
                name="amount"
                value={data?.pay_rate?.amount || ""}
                onChange={handlePayRateChange}
                placeholder="0.00"
                className="w-full py-3 pl-4 pr-4 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
              />
            </div>
          </div>
        </div>

        <div className="mb-4 col-span-1 md:col-span-2">
          <h2 className="text-[1rem] text-[#696F79] mb-3">Languages</h2>
          <Select
            options={languageOptions}
            value={languageOptions.find((option) => option.value === data?.language)}
            onChange={(selectedOption) =>
              updateData({ ...data, language: selectedOption.value })
            }
            className="react-select-container"
            classNamePrefix="react-select"
          />
        </div>

        <div className="mb-4 col-span-1 md:col-span-2">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">About Me</h2>
          <textarea
            name="about"
            value={data?.about || ""}
            onChange={handleInputChange}
            placeholder="Write about yourself"
            rows="4"
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          ></textarea>
        </div>

        {/* <div className="mb-4 col-span-1 md:col-span-2">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">CV / Resume</h2>
          <div className="flex mt-4 items-center gap-3 flex-wrap">
            <label className="flex items-center gap-2 rounded-[3.1rem] text-[#FC6935] border border-[#FC6935] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer hover:bg-[#FC6935] hover:text-white transition-colors">
              <input type="file" className="hidden" accept=".pdf,.doc,.docx" />
              <GrAttachment /> Add CV / Resume
            </label>

            {data?.resume_url && (
              <div className="flex items-start gap-3 px-[1.5rem] py-[0.24rem] bg-gray-50 rounded-full border border-gray-200">
                <div className="flex items-center gap-2">
                  <div className="bg-blue-100 rounded-full">
                    <FiFileText className="text-blue-600 w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-800">Resume</p>
                    <p className="text-xs text-gray-500">CV</p>
                  </div>
                </div>
                <button className="ml-2 text-gray-400 cursor-pointer hover:text-red-500 transition-colors">
                  <FiX className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>
        </div> */}
      </div>

      <div className="flex justify-end mt-8">
        <button
          onClick={onNext}
          className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default PersonalInformation;
