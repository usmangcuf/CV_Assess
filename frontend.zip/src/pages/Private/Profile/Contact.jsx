import React from "react";
import { FaPlus, FaTimes } from "react-icons/fa";
import Select from "react-select";
import "./profileStyle.scss";

const ContactSection = ({ data, updateData, onSubmit, onPrevious, isLast }) => {

  const defaultPlatforms = ["Facebook", "LinkedIn", "Twitter", "Instagram", "GitHub", "YouTube"];

  // Get currently used platforms to prevent duplicates
  const usedPlatforms = data.social_media_urls?.map(item => item.platform) || [];

  // Available platforms are those not already selected
  const availablePlatforms = defaultPlatforms.filter(
    platform => !usedPlatforms.includes(platform)
  );

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    updateData({
      ...data,
      [name]: value,
    });
  };

  const handleSocialMediaChange = (index, field, value) => {
    const updatedSocialMedia = [...data.social_media_urls];
    updatedSocialMedia[index] = {
      ...updatedSocialMedia[index],
      [field]: value
    };

    updateData({
      ...data,
      social_media_urls: updatedSocialMedia
    });
  };

  const addSocialLink = () => {
    if (availablePlatforms.length === 0) return;

    updateData({
      ...data,
      social_media_urls: [
        ...(data.social_media_urls || []),
        { platform: availablePlatforms[0], link: "" }
      ]
    });
  };

  const removeSocialLink = (index) => {
    const updatedSocialMedia = data.social_media_urls.filter((_, i) => i !== index);
    updateData({
      ...data,
      social_media_urls: updatedSocialMedia
    });
  };


  return (
    <div className="">
      <h2 className="text-2xl font-semibold mb-4">Contact Information</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label className="text-[1rem] text-[#696F79] mb-2.5 block">
            Phone Number*
          </label>
          <input
            type="tel"
            name="phone_num"
            value={data.phone_num || ""}
            onChange={handleInputChange}
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
            placeholder="Enter phone number"
          />
        </div>

        <div>
          <label className="text-[1rem] text-[#696F79] mb-2.5 block">
            Phone Number (optional)
          </label>
          <input
            type="tel"
            name="phone_num_optional"
            value={data.phone_num_optional || ""}
            onChange={handleInputChange}
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
            placeholder="Enter phone number"
          />
        </div>

        <div>
          <label className="text-[1rem] text-[#696F79] mb-2.5 block">
            Email*
          </label>
          <input
            type="email"
            name="email"
            value={data.email || ""}
            onChange={handleInputChange}
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
            placeholder="example@search.com"
          />
        </div>

        <div>
          <label className="text-[1rem] text-[#696F79] mb-2.5 block">
            Email (optional)
          </label>
          <input
            type="email"
            name="email_optional"
            value={data.email_optional || ""}
            onChange={handleInputChange}
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
            placeholder="Enter email address"
          />
        </div>

        <div>
          <label className="text-[1rem] text-[#696F79] mb-2.5 block">
            Portfolio URL
          </label>
          <input
            type="url"
            name="portfolio_url"
            value={data.portfolio_url || ""}
            onChange={handleInputChange}
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
            placeholder="Url"
          />
        </div>

        <div>
          <label className="text-[1rem] text-[#696F79] mb-2.5 block">
            Website
          </label>
          <input
            type="url"
            name="website_url"
            value={data.website_url || ""}
            onChange={handleInputChange}
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
            placeholder="Url"
          />
        </div>
      </div>

      <div className="pt-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-[1.5rem] font-semibold">Social Media</h3>
          <button
            onClick={addSocialLink}
            disabled={availablePlatforms.length === 0}
            className={`flex items-center gap-1 ${availablePlatforms.length === 0 ? 'text-gray-400' : 'text-[#FC6935]'}`}
          >
            <FaPlus />
            <span>Add Social Link</span>
          </button>
        </div>

        <div className="space-y-4">
          {data.social_media_urls?.map((social, index) => {
            const optionsForThisItem = [
              social.platform,
              ...availablePlatforms
            ].filter(Boolean);

            return (
              <div key={index} className="flex items-center gap-4">
                <Select
                  value={{ value: social.platform, label: social.platform }}
                  onChange={(selected) => handleSocialMediaChange(index, 'platform', selected?.value)}
                  options={optionsForThisItem.map(platform => ({
                    value: platform,
                    label: platform
                  }))}
                  className="w-[12rem] react-select-container"
                  classNamePrefix="select"
                />
                <input
                  type="url"
                  value={social.link || ""}
                  onChange={(e) => handleSocialMediaChange(index, 'link', e.target.value)}
                  className="flex-1 py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                  placeholder="Url"
                />
                <button
                  onClick={() => removeSocialLink(index)}
                  className="text-red-500 p-2 rounded-full hover:bg-red-50"
                  title="Remove this social media link"
                >
                  <FaTimes />
                </button>
              </div>
            );
          })}
        </div>

        {availablePlatforms.length === 0 && data.social_media_urls?.length > 0 && (
          <p className="text-sm text-gray-500 mt-2">
            All available social media platforms have been added.
          </p>
        )}
      </div>

      <div className="flex justify-between mt-8">
        <button
          onClick={onPrevious}
          className="border border-[#FC6935] text-[#FC6935] rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
        >
          Previous
        </button>
        <button
          onClick={onSubmit}
          className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
        >
          Submit
        </button>
      </div>
    </div>
  );
};

export default ContactSection;