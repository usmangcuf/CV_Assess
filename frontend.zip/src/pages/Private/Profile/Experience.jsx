import React, { useState } from "react";
import { FaPlus, FaTrash, FaEdit } from "react-icons/fa";
import Card from "./Card";
const Experience = () => {
  const [experience, setExperience] = useState([
    {
      id: 1,
      title: "Microsoft Certified: Azure Fundamentals",
      company: "Micosoft",
      startDate: "Jan 2, 23",
      endDate: "Mar 2, 24",
      description: "Azure Fundamentals certification from Microsoft",
    },
  ]);

  const addExperience = () => {
    setExperience([
      ...experience,
      {
        id: experience.length + 1,
        title: "Reacact JS",
        company: "Meta",
        startDate: "Dec 2, 23",
        endDate: "Feb 2, 25",
        description: "React JS certification from Meta",
      },
    ]);
  };

  const removeExperience = (id) => {
    setExperience(experience.filter((cer) => cer.id !== id));
  };

  return (
    <div className="">
      <div className="flex justify-between items-start mt-9 mb-6">
        <h1 className="text-2xl font-semibold text-[#171725]">
          Other Experience
        </h1>
        <button
          onClick={addExperience}
          className="flex items-center gap-1 cursor-pointer"
        >
          <FaPlus className="text-[#FC6935]" />
          <span className="text-[1rem] font-semibold text-[#FC6935]">
            Add Experience
          </span>
        </button>
      </div>

      {experience.map((edu) => (
        <div key={edu.id}>
          <Card data={edu} remove={removeExperience} isWorkExperiance={true} />
        </div>
      ))}

      <div className="flex justify-end">
        <button
          onClick={addExperience}
          className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer mt-4"
        >
          + Add
        </button>
      </div>

      {experience.length === 0 && (
        <div className="p-8 border-2 border-dashed border-[#E5E7EB] rounded-lg text-center">
          <p className="text-[#696F79]">No Experience added yet</p>
          <button
            onClick={addExperience}
            className="mt-2 text-[#FC6935] font-medium flex items-center mx-auto"
          >
            <FaPlus className="mr-1" /> Add Experience
          </button>
        </div>
      )}
    </div>
  );
};

export default Experience;
