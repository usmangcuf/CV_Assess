import React, { useEffect } from "react";
import { Modal, Box, Typography } from "@mui/material";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { IoIosClose } from "react-icons/io";
import Select from "react-select";

const AddEntryModal = ({
    open,
    handleClose,
    onSave,
    type = "education",
    editData,
    isEditing,
    isWorkExperience
}) => {
    const baseSchema = {
        description: yup.string(),
    };

    const educationSchema = {
        institute: yup.string().required('Institute name is required'),
        degree: yup.string().required("Degree is required"),
        field_of_study: yup.string().required("Field of study is required"),
        start_date: yup.date().required("Start date is required"),
        end_date: yup.date()
            .nullable()
            .transform((curr, orig) => orig === "" ? null : curr)
            .when('is_present', {
                is: false,
                then: (schema) => schema.required('End date is required')
                    .test('date-order', 'End date must be shorter than start date', function(value) {
                        return value && this.parent.start_date ? value > this.parent.start_date : true;
                    }),
            }),
        is_present: yup.boolean(),
    };

    const certificationSchema = {
        institute: yup.string().required('Issuing organization is required'),
        title: yup.string().required("Certification title is required"),
        doc_url: yup.string().url("Must be a valid URL").required("Document URL is required"),
    };

    const workExperienceSchema = {
        company: yup.string().required("Company name is required"),
        job_title: yup.string().required("Job title is required"),
        employment_type: yup.string().required("Employment type is required"),
        start_date: yup.date().required("Start date is required"),
        end_date: yup.date()
            .nullable()
            .transform((curr, orig) => orig === "" ? null : curr)
            .when('is_present', {
                is: false,
                then: (schema) => schema.required('End date is required')
                    .test('date-order', 'End date must be after start date', function(value) {
                        return value && this.parent.start_date ? value > this.parent.start_date : true;
                    }),
            }),
        is_present: yup.boolean(),
    };

    let formSchema;
    if (isWorkExperience) {
        formSchema = yup.object().shape({
            ...baseSchema,
            ...workExperienceSchema,
        });
    } else {
        formSchema = yup.object().shape({
            ...baseSchema,
            ...(type === 'education' ? educationSchema : certificationSchema),
        });
    }

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        watch,
        setValue,
        control,
    } = useForm({
        resolver: yupResolver(formSchema),
        defaultValues: isWorkExperience || type === 'education' ? {
            is_present: false,
            employment_type: 'Full-time'
        } : {},
    });

    const isPresent = watch("is_present");

    useEffect(() => {
        if (isEditing && editData) {
            const formattedData = { ...editData };
            if (editData.start_date) {
                formattedData.start_date = new Date(editData.start_date).toISOString().split('T')[0];
            }
            if (editData.end_date) {
                formattedData.end_date = new Date(editData.end_date).toISOString().split('T')[0];
            }
            reset(formattedData);
        } else {
            reset(isWorkExperience || type === 'education' ? {
                is_present: false,
                employment_type: 'Full-time'
            } : {});
        }
    }, [open, editData, isEditing, type, reset, isWorkExperience]);

    const onSubmit = (data) => {
        onSave(data);
        handleClose();
    };

    const getModalTitle = () => {
        if (isWorkExperience) {
            return isEditing ? "Edit Work Experience" : "Add Work Experience";
        }
        return isEditing ? `Edit ${type === 'education' ? 'Education' : 'Certification'}`
            : `Add ${type === 'education' ? 'Education' : 'Certification'}`;
    };

    return (
        <Modal
            open={open}
            onClose={handleClose}
            aria-labelledby={`${type}-modal-title`}
        >
            <Box
                sx={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    width: "50%",
                    bgcolor: "background.paper",
                    border: "1px solid #ccc",
                    p: 4,
                    borderRadius: 2,
                }}
            >
                <div className="flex justify-between items-center">
                    <Typography variant="h5" component="h2">
                        {getModalTitle()}
                    </Typography>
                    <button onClick={handleClose} className="text-gray-500 hover:text-gray-700 cursor-pointer">
                        <IoIosClose fontSize="28px" />
                    </button>
                </div>

                <form className="flex flex-col gap-4 mt-4" onSubmit={handleSubmit(onSubmit)}>
                    {isWorkExperience ? (
                        <>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="flex gap-1 flex-col">
                                    <input
                                        type="text"
                                        placeholder="Company Name"
                                        {...register("company")}
                                        className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                    />
                                    {errors.company && (
                                        <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                            {errors.company.message}
                                        </p>
                                    )}
                                </div>

                                <div className="flex gap-1 flex-col">
                                    <input
                                        type="text"
                                        placeholder="Job Title"
                                        {...register("job_title")}
                                        className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                    />
                                    {errors.job_title && (
                                        <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                            {errors.job_title.message}
                                        </p>
                                    )}
                                </div>
                            </div>

                            <div className="flex gap-1 flex-col">
                                <Select
                                    {...register("employment_type")}
                                    options={[
                                        { value: "Full-time", label: "Full-time" },
                                        { value: "Part-time", label: "Part-time" },
                                        { value: "Contract", label: "Contract" },
                                        { value: "Freelance", label: "Freelance" },
                                        { value: "Internship", label: "Internship" },
                                        { value: "Self-employed", label: "Self-employed" }
                                    ]}
                                    className="react-select-container"
                                    classNamePrefix="react-select"
                                />
                                {errors.employment_type && (
                                    <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                        {errors.employment_type.message}
                                    </p>
                                )}
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="flex gap-1 flex-col">
                                    <label className="text-sm text-gray-600 pl-4">Start Date</label>
                                    <input
                                        type="date"
                                        {...register("start_date")}
                                        className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                    />
                                    {errors.start_date && (
                                        <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                            {errors.start_date.message}
                                        </p>
                                    )}
                                </div>

                                {!isPresent && (
                                    <div className="flex gap-1 flex-col">
                                        <label className="text-sm text-gray-600 pl-4">End Date</label>
                                        <input
                                            type="date"
                                            {...register("end_date")}
                                            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                        />
                                        {errors.end_date && (
                                            <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                                {errors.end_date.message}
                                            </p>
                                        )}
                                    </div>
                                )}
                            </div>

                            <div className="flex items-center gap-2">
                                <input
                                    type="checkbox"
                                    id="is_present"
                                    {...register("is_present")}
                                    onChange={(e) => {
                                        register("is_present").onChange(e);
                                        if (e.target.checked) {
                                            setValue("end_date", null);
                                        }
                                    }}
                                    className="h-4 w-4 text-[#FC6935] rounded focus:ring-[#FC6935]"
                                />
                                <label htmlFor="is_present" className="text-sm text-gray-600">
                                    I currently work here
                                </label>
                            </div>
                        </>
                    ) : type === 'education' ? (
                        <>
                            <div className="flex gap-1 flex-col">
                                <input
                                    type="text"
                                    placeholder="Institute Name"
                                    {...register("institute")}
                                    className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                />
                                {errors.institute && (
                                    <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                        {errors.institute.message}
                                    </p>
                                )}
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="flex gap-1 flex-col">
                                    <input
                                        type="text"
                                        placeholder="Degree (e.g. Bachelor's)"
                                        {...register("degree")}
                                        className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                    />
                                    {errors.degree && (
                                        <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                            {errors.degree.message}
                                        </p>
                                    )}
                                </div>

                                <div className="flex gap-1 flex-col">
                                    <input
                                        type="text"
                                        placeholder="Field of Study"
                                        {...register("field_of_study")}
                                        className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                    />
                                    {errors.field_of_study && (
                                        <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                            {errors.field_of_study.message}
                                        </p>
                                    )}
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="flex gap-1 flex-col">
                                    <label className="text-sm text-gray-600 pl-4">Start Date</label>
                                    <input
                                        type="date"
                                        {...register("start_date")}
                                        className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                    />
                                    {errors.start_date && (
                                        <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                            {errors.start_date.message}
                                        </p>
                                    )}
                                </div>

                                {!isPresent && (
                                    <div className="flex gap-1 flex-col">
                                        <label className="text-sm text-gray-600 pl-4">End Date</label>
                                        <input
                                            type="date"
                                            {...register("end_date")}
                                            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                        />
                                        {errors.end_date && (
                                            <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                                {errors.end_date.message}
                                            </p>
                                        )}
                                    </div>
                                )}
                            </div>

                            <div className="flex items-center gap-2">
                                <input
                                    type="checkbox"
                                    id="is_present"
                                    {...register("is_present")}
                                    onChange={(e) => {
                                        register("is_present").onChange(e);
                                        if (e.target.checked) {
                                            setValue("end_date", null);
                                        }
                                    }}
                                    className="h-4 w-4 text-[#FC6935] rounded focus:ring-[#FC6935]"
                                />
                                <label htmlFor="is_present" className="text-sm text-gray-600">
                                    I currently study here
                                </label>
                            </div>
                        </>
                    ) : (
                        <>
                            <div className="flex gap-1 flex-col">
                                <input
                                    type="text"
                                    placeholder="Issuing Organization"
                                    {...register("institute")}
                                    className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                />
                                {errors.institute && (
                                    <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                        {errors.institute.message}
                                    </p>
                                )}
                            </div>

                            <div className="flex gap-1 flex-col">
                                <input
                                    type="text"
                                    placeholder="Certification Title"
                                    {...register("title")}
                                    className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                />
                                {errors.title && (
                                    <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                        {errors.title.message}
                                    </p>
                                )}
                            </div>

                            <div className="flex gap-1 flex-col">
                                <input
                                    type="url"
                                    placeholder="Certificate URL"
                                    {...register("doc_url")}
                                    className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                                />
                                {errors.doc_url && (
                                    <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                                        {errors.doc_url.message}
                                    </p>
                                )}
                            </div>
                        </>
                    )}

                    <div className="flex gap-1 flex-col">
                        <textarea
                            placeholder="Description (Optional)"
                            {...register("description")}
                            rows={3}
                            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
                        />
                    </div>

                    <button
                        type="submit"
                        className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
                    >
                        Save {isWorkExperience ? 'Work Experience' : (type === 'education' ? 'Education' : 'Certification')}
                    </button>
                </form>
            </Box>
        </Modal>
    );
};

export default AddEntryModal;