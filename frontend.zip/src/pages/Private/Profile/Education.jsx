import React, { useEffect, useState } from "react";
import { FaPlus } from "react-icons/fa";
import Card from "./Card";
import Certificate from "./Certificate";
import AddEntryModal from "./AddEntryModal";

const EducationSection = ({
  data,
  certificateData,
  updateData,
  onNext,
  onPrevious,
}) => {
  const [certificates, setCertificates] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState('education');
  const [isEditing, setIsEditing] = useState(false);
  const [editingIndex, setEditingIndex] = useState(null);

  const realEducations = (data?.educationList || []).filter(
    edu => edu.institute || edu.title
  );
  const hasRealEducations = realEducations.length > 0;

  useEffect(() => {
    const validCertificates = (certificateData || []).filter(
      cert => cert.title || cert.institute
    );
    setCertificates(validCertificates);
  }, [certificateData]);

  const handleEditEducation = (index) => {
    setModalType('education');
    setEditingIndex(index);
    setIsEditing(true);
    setModalOpen(true);
  };

  const handleEditCertificate = (index) => {
    setModalType('certification');
    setEditingIndex(index);
    setIsEditing(true);
    setModalOpen(true);
  };

  const handleSave = (newData) => {
    if (modalType === 'education') {
      if (!newData.institute && !newData.title) {
        alert('Please provide at least an institute or title');
        return;
      }

      const updatedEducations = isEditing
        ? realEducations.map((edu, i) => (i === editingIndex ? newData : edu))
        : [...realEducations, newData];

      updateData({ educationList: updatedEducations });
    } else {
      const updatedCertificates = isEditing
        ? certificates.map((cert, i) => (i === editingIndex ? newData : cert))
        : [...certificates, newData];

      setCertificates(updatedCertificates);
      updateData({ certifications: updatedCertificates });
    }

    setModalOpen(false);
    setIsEditing(false);
    setEditingIndex(null);
  };

  const handleAddEducation = () => {
    setModalType('education');
    setIsEditing(false);
    setEditingIndex(null);
    setModalOpen(true);
  };

  const handleAddCertification = () => {
    setModalType('certification');
    setIsEditing(false);
    setEditingIndex(null);
    setModalOpen(true);
  };

  const removeEducation = (indexToRemove) => {
    const updatedEducations = realEducations.filter((_, index) => index !== indexToRemove);
    updateData({ educationList: updatedEducations });
  };

  const removeCertification = (indexToRemove) => {
    const updatedCertificates = certificates.filter((_, index) => index !== indexToRemove);
    setCertificates(updatedCertificates);
    updateData({ certifications: updatedCertificates });
  };

  return (
    <div className="">
      <div className="flex justify-between items-start mb-6">
        <h1 className="text-2xl font-semibold text-[#171725]">Education</h1>
        <button
          onClick={handleAddEducation}
          className="flex items-center gap-1 cursor-pointer"
        >
          <FaPlus className="text-[#FC6935]" />
          <span className="text-[1rem] font-semibold text-[#FC6935]">
            Add Education
          </span>
        </button>
      </div>

      {hasRealEducations ? (
        realEducations.map((edu, i) => (
          <div key={i}>
            <Card
              data={edu}
              isEditing={isEditing}
              remove={() => removeEducation(i)}
              onEdit={() => handleEditEducation(i)}
            />
          </div>
        ))
      ) : (
        <div className="p-8 border-2 border-dashed border-[#E5E7EB] rounded-lg text-center">
          <p className="text-[#696F79]">No education information available</p>
          <button
            onClick={handleAddEducation}
            className="mt-2 text-[#FC6935] font-medium flex items-center mx-auto cursor-pointer"
          >
            <FaPlus className="mr-1" /> Add Education
          </button>
        </div>
      )}

      <div className="flex justify-between items-start mb-6 mt-8">
        <h1 className="text-2xl font-semibold text-[#171725]">Certifications</h1>
        <button
          onClick={handleAddCertification}
          className="flex items-center gap-1 cursor-pointer"
        >
          <FaPlus className="text-[#FC6935]" />
          <span className="text-[1rem] font-semibold text-[#FC6935]">
            Add Certification
          </span>
        </button>
      </div>

      <Certificate
        data={certificates}
        onAddCertificate={handleAddCertification}
        onRemoveCertificate={(index) => removeCertification(index)}
        onEditCertificate={(index) => handleEditCertificate(index)}
      />

      <div className="flex justify-between mt-8">
        <button
          onClick={onPrevious}
          className="border border-[#FC6935] text-[#FC6935] rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
        >
          Previous
        </button>
        <button
          onClick={onNext}
          className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
        >
          Next
        </button>
      </div>

      <AddEntryModal
        open={modalOpen}
        handleClose={() => {
          setModalOpen(false);
          setIsEditing(false);
          setEditingIndex(null);
        }}
        onSave={handleSave}
        type={modalType}
        editData={
          isEditing
            ? modalType === 'education'
              ? realEducations[editingIndex]
              : certificates[editingIndex]
            : null
        }
        isEditing={isEditing}
      />
    </div>
  );
};

export default EducationSection;