import React, { useEffect, useState } from "react";
import Options from "../../myJobs/Options";
import PersonalInformation from "./PersonalInformation";
import Education from "./Education";
import Work from "./Work";
import Contact from "./Contact";
import { api } from "../../utlis/customAPI";
import {
  apiToFrontendFormat,
  frontendToApiFormat,
  getInitialProfileData,
} from "./helper/index";
import toast from "react-hot-toast";

export default function Profile({ setProgress }) {
  const [selectedOption, setSelectedOption] = useState("Personal Information");
  const options = [
    "Personal Information",
    "Education & Certificate",
    "Work & Experience",
    "Contact Information",
  ];
  const token = localStorage.getItem("ai-token");
  const [profileData, setProfileData] = useState(getInitialProfileData());

  useEffect(() => {
    if (token) {
      setProgress(20);
      api
        .get("/candidate/get-profile")
        .then(({ data }) => {
          const formattedData = apiToFrontendFormat(data);
          setProfileData(formattedData);
          setProgress(59);
        })
        .catch((error) => {
          console.log(error);
          setProfileData(getInitialProfileData());
        })
        .finally(() => setProgress(100));
    }
  }, [token]);

  const updateProfileData = (section, newData) => {
    setProfileData((prev) => {
      if (typeof newData === "object" && !Array.isArray(newData)) {
        return {
          ...prev,
          [section]: {
            ...prev[section],
            ...newData,
          },
        };
      }
      return {
        ...prev,
        [section]: newData,
      };
    });
  };
  const handleNext = () => {
    const currentIndex = options.indexOf(selectedOption);
    if (currentIndex < options.length - 1) {
      setSelectedOption(options[currentIndex + 1]);
    }
  };

  const handlePrevious = () => {
    const currentIndex = options.indexOf(selectedOption);
    if (currentIndex > 0) {
      setSelectedOption(options[currentIndex - 1]);
    }
  };

  const handleSubmit = async () => {
    setProgress(30);
    const apiPayload = frontendToApiFormat(profileData);

    await api
      .put("/candidate/update-profile", apiPayload)
      .then((res) => {
        const user = JSON.parse(localStorage.getItem("ai-user"));
        console.log("user", user);
        const updateUser = {
          ...user,
          personalInfo: {
            ...user.personalInfo,
            image_url: res?.data?.profile?.personalInformation?.image_url,
          },
        };
        console.log(res?.data?.profile?.personalInformation?.image_url);
        localStorage.setItem("ai-user", JSON.stringify(updateUser));
        const userUpdate = JSON.parse(localStorage.getItem("ai-user"));
        console.log("userUpdate", userUpdate);

        setProgress(70);
        toast.success("Profile updated successfully");
      })
      .catch((error) => {
        console.error(error);
        toast.error("Failed to update profile");
      })
      .finally(() => setProgress(100));
  };

  const selectedSection = () => {
    switch (selectedOption) {
      case "Personal Information":
        return (
          <PersonalInformation
            data={profileData.personalInfo}
            updateData={(newData) => updateProfileData("personalInfo", newData)}
            onNext={handleNext}
            isFirst={true}
          />
        );
      case "Education & Certificate":
        return (
          <Education
            data={profileData}
            certificateData={profileData.certifications}
            updateData={(updates) => {
              setProfileData((prev) => ({
                ...prev,
                ...updates,
              }));
            }}
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        );
      case "Work & Experience":
        return (
          <Work
            data={profileData.workHistory}
            updateData={(newData) => updateProfileData("workHistory", newData)}
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        );
      default:
        return (
          <Contact
            data={profileData.contactInfo}
            updateData={(newData) => updateProfileData("contactInfo", newData)}
            onSubmit={handleSubmit}
            onPrevious={handlePrevious}
            isLast={true}
          />
        );
    }
  };

  return (
    <div className="family-outfit mt-[5.8rem]">
      <div className="px-20 w-full flex gap-16 min-h-screen">
        <div className="w-[280px] border-r-3 border-[#F7F7F7] min-h-screen">
          <div className="fixed h-screen">
            <div className="py-12">
              <Options
                options={options}
                selectedOption={selectedOption}
                setSelectedOption={setSelectedOption}
              />
            </div>
          </div>
        </div>
        <div className="flex-1 ml-8 min-h-screen">
          <div className="py-12">{selectedSection()}</div>
        </div>
      </div>
    </div>
  );
}
