export const getInitialProfileData = () => ({
  personalInfo: {
    full_name: "",
    email: "",
    image_url: "",
    date_of_birth: "",
    gender: "",
    address: "",
    pay_rate: {
      period: "hourly",
      currency: "USD",
      amount: 0,
    },
    language: "",
    about: "",
    resume_url: "",
  },
  educationList: [
    {
      institute: "",
      degree: "",
      field_of_study: "",
      start_date: "",
      end_date: "",
      is_present: false,
      description: "",
    },
  ],
  certifications: [
    {
      institute: "",
      title: "",
      doc_url: "",
      description: "",
    },
  ],
  workHistory: [
    {
      company: "",
      job_title: "",
      job_type: "",
      description: "",
      end_date: "",
      start_date: "",
      is_present: false,
      city: "",
    },
  ],
  contactInfo: {
    phone_num: "",
    phone_num_optional: "",
    email: "",
    email_optional: "",
    portfolio_url: "",
    website_url: "",
    social_media_urls: [
      { platform: "LinkedIn", link: "" },
      { platform: "GitHub", link: "" },
    ],
  },
});

export const apiToFrontendFormat = (apiData) => {
  return {
    personalInfo: {
      full_name: apiData.personalInfo?.full_name || "",
      email: apiData.personalInfo?.email || "",
      image_url: apiData.personalInfo?.image_url || "",
      date_of_birth: apiData.personalInfo?.date_of_birth || "",
      gender: apiData.personalInfo?.gender || "",
      address: apiData.personalInfo?.address || "",
      pay_rate: {
        period: apiData.personalInfo?.pay_rate?.period || "hourly",
        currency: apiData.personalInfo?.pay_rate?.currency || "USD",
        amount: apiData.personalInfo?.pay_rate?.amount || 0,
      },
      language: apiData.personalInfo?.language || "",
      about: apiData.personalInfo?.about || "",
      resume_url: apiData.personalInfo?.resume_url || "",
    },
    educationList: apiData.educationList?.length
      ? apiData.educationList
      : [
          {
            institute: "",
            degree: "",
            field_of_study: "",
            start_date: "",
            end_date: "",
            is_present: false,
            description: "",
          },
        ],
    certifications: apiData.certifications?.length
      ? apiData.certifications
      : [
          {
            institute: "",
            title: "",
            doc_url: "",
            description: "",
          },
        ],
    workHistory: apiData.workHistory?.length
      ? apiData.workHistory
      : [
          {
            company: "",
            job_title: "",
            description: "",
            end_date: "",
            start_date: "",
            is_present: false,
            job_type: "",
            city: "",
          },
        ],
    contactInfo: {
      phone_num: apiData.contactInfo?.phone_num || "",
      phone_num_optional: apiData.contactInfo?.phone_num_optional || "",
      email: apiData.contactInfo?.email || "",
      email_optional: apiData.contactInfo?.email_optional || "",
      portfolio_url: apiData.contactInfo?.portfolio_url || "",
      website_url: apiData.contactInfo?.website_url || "",
      social_media_urls: apiData.contactInfo?.social_media_urls || [
        { platform: "LinkedIn", link: "" },
        { platform: "GitHub", link: "" },
      ],
    },
  };
};

export const frontendToApiFormat = (frontendData) => {
  return {
    personalInfo: {
      full_name: frontendData.personalInfo.full_name,
      email: frontendData.personalInfo.email,
      image_url: frontendData.personalInfo.image_url,
      date_of_birth: frontendData.personalInfo.date_of_birth,
      gender: frontendData.personalInfo.gender,
      address: frontendData.personalInfo.address,
      pay_rate: {
        period: frontendData.personalInfo.pay_rate.period,
        currency: frontendData.personalInfo.pay_rate.currency,
        amount: Number(frontendData.personalInfo.pay_rate.amount) || 0,
      },
      language: frontendData.personalInfo.language,
      about: frontendData.personalInfo.about,
      resume_url: frontendData.personalInfo.resume_url,
    },
    educationList: frontendData.educationList.filter(
      (edu) => edu.institute || edu.degree || edu.field_of_study
    ),
    certifications: frontendData.certifications.filter(
      (cert) => cert.institute || cert.title
    ),
    contactInfo: {
      phone_num: frontendData.contactInfo.phone_num,
      phone_num_optional: frontendData.contactInfo.phone_num_optional,
      email: frontendData.contactInfo.email,
      email_optional: frontendData.contactInfo.email_optional,
      portfolio_url: frontendData.contactInfo.portfolio_url,
      website_url: frontendData.contactInfo.website_url,
      social_media_urls: frontendData.contactInfo.social_media_urls.filter(
        (social) => social.link
      ),
    },
    workHistory: frontendData.workHistory.filter(
      (work) =>
        work.job_title ||
        work.job_type ||
        work.description ||
        work.company ||
        work.city ||
        work.start_date ||
        work.end_date ||
        work.is_present
    ),
  };
};

export const getInitialProfileDataCompany = () => ({
  personalInfo: {
    full_name: "",
    email: "",
    image_url: "",
    joining_date: "",
    address: "",
    language: "",
    about_company: "",
    team_size: "",
  },
  contactInfo: {
    phone_num: "",
    phone_num_optional: "",
    email: "",
    email_optional: "",
    website_url: "",
    social_media_urls: [
      { platform: "LinkedIn", link: "" },
      { platform: "GitHub", link: "" },
    ],
  },
});

export const apiToFrontendFormatCompany = (apiData) => {
  return {
    personalInfo: {
      full_name: apiData.personalInfo?.full_name || "",
      email: apiData.personalInfo?.email || "",
      image_url: apiData.personalInfo?.image_url || "",
      joining_date: apiData.personalInfo?.joining_date || "",
      address: apiData.personalInfo?.address || "",
      language: apiData.personalInfo?.language || "",
      about_company: apiData.personalInfo?.about_company || "",
      team_size: apiData.personalInfo?.team_size || "",
    },

    contactInfo: {
      phone_num: apiData.contactInfo?.phone_num || "",
      phone_num_optional: apiData.contactInfo?.phone_num_optional || "",
      email: apiData.contactInfo?.email || "",
      email_optional: apiData.contactInfo?.email_optional || "",
      website_url: apiData.contactInfo?.website_url || "",
      social_media_urls: apiData.contactInfo?.social_media_urls || [
        { platform: "LinkedIn", link: "" },
        { platform: "GitHub", link: "" },
      ],
    },
  };
};

export const frontendToApiFormatCompany = (frontendData) => {
  return {
    personalInfo: {
      full_name: frontendData.personalInfo.full_name,
      email: frontendData.personalInfo.email,
      image_url: frontendData.personalInfo.image_url,
      joining_date: frontendData.personalInfo.joining_date,
      address: frontendData.personalInfo.address,
      language: frontendData.personalInfo.language,
      about_company: frontendData.personalInfo.about_company,
      team_size: frontendData.personalInfo.team_size,
    },
    contactInfo: {
      phone_num: frontendData.contactInfo.phone_num,
      phone_num_optional: frontendData.contactInfo.phone_num_optional,
      email: frontendData.contactInfo.email,
      email_optional: frontendData.contactInfo.email_optional,
      website_url: frontendData.contactInfo.website_url,
      social_media_urls: frontendData.contactInfo.social_media_urls.filter(
        (social) => social.link
      ),
    },
  };
};
