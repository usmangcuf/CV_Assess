import React from "react";
import { FaPlus, FaTrash, FaEdit } from "react-icons/fa";
import education from "../../../assets/img/education.svg";
import { formatDate } from "../../utlis/helper";

const Card = ({ data, remove, isWorkExperience, certificate, onEdit }) => {
  return (
    <div className="border border-[#F7F7F7] rounded-[24px] px-[1.5rem] py-[1.6rem] mb-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="flex items-center justify-center bg-[#F6F3EA] p-3.5 rounded-full w-fit">
            <img src={education} alt="" />
          </div>
          <div>
            <h3 className="text-[1.25rem] font-medium">
              {isWorkExperience
                ? data.job_title
                : certificate
                  ? data?.title
                  : data?.field_of_study}
            </h3>
            <p className="text-[#696F79] text-[1rem]">
              {data?.degree ? `${data.degree} - ` : ""}{" "}
              {isWorkExperience ? data.company : data?.institute}
            </p>
          </div>
        </div>
        <div className="flex items-center">
          <span className="text-[#707070] text-[1rem]">
            {formatDate(data?.start_date)} - {formatDate(data?.end_date)}
          </span>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => onEdit && onEdit()}
            className="text-[#FC6935] border border-[#FC6935] rounded-full p-3 cursor-pointer"
          >
            <FaEdit />
          </button>
          <button
            className="text-[#FC6935] border border-[#FC6935] rounded-full p-3 cursor-pointer"
            onClick={() => remove(data._id)}
          >
            <FaTrash />
          </button>
        </div>
      </div>

      <p className="text-[#696F79] mt-4 text-[1rem]">{data?.description}</p>
    </div>
  );
};
export default Card;
