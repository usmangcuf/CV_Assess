import React from "react";
import { FaPlus, FaTrash, FaEdit } from "react-icons/fa";
import Card from "./Card";

const Certificate = ({ data, onAddCertificate, onRemoveCertificate, onEditCertificate }) => {
  const validCertificates = Array.isArray(data)
    ? data.filter(cert => cert.title || cert.institute)
    : [];

  return (
    <div className="">
      {validCertificates.length > 0 ? (
        validCertificates.map((cert, i) => (
          <div key={i}>
            <Card
              data={cert}
              remove={() => onRemoveCertificate(i)}
              onEdit={() => onEditCertificate(i)}
              certificate={true}
            />
          </div>
        ))
      ) : (
        <div className="p-8 border-2 border-dashed border-[#E5E7EB] rounded-lg text-center">
          <p className="text-[#696F79]">No certificates available</p>
          <button
            onClick={onAddCertificate}
            className="mt-2 text-[#FC6935] font-medium flex items-center mx-auto cursor-pointer"
          >
            <FaPlus className="mr-1" /> Add Certificate
          </button>
        </div>
      )}
    </div>
  );
};

export default Certificate;