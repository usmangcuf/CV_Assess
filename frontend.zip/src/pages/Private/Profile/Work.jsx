import React, { useState } from "react";
import { FaPlus } from "react-icons/fa";
import Card from "./Card";
import AddEntryModal from "./AddEntryModal";

const WorkSection = ({ data, updateData, onNext, onPrevious }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingIndex, setEditingIndex] = useState(null);

  const realWorkHistory = (data || []).filter(
    work => work.company || work.title
  );
  const hasWorkHistory = realWorkHistory.length > 0;

  const handleAddWork = () => {
    setIsEditing(false);
    setEditingIndex(null);
    setModalOpen(true);
  };

  const handleEditWork = (index) => {
    setEditingIndex(index);
    setIsEditing(true);
    setModalOpen(true);
  };

  const handleSave = (newData) => {
    if (!newData.company && !newData.title) {
      alert('Please provide at least a company or title');
      return;
    }

    const updatedWorkHistory = isEditing
      ? realWorkHistory.map((work, i) => (i === editingIndex ? newData : work))
      : [...realWorkHistory, newData];

    updateData(updatedWorkHistory);
    setModalOpen(false);
    setIsEditing(false);
    setEditingIndex(null);
  };

  const removeWork = (indexToRemove) => {
    const updatedWorkHistory = realWorkHistory.filter((_, index) => index !== indexToRemove);
    updateData(updatedWorkHistory);
  };

  return (
    <div className="">
      <div className="flex justify-between items-start mb-6">
        <h1 className="text-2xl font-semibold text-[#171725]">Work History</h1>
        <button
          onClick={handleAddWork}
          className="flex items-center gap-1 cursor-pointer"
        >
          <FaPlus className="text-[#FC6935]" />
          <span className="text-[1rem] font-semibold text-[#FC6935]">
            Add History
          </span>
        </button>
      </div>

      {hasWorkHistory ? (
        realWorkHistory.map((work, i) => (
          <div key={i}>
            <Card
              data={work}
              isEditing={isEditing}
              remove={() => removeWork(i)}
              onEdit={() => handleEditWork(i)}
              isWorkExperience={true}
            />
          </div>
        ))
      ) : (
        <div className="p-8 border-2 border-dashed border-[#E5E7EB] rounded-lg text-center">
          <p className="text-[#696F79]">No work history added yet</p>
          <button
            onClick={handleAddWork}
            className="mt-2 text-[#FC6935] font-medium flex items-center mx-auto cursor-pointer"
          >
            <FaPlus className="mr-1" /> Add History
          </button>
        </div>
      )}

      <div className="flex justify-between mt-8">
        <button
          onClick={onPrevious}
          className="border border-[#FC6935] text-[#FC6935] rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
        >
          Previous
        </button>
        <button
          onClick={onNext}
          className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
        >
          Next
        </button>
      </div>

      <AddEntryModal
        open={modalOpen}
        handleClose={() => {
          setModalOpen(false);
          setIsEditing(false);
          setEditingIndex(null);
        }}
        onSave={handleSave}
        type="work"
        editData={isEditing ? realWorkHistory[editingIndex] : null}
        isEditing={isEditing}
        isWorkExperience={true}
      />
    </div>
  );
};

export default WorkSection;