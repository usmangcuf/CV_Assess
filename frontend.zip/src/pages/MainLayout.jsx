import React from "react";
import { Outlet, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";

export default function MainLayout({ setProgress, landing, progress }) {
  // const token = localStorage.getItem("ai-token");
  // if (!token) {
  //   return <Navigate to="/login" replace />;
  // }
  return (
    <div>
      <Navbar setProgress={setProgress} landing={landing} progress={progress} />
      <Outlet />
    </div>
  );
}

