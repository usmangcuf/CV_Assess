import React, { useEffect, useState } from "react";
import Search from "../../common/Search";
import Roles from "../../common/Roles";
import JobCard from "../../job/JobCard";
import { api } from "../../utlis/customAPI";
import Filter from "../../components/Filter";

export default function Landing({ setProgress, landing }) {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    setProgress(20);
    api
      .get("/all-jobs")
      .then(({ data }) => {
        setJobs(data);
        setProgress(59);
      })
      .catch((error) => {
        console.log(error);
      })
      .finally(() => {
        setProgress(100);
        setLoading(false);
      });
  }, []);

  return (
    <div className="portal-main family-outfit mt-[5.8rem]">
      <div className="bg-[#F6F3EA]">
        <div className="px-[5rem] py-[2rem] pb-[1.5rem]">
          <h1 className="text-[#000] font-semibold text-[2.25rem] pb-[1.5rem]">
            Find the Career That Fits You
          </h1>
          <Search />
        </div>
      </div>
      <div className="px-[5rem] mt-[1.5rem] mb-[1.5rem]">
        <Roles loading={loading} />
        <div className="mt-[2.25rem] flex gap-[1.5rem] w-full">
          <di className="jobs w-[75%]">
            <h1 className="text-[#000] font-semibold text-[2.25rem]">
              Recommended Jobs For You!
            </h1>
            <div className="mt-[1.5rem]">
              <JobCard data={jobs?.jobs} loading={loading} landing={landing} />
            </div>
          </di>
          <di className="w-[25%]">
            <Filter />
          </di>
        </div>
      </div>
    </div>
  );
}
