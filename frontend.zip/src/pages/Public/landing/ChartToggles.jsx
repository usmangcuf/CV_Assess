import React from 'react';
import './style.css';

const ChartToggles = ({
  showApplied,
  setShowApplied,
  showInterviewed,
  setShowInterviewed,
  showRejected,
  setShowRejected,
}) => (
  <div className="flex gap-8 ml-0 sm:ml-4 items-center">
    {/* Applied Jobs Toggle */}
    <div className="flex items-center gap-2">
      <span className={`font-semibold text-[1rem] ${showApplied ? 'text-gray-900' : 'text-gray-400'}`}>Applied Jobs</span>
      <label className="switch">
        <input
          type="checkbox"
          checked={showApplied}
          onChange={() => setShowApplied(!showApplied)}
        />
        <span className="slider"></span>
      </label>
    </div>
    {/* Interviewed Toggle */}
    <div className="flex items-center gap-2">
      <span className={`font-semibold text-[1rem] ${showInterviewed ? 'text-gray-900' : 'text-gray-400'}`}>Interviewed</span>
      <label className="switch">
        <input
          type="checkbox"
          checked={showInterviewed}
          onChange={() => setShowInterviewed(!showInterviewed)}
        />
        <span className="slider"></span>
      </label>
    </div>
    {/* Rejected Toggle */}
    <div className="flex items-center gap-2">
      <span className={`font-semibold text-[1rem] ${showRejected ? 'text-gray-900' : 'text-gray-400'}`}>Rejected</span>
      <label className="switch">
        <input
          type="checkbox"
          checked={showRejected}
          onChange={() => setShowRejected(!showRejected)}
        />
        <span className="slider"></span>
      </label>
    </div>
  </div>
);

export default ChartToggles;