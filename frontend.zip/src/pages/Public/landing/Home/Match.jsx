import React, { useState } from "react";
import Select from "react-select";
import { useNavigate } from "react-router-dom";
import {
  employmentTypes,
  jobLocationOptions,
} from "../../../json/jobFormUtils";

const SearchSection = () => {
  const navigate = useNavigate();
  const [keyword, setKeyword] = useState("");
  const [location, setLocation] = useState(null); // object with value/label
  const [jobType, setJobType] = useState(null); // object with value/label

  const handleSubmit = () => {
    const params = new URLSearchParams();
    if (keyword.trim()) params.append("keyword", keyword.trim());
    if (location) params.append("address", location.trim());
    if (jobType) params.append("job_type", jobType.value);

    navigate(`/view-job?${params.toString()}`);
  };

  return (
    <div className="w-[80%] mx-auto p-10 rounded-[0.5rem] border border-[#ACB2B980] mt-17.5 mb-17.5">
      <h2 className="text-3xl font-bold mb-6 text-center">
        Find Your Perfect Match
      </h2>

      <div className="flex items-end flex-wrap gap-4 ">
        {/* Keyword Field */}
        <div className="family-outfit flex flex-col flex-grow items-baseline gap-[0.6rem]">
          <label className="font-medium text-[1rem] text-[#707070]">
            Keyword
          </label>
          <input
            type="text"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="Enter job title, skill, or keyword"
            className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
          />
        </div>

        {/* Location Field */}
        <div className="family-outfit flex flex-col flex-grow items-baseline gap-[0.6rem]">
          <label className="font-medium text-[1rem] text-[#707070]">
            Location:
          </label>
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Enter Location or City"
            className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
          />
        </div>

        {/* Employment Type Field */}
        <div className="family-outfit flex flex-col flex-grow items-baseline gap-[0.6rem]">
          <label className="font-medium text-[1rem] text-[#707070]">
            Employment Type:
          </label>
          <Select
            className="custom-selector w-full"
            classNamePrefix="react-select"
            options={employmentTypes}
            value={jobType}
            onChange={setJobType}
            placeholder="Select Employment Type"
            isClearable
          />
        </div>

        {/* Submit Button */}
        <button
          onClick={handleSubmit}
          className="bg-[#FC6935] text-white cursor-pointer px-[25px] py-[11px] rounded-full font-semibold flex-grow"
        >
          Find Jobs
        </button>
      </div>
    </div>
  );
};

export default SearchSection;
