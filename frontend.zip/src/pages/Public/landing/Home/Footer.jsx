import React from "react";
import { FaFacebook, FaLinkedin, FaInstagram, FaTwitter } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="mt-2">
      <div className="flex justify-between mb-20">
        <div className="flex flex-col">
          <h2 className="text-lg font-bold">LOGO</h2>
          <p className="mt-3">
            Connecting talented professionals with businesses looking for
            skilled expertise.
          </p>
          <div className="mt-3">
            <div className="max-w-md flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-grow px-4 py-2 border border-[#FC6935] rounded-[3.1rem]"
              />
              <button className="rounded-[3.1rem] text-white bg-[#FC6935] px-[1.5rem] py-[0.6rem] text-[1rem] cursor-pointer">
                Subscribe
              </button>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-28">
          <div>
            <h3 className="text-[1rem] font-semibold mb-4">For Talent</h3>
            <div>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:text-[#FC6935]">
                    Find Work
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-[#FC6935]">
                    Create Profile
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-[#FC6935]">
                    Resources
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div>
            <h3 className="text-[1rem] font-semibold mb-4">For Client</h3>
            <div>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:text-[#FC6935]">
                    Find Talent
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-[#FC6935]">
                    Post a Job
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-[#FC6935]">
                    Success Stories
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div>
            <h3 className="text-[1rem] font-semibold mb-4">Follow Us</h3>
            <div>
              <ul className="space-y-2">
                <li>
                  <a
                    href="#"
                    className="flex items-center gap-2.5 hover:text-[#FC6935]"
                  >
                    <FaFacebook /> Facebook
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center gap-2.5 hover:text-[#FC6935]"
                  >
                    <FaInstagram />
                    Instagram
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center gap-2.5 hover:text-[#FC6935]"
                  >
                    <FaTwitter />
                    Twitter
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center gap-2.5 hover:text-[#FC6935]"
                  >
                    <FaLinkedin />
                    LinkedIn
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div className="border-t">
        <div className="flex justify-between items-center py-5">
          <span>© 2025[ FreelanceHub]. All rights reserved.</span>
          <ul className="flex items-center gap-5">
            <li className="underline hover:text-[#FC6935] cursor-pointer">
              Privacy Policy
            </li>
            <li className="underline hover:text-[#FC6935] cursor-pointer">
              Terms of Service
            </li>
            <li className="underline hover:text-[#FC6935] cursor-pointer">
              Cookies Settings
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
