import React from "react";
import cube from "../../../../assets/img/cube.svg";

export default function TopCategories() {
  return (
    <div className="container mx-auto px-4 py-8 pt-0 flex flex-col">
      <h1 className="text-3xl font-bold mb-2 text-center">Top Categories</h1>
      <span className="text-center block text-[1rem] font-normal mb-10">
        Browse professionals by category and find the perfect match for your
      </span>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="border border-[#ACB2B980] p-4 flex items-start gap-4 rounded-[0.5rem] min-w-0">
          <div className="flex-shrink-0">
            <img src={cube} alt="" className="w-10 h-10" />
          </div>
          <div className="min-w-0">
            <span className="font-bold text-xl block">Development</span>
            <p className="font-normal text-[1rem] mt-1 break-words">
              Web, Mobile & Software Development
            </p>
            <span className="text-[0.9rem] text-normal block mt-1">
              1,240 professionals
            </span>
          </div>
        </div>

        <div className="border border-[#ACB2B980] p-4 flex items-start gap-4 rounded-[0.5rem] min-w-0">
          <div className="flex-shrink-0">
            <img src={cube} alt="" className="w-10 h-10" />
          </div>
          <div className="min-w-0">
            <span className="font-bold text-xl block">Design</span>
            <p className="font-normal text-[1rem] mt-1 break-words">
              UI/UX, Graphic & Brand Design
            </p>
            <span className="text-[0.9rem] text-normal block mt-1">
              1,240 professionals
            </span>
          </div>
        </div>

        <div className="border border-[#ACB2B980] p-4 flex items-start gap-4 rounded-[0.5rem] min-w-0">
          <div className="flex-shrink-0">
            <img src={cube} alt="" className="w-10 h-10" />
          </div>
          <div className="min-w-0">
            <span className="font-bold text-xl block">Marketing</span>
            <p className="font-normal text-[1rem] mt-1 break-words">
              Digital Marketing & Social Media
            </p>
            <span className="text-[0.9rem] text-normal block mt-1">
              1,240 professionals
            </span>
          </div>
        </div>

        <div className="border border-[#ACB2B980] p-4 flex items-start gap-4 rounded-[0.5rem] min-w-0">
          <div className="flex-shrink-0">
            <img src={cube} alt="" className="w-10 h-10" />
          </div>
          <div className="min-w-0">
            <span className="font-bold text-xl block">Content</span>
            <p className="font-normal text-[1rem] mt-1 break-words">
              Writing, Editing & Translation
            </p>
            <span className="text-[0.9rem] text-normal block mt-1">
              1,240 professionals
            </span>
          </div>
        </div>

        <div className="border border-[#ACB2B980] p-4 flex items-start gap-4 rounded-[0.5rem] min-w-0">
          <div className="flex-shrink-0">
            <img src={cube} alt="" className="w-10 h-10" />
          </div>
          <div className="min-w-0">
            <span className="font-bold text-xl block">Business</span>
            <p className="font-normal text-[1rem] mt-1 break-words">
              Finance, Consulting & Management
            </p>
            <span className="text-[0.9rem] text-normal block mt-1">
              1,240 professionals
            </span>
          </div>
        </div>

        <div className="border border-[#ACB2B980] p-4 flex items-start gap-4 rounded-[0.5rem] min-w-0">
          <div className="flex-shrink-0">
            <img src={cube} alt="" className="w-10 h-10" />
          </div>
          <div className="min-w-0">
            <span className="font-bold text-xl block">Video & Audio</span>
            <p className="font-normal text-[1rem] mt-1 break-words">
              Animation, Production & Editing
            </p>
            <span className="text-[0.9rem] text-normal block mt-1">
              1,240 professionals
            </span>
          </div>
        </div>
      </div>
      <button className="rounded-[3.1rem] text-[#FC6935] border border-[#FC6935] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer w-fit m-auto mt-10">
        View All
      </button>
    </div>
  );
}
