import { useNavigate } from "react-router-dom";
import JobType from "../../../../assets/img/job-type.svg";
import Salary from "../../../../assets/img/salary.svg";
import World from "../../../../assets/img/world-black.svg";
export default function TopCategories() {
  const navigate = useNavigate();
  const handleViewAll = () => {
    navigate("/view-job");
  };
  return (
    <div className="container mx-auto px-4 py-8 pt-0 mt-17 flex flex-col">
      <h1 className="text-3xl font-bold mb-2 text-center">Featured Jobs</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-14">
        <div className="bg-[#F6F3EA] p-6 flex items-start gap-4 rounded-3xl min-w-0">
          <div className="min-w-0">
            <span className="font-bold text-xl block">Development</span>
            <div className="flex items-center flex-wrap gap-[.7rem] w-fit mt-[.7rem] gap-y-0">
              <div className="flex items-center gap-[1rem]">
                <img src={World} className="w-[1rem] h-[1rem]" alt="" />
                <span className="text-[1rem] font-medium text-[#707070]">
                  Pakistan
                </span>
              </div>
              <div className="flex items-center gap-[1rem]">
                <img src={JobType} className="w-[1rem] h-[1rem]" alt="" />
                <span className="text-[1rem] font-medium text-[#707070]">
                  Remote
                </span>
              </div>
              <div className="flex items-center gap-[1rem]">
                <img src={Salary} className="w-[1rem] h-[1rem]" alt="" />
                <span className="text-[1rem] font-medium text-[#707070]">
                  $1000 - $1500
                </span>
              </div>
            </div>
            <p className="font-normal text-[1rem] mt-1 break-words">
              A graphic design job involves creating visual content for
              branding, marketing, and digital platforms.
            </p>
          </div>
        </div>
        <div className="bg-[#F6F3EA] p-6 flex items-start gap-4 rounded-3xl min-w-0">
          <div className="min-w-0">
            <span className="font-bold text-xl block">Development</span>
            <div className="flex items-center flex-wrap gap-[.7rem] w-fit mt-[.7rem] gap-y-0">
              <div className="flex items-center gap-[1rem]">
                <img src={World} className="w-[1rem] h-[1rem]" alt="" />
                <span className="text-[1rem] font-medium text-[#707070]">
                  Pakistan
                </span>
              </div>
              <div className="flex items-center gap-[1rem]">
                <img src={JobType} className="w-[1rem] h-[1rem]" alt="" />
                <span className="text-[1rem] font-medium text-[#707070]">
                  Remote
                </span>
              </div>
              <div className="flex items-center gap-[1rem]">
                <img src={Salary} className="w-[1rem] h-[1rem]" alt="" />
                <span className="text-[1rem] font-medium text-[#707070]">
                  $1000 - $1500
                </span>
              </div>
            </div>
            <p className="font-normal text-[1rem] mt-1 break-words">
              A graphic design job involves creating visual content for
              branding, marketing, and digital platforms.
            </p>
          </div>
        </div>
        <div className="bg-[#F6F3EA] p-6 flex items-start gap-4 rounded-3xl min-w-0">
          <div className="min-w-0">
            <span className="font-bold text-xl block">Development</span>
            <div className="flex items-center flex-wrap gap-[.7rem] w-fit mt-[.7rem] gap-y-0">
              <div className="flex items-center gap-[1rem]">
                <img src={World} className="w-[1rem] h-[1rem]" alt="" />
                <span className="text-[1rem] font-medium text-[#707070]">
                  Lahore, Pakistan
                </span>
              </div>
              <div className="flex items-center gap-[1rem]">
                <img src={JobType} className="w-[1rem] h-[1rem]" alt="" />
                <span className="text-[1rem] font-medium text-[#707070]">
                  Remote
                </span>
              </div>
              <div className="flex items-center gap-[1rem]">
                <img src={Salary} className="w-[1rem] h-[1rem]" alt="" />
                <span className="text-[1rem] font-medium text-[#707070]">
                  $1800 - $2500
                </span>
              </div>
            </div>
            <p className="font-normal text-[1rem] mt-1 break-words">
              We're looking for a talented UI/UX Designer to create intuitive
              and visually appealing digital experiences. You'll work closely
              with our development team to bring innovative designs to life.
            </p>
          </div>
        </div>
      </div>
      <button
        onClick={handleViewAll}
        className="rounded-[3.1rem] text-[#FC6935] border border-[#FC6935] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer w-fit m-auto mt-14"
      >
        View All
      </button>
    </div>
  );
}
