import React, { useState } from "react";
import Rank from "../../../assets/img/rank.svg";
import Job from "../../../assets/img/rank.svg";
import World from "../../../assets/img/world-black.svg";
import Salary from "../../../assets/img/salary.svg";
import Degree from "../../../assets/img/cap.svg";
import ArrowLongRight from "../../../assets/img/arrow-long-right.svg";
import Google from "../../../assets/img/google.svg";
import JobCard from "../../job/JobCard";
import { useParams } from "react-router-dom";
import { formatDate, formatName } from "../../utlis/helper";
import CustomEditor from "../../components/CustomEditor";

const JobListing = ({ progress, setProgress }) => {
  const { id } = useParams();
  const [job, setJob] = useState();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setProgress(30);
      setLoading(true);
      api
        .get(`/candidate/job/${id}`)
        .then((res) => {
          setProgress(50);
          setJob(res.data);
        })
        .catch((err) => {
          console.log(err);
        })
        .finally(() => {
          setProgress(100);
          setLoading(false);
        });
    };
    fetchData();
  }, []);

  const Shimmer = () => (
    <div className="animate-pulse mt-[5.8rem]">
      <div className="py-12 px-20 flex gap-6">
        <div className="w-[70%]">
          <div className="h-4 w-32 bg-gray-200 rounded mb-6"></div>

          <div className="h-8 w-3/4 bg-gray-200 rounded mb-4"></div>

          <div className="h-6 w-1/2 bg-gray-200 rounded mb-8"></div>

          <div className="flex gap-4 mb-8">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-8 w-24 bg-gray-200 rounded-full"></div>
            ))}
          </div>

          <div className="mb-8">
            <div className="h-6 w-48 bg-gray-200 rounded mb-4"></div>
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="h-4 w-full bg-gray-200 rounded mb-2"
              ></div>
            ))}
          </div>

          <div className="mb-8">
            <div className="h-6 w-48 bg-gray-200 rounded mb-4"></div>
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="h-4 w-full bg-gray-200 rounded mb-2"
              ></div>
            ))}
          </div>

          <div className="mb-8">
            <div className="h-8 w-64 bg-gray-200 rounded mb-4"></div>
            <div className="bg-gray-100 p-6 rounded-lg">
              <div className="flex justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
                  <div>
                    <div className="h-4 w-32 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 w-48 bg-gray-200 rounded"></div>
                  </div>
                </div>
                <div className="h-4 w-24 bg-gray-200 rounded"></div>
              </div>
              {[...Array(4)].map((_, i) => (
                <div
                  key={i}
                  className="h-3 w-full bg-gray-200 rounded mb-2"
                ></div>
              ))}
              <div className="h-4 w-24 bg-gray-200 rounded mt-4 mx-auto"></div>
            </div>
          </div>

          <div>
            <div className="h-8 w-64 bg-gray-200 rounded mb-4"></div>
            <div className="space-y-4">
              {[...Array(2)].map((_, i) => (
                <div
                  key={i}
                  className="h-32 w-full bg-gray-200 rounded-lg"
                ></div>
              ))}
            </div>
          </div>
        </div>

        <div className="w-[30%]">
          <div className="h-96 w-full bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    </div>
  );

  if (loading) {
    return <Shimmer />;
  }

  return (
    <div className="family-outfit mt-[5.8rem] flex items-start">
      <div className="py-12 px-20 flex gap-6 w-available">
        <div className="w-[100%]">
          <>
            <div className="flex justify-between items-center">
              <div className="text-[#707070] font-medium text-[1rem] flex gap-4">
                <i className="calender-icon"></i>
                <span>{formatDate(job?.job?.createdAt)}</span>
              </div>
            </div>
            <h1 className="text-[#000] text-[2.25rem] font-semibold mt-[1.5rem]">
              {job?.job?.title}
            </h1>
            <div className="text-[#707070] text-[1.25rem] font-medium mt-[1rem] cursor-pointer w-fit">
              @ {formatName(job?.job?.company_id?.company)} is hiring{" "}
              {job?.job?.title}
            </div>
            <div className="mt-[2rem] flex gap-9">
              <div className="border-2 border-[#F7F7F7] rounded-[1.5rem] py-[0.3rem] px-[0.75rem] flex gap-4 cursor-pointer w-fit">
                <img src={Job} alt="Rank Icon" />
                <span className="text-[1rem] text-[#292929] font-medium ">
                  {formatName(job?.job?.job_type || "")}
                </span>
              </div>
              <div className="border-2 border-[#F7F7F7] rounded-[1.5rem] py-[0.3rem] px-[0.75rem] flex gap-4 cursor-pointer w-fit">
                <img src={Rank} alt="Rank Icon" />
                <span className="text-[1rem] text-[#292929] font-medium ">
                  {formatName(job?.job?.level || "")}
                </span>
              </div>
              <div className="border-2 border-[#F7F7F7] rounded-[1.5rem] py-[0.3rem] px-[0.75rem] flex gap-4 cursor-pointer w-fit">
                <img src={Salary} alt="Rank Icon" />
                <span className="text-[1rem] text-[#292929] font-medium ">
                  ${numeral(job?.job?.min_salary).format("0.0a")} - $
                  {numeral(job?.job?.max_salary).format("0.0a")}
                </span>
              </div>
              <div className="border-2 border-[#F7F7F7] rounded-[1.5rem] py-[0.3rem] px-[0.75rem] flex gap-4 cursor-pointer w-fit">
                <img src={Degree} alt="Rank Icon" />
                <span className="text-[1rem] text-[#292929] font-medium capitalize">
                  {job?.job?.job_location || "--"}
                </span>
              </div>
              <div className="border-2 border-[#F7F7F7] rounded-[1.5rem] py-[0.3rem] px-[0.75rem] flex gap-4 cursor-pointer w-fit">
                <img src={World} alt="Rank Icon" />
                <span className="text-[1rem] text-[#292929] font-medium ">
                  {job?.job?.address || ""}
                </span>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <h3 className="text-[1.5rem] font-semibold text-[#707070] mb-2">
                  About the job
                </h3>
                <div className="relative">
                  <CustomEditor
                    value={job?.job?.description}
                    isReadOnly={true}
                  />
                </div>
              </div>

              <div>
                <h3 className="text-[1.5rem] font-semibold text-[#707070] mb-2">
                  Key Responsibilities
                </h3>
                <div className="relative">
                  <CustomEditor
                    value={job?.job?.key_responsibilities}
                    isReadOnly={true}
                  />
                </div>
              </div>

              <div>
                <h3 className="text-[1.5rem] font-semibold text-[#707070] mb-2">
                  Skills
                </h3>
                <div className="flex flex-wrap gap-3">
                  {job?.job?.skills?.map((skill, skIdx) => (
                    <span
                      className="bg-[#FFEDE5] text-[#FC6935] rounded-full px-4 py-2 text-[1rem] font-medium"
                      key={skIdx}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-12">
              <h1 className="text-[2.25rem] font-semibold">
                About the Company:
              </h1>

              <div className="mt-[1rem]">
                <div className="bg-[#F6F3EA] p-[1.5rem] border-2 border-[#94949470] rounded-[1rem]">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      <div className="bg-white p-[0.5rem] rounded-full cursor-pointer">
                        <img src={Google} />
                      </div>
                      <div className="">
                        <span className="font-semibold text-[1.5rem] underline cursor-pointer">
                          {job?.job?.company_id?.company}
                        </span>
                        <p className="text-[1rem] text-[#707070] font-normal">
                          Shape the Next Generation of AI with your Expertise.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-[1.3rem]">
                    <p className="text-[#707070] text-[1rem] font-normal">
                      {job?.companyInfo?.about_company}
                    </p>
                  </div>

                  <div className="flex gap-4 font-medium text-[1rem] text-[#707070] cursor-pointer underline mt-[1.5rem] justify-center">
                    Read More <img src={ArrowLongRight} alt="" />
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-12">
              <h1 className="text-[2.25rem] font-semibold">Similar Jobs:</h1>

              <div className="mt-[1rem]">
                <JobCard
                  data={job?.similarJobs}
                  progress={progress}
                  setProgress={setProgress}
                />
              </div>
            </div>
          </>
        </div>
      </div>
    </div>
  );
};

export default JobListing;
