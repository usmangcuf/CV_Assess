import React, { useEffect, useRef, useState } from "react";
import ChartToggles from "./ChartToggles";
import {
  FaUserCircle,
  FaMapMarkerAlt,
  FaMoneyBill,
  FaRegClock,
  FaCheckCircle,
  FaEnvelope,
  FaBookmark,
} from "react-icons/fa";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import User from "../../../assets/img/user.png";
import JobCard from "../../job/JobCard";
import { api } from "../../utlis/customAPI";
import { ReportLoader } from "../../utlis/shimmer";
import { useNavigate } from "react-router-dom";
import { AiOutlineLeft, AiOutlineRight } from "react-icons/ai";
import { IoIosArrowForward } from "react-icons/io";

const ReportPage = () => {
  const navigate = useNavigate();
  // State for toggles
  const [showApplied, setShowApplied] = useState(true);
  const [showInterviewed, setShowInterviewed] = useState(true);
  const [showRejected, setShowRejected] = useState(true);
  const [reportData, setReportData] = useState({
    data: null,
    isLoad: false,
  });

  const carouselRef = useRef(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const scrollAmount = 200;

  const checkScroll = () => {
    if (carouselRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = carouselRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft + clientWidth < scrollWidth);
    }
  };

  const scrollLeft = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollLeft -= scrollAmount;
      setTimeout(checkScroll, 300);
    }
  };

  const scrollRight = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollLeft += scrollAmount;
      setTimeout(checkScroll, 300);
    }
  };

  useEffect(() => {
    checkScroll();
  }, []);

  const getReport = async () => {
    setReportData((prev) => ({
      ...prev,
      isLoad: true,
    }));
    try {
      const response = await api.get("/candidate/report");
      setReportData({
        data: response.data,
        isLoad: false,
      });
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getReport();
  }, []);
  console.log(reportData);

  return (
    <div className="min-h-screen p-4 md:p-8 flex flex-col md:flex-row gap-6 mt-[5.8rem] w-full">
      {reportData.isLoad ? (
        <ReportLoader />
      ) : (
        <>
          <div className="flex-1 flex flex-col gap-6 w-[70%]">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {Object.values(reportData?.data?.totalStats || {}).map(
                (card, idx) => {
                  const percent = Math.min(card / 100, 1);
                  const color =
                    idx === 0 ? "#10b981" : idx === 1 ? "#f59e0b" : "#4f46e5";
                  return (
                    <div
                      key={idx}
                      className="bg-[#F7F7F7] rounded-3xl flex flex-row items-center px-8 py-6 gap-6 min-h-[120px]"
                      style={{ minWidth: 280 }}
                    >
                      <div className="relative w-20 h-20 flex items-center justify-center">
                        <svg width="80" height="80" className="block">
                          <circle
                            cx="40"
                            cy="40"
                            r="32"
                            fill="none"
                            stroke="#fff"
                            strokeWidth="8"
                          />
                          <circle
                            cx="40"
                            cy="40"
                            r="32"
                            fill="none"
                            stroke={color}
                            strokeWidth="8"
                            strokeDasharray={2 * Math.PI * 32}
                            strokeDashoffset={2 * Math.PI * 32 * (1 - percent)}
                            strokeLinecap="round"
                            style={{ transition: "stroke-dashoffset 0.5s" }}
                          />
                        </svg>
                        <span
                          className="absolute inset-0 flex items-center justify-center text-2xl font-bold"
                          style={{ color }}
                        >
                          {card}
                        </span>
                      </div>
                      <div className="flex flex-col justify-center items-start family-outfit">
                        <div className="font-semibold text-lg text-gray-800 mb-1">
                          {idx === 0
                            ? "Applied Jobs"
                            : idx === 1
                              ? "Interview"
                              : "Rejected"}
                        </div>
                        <div className="text-sm text-gray-500">This month</div>
                      </div>
                    </div>
                  );
                }
              )}
            </div>
            <div className="bg-[#f8f9fb] rounded-3xl shadow p-6 family-outfit">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-4">
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 w-full">
                  <span className="text-2xl font-semibold text-[#707070] mb-2 sm:mb-0">
                    Vacancy State
                  </span>
                  <ChartToggles
                    showApplied={showApplied}
                    setShowApplied={setShowApplied}
                    showInterviewed={showInterviewed}
                    setShowInterviewed={setShowInterviewed}
                    showRejected={showRejected}
                    setShowRejected={setShowRejected}
                  />
                </div>
              </div>
              {/* Graph with static data */}
              <div className="w-full h-72 flex items-center justify-center mt-5">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={reportData?.data?.chartData}
                    margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid stroke="#e5e7eb" strokeDasharray="3 3" />
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 14, fill: "#888" }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fontSize: 14, fill: "#888" }}
                      axisLine={false}
                      tickLine={false}
                      domain={[0, 130]}
                    />
                    <Tooltip
                      contentStyle={{ borderRadius: 12, fontSize: 14 }}
                    />
                    {/* Custom Legend below chart, so we skip default Legend */}
                    {showApplied && (
                      <Line
                        type="monotone"
                        dataKey="Applied"
                        stroke="#22c55e"
                        strokeWidth={3}
                        dot={{
                          r: 6,
                          fill: "#fff",
                          stroke: "#22c55e",
                          strokeWidth: 3,
                        }}
                        activeDot={{
                          r: 8,
                          fill: "#22c55e",
                          stroke: "#fff",
                          strokeWidth: 2,
                        }}
                      />
                    )}
                    {showInterviewed && (
                      <Line
                        type="monotone"
                        dataKey="Interviewed"
                        stroke="#eab308"
                        strokeWidth={3}
                        dot={{
                          r: 6,
                          fill: "#fff",
                          stroke: "#eab308",
                          strokeWidth: 3,
                          shape: (props) => (
                            <rect
                              {...props}
                              width={12}
                              height={12}
                              rx={3}
                              fill="#fff"
                              stroke="#eab308"
                              strokeWidth={3}
                              x={props.cx - 6}
                              y={props.cy - 6}
                            />
                          ),
                        }}
                        activeDot={{
                          r: 8,
                          fill: "#eab308",
                          stroke: "#fff",
                          strokeWidth: 2,
                        }}
                      />
                    )}
                    {showRejected && (
                      <Line
                        type="monotone"
                        dataKey="Rejected"
                        stroke="#f87171"
                        strokeWidth={3}
                        dot={{
                          r: 6,
                          fill: "#fff",
                          stroke: "#f87171",
                          strokeWidth: 3,
                          shape: (props) => (
                            <rect
                              {...props}
                              width={12}
                              height={12}
                              rx={2}
                              fill="#fff"
                              stroke="#f87171"
                              strokeWidth={3}
                              x={props.cx - 6}
                              y={props.cy - 6}
                            />
                          ),
                        }}
                        activeDot={{
                          r: 8,
                          fill: "#f87171",
                          stroke: "#fff",
                          strokeWidth: 2,
                        }}
                      />
                    )}
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="flex gap-8 mt-4 justify-center">
                <span className="flex items-center gap-2 text-green-600 text-lg font-bold">
                  <svg width="20" height="8">
                    <circle cx="10" cy="4" r="4" fill="#22c55e" />
                  </svg>
                  Applied
                </span>
                <span className="flex items-center gap-2 text-yellow-500 text-lg font-bold">
                  <svg width="20" height="8">
                    <rect
                      x="4"
                      y="1"
                      width="12"
                      height="6"
                      rx="3"
                      fill="#eab308"
                    />
                  </svg>
                  Interviewed
                </span>
                <span className="flex items-center gap-2 text-red-400 text-lg font-bold">
                  <svg width="20" height="8">
                    <rect
                      x="4"
                      y="1"
                      width="12"
                      height="6"
                      rx="2"
                      fill="#f87171"
                    />
                  </svg>
                  Rejected
                </span>
              </div>
            </div>

            <div>
              <div className="font-semibold text-2xl text-[#707070] m4-3 family-outfit">
                Companies in which applied
              </div>
              <div className="flex gap-4 overflow-x-auto pb-2 mt-4 family-outfit relative w-full">

                {canScrollLeft && (
                  <button
                    onClick={scrollLeft}
                    className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-white p-2 rounded-full shadow-md cursor-pointer"
                  >
                    <AiOutlineLeft size={24} />
                  </button>
                )}

                <div
                  ref={carouselRef}
                  className="flex gap-6 overflow-x-auto scroll-smooth whitespace-nowrap no-scrollbar w-full"
                  onScroll={checkScroll}
                >
                  {reportData?.data?.companies.length > 0 ? reportData?.data?.companies?.map((company, idx) => (
                    <div
                      key={idx}
                      className="bg-[#F6F3EA] rounded-3xl flex items-center p-4 min-w-[160px] gap-2.5 flex-wrap"
                    >
                      <img
                        src={
                          company.image_url
                            ? company.image_url
                            : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUEAAACdCAMAAAAdWzrjAAABd1BMVEXz8/P4+Pj39/f29vb19fX5+fn09PT6+vrAxMbu7u/X2Nn9/f37//8eZK4pUI8sSoYsRHzyhxPygxQuQnvyfhTvZxktQnfzjBHxeQD69e3839/wdRfvcBfP3u3rTCDpNSPnKSP0mg7rQyPoNTXyiADsWhznGRLvbADrVR3pOiNRT1CTkpL1ng/rTgz56ueIpcueqcHc3+gNNnjxkm4nV5kVTZSesc1iYGHzpXvwmZcSXapnZWb2xprznH3sWC/pMxi9wdDtYjw1ZKPh4OF1c3SBf4CenZ6OjY7BxsnvZAD30sHuWQDvf29MdrEYT5S3tbZKSEn54bf30o34xHb2vWT2uFH5xoP2sTT669b10Kz0nzH54cfzkC/0sXX1n1j3ya/xm2j0t47xgT/wekDuay30tZzwgVTubUrsQADwj3X3ysHyoZHuc2D0urTsVkXqRjPtfHHqVlKrv9pfib5XdahGZ5x+jrFdbJVDU4EfMm16gJ2PlKuysbJg0iSaAAAMMklEQVR4nO3djUPTZh4H8JY2TdMnB96qnkXZfBs6ykvLWqrgpFIooGfBuXPcbjc9nc5z7G5DBnrjj7/nJWnz8rylSQpP2u8mLTZpm4+/X54khCa1VRglTLZShbFsLjtKvzHyqUI2NUrfySHB3Gm/C6UzqsGwGQmGTG4kGDIjwbAZCYbNSDBsRoJhMxIMm5Fg2IwEw2YkGDZnRDDnyWm/nwAZvKAXi52YXjvq54xbUIbKf8wtDsWY/mFOX5B14DLKasy53kgES+V87rgEg3GhZEg4kFEl2gUdqCDdzJexse5dQXG6nzeBgh4wzzdMPxJ4z8dI5uJVMkM6GxvhAAUFYJBsjBrGfNRnpiBSQaNc0DgFeYB+qbQrdE0hrWRRRrmgMQqGAZSTpHQ+R1RtQREgwy+gKAWRThjlgsYnyC5B6QLsizQxggEAQ/jRDEWEES9oTIKcHo7YLzBh1Esam2COAZgJ4Kc5EsSQKZhVU7AfQI2evggzcQIOoouDAjLwRIwcQ6dg9EsajyCzBCMAZBnKNHJKlRp07pCwAfvkYxpKFKEyXcwQ9DRa/34sRGERKigYoAKD+VENhVWozNYMXZBbgcH9qGWYaMGoK5BqKChC9QRlAZlCOuVeX4QJE5QDRGa6Heky5BahcoJyJUjnQwHABHqppJumCUymYwBC1QRZw4gYEOulS0++fvrN32C+efr1k1IaAAbiUAhKA8K/QE6m+eTZt7OufPvsCSpJjabINKQQRr2sMQr2V4HYb+/Z7LVZX67NPtsz6d0sU4XJFKT5gb2ns9cYmX26R+1lqUZWWFAECEw7qE/vsfhI7pVohjJ9HMvRmYEL0gDNv99z5Lubf+Hm5nf/MClbOHJFmFFTkFWC9sKb3990hg+IDO/plDKUbeOol3XAghTAtFb6/s/BcvOfJcpmtriN4yCMTdCxMSMaRfS9S/R8wsylH3T/mCy1JlTkZ3VBShAteomeS+eZufQDrEJNjjBJgnRAe+/X9KR06/z5y5eRV+9Lj/CF5h9O5AgjXtb4u1hYgpag+fyOOy9uXebk1r/8I3KSBLM0QR6gBva2b3lyhZtbD/mE1DVh9G0cv6C4BAlg6eW2X+nC9vb2lZcvr6AbP2HJf+RLXIQKCXJL0Cuom6+3L/iy/erOw3mc5y9e+R7fvgP6KELlBOVKUAfzfr9Hrx6Owf08HDiuvL7wyPUozKSTMC1VhIqcBSwURHDugffLR5+78+jH56ap9wL3mF87pnnzEGbe8QS6XBurIUhfDXpK0PzKFY/f53Nv5kmBAYfh5I9z9uOv4DxfOvJVyd/HlDaO/iBr3ILsEizNuXLbnbk3momOU/eCCed/6k7onn3uAW1VmGzByblPnblt/SH35/Y14PKzDM35+2iq2+SLY6a5n8xkCea4TYyW03x4nxLb88G86fUjhubkWxf8/Qck9/+dMEH+ahCPwNl5St5ex3n7jgqIDM2fIeF1O5/u23Om+F3s+OWepAhqujXQkm0VkiwRXN1nAcJkr7uimb6NQl4RqiHo2CumrgbtBbW3BeHG4F9J9le/QFllliDS/plMBCeDmbY3CRMmSBlIvCXo2JrWzV+mV0kIzX84gHCT5r/WVL/C7L+jCGrDJ3h39TNHpu9yACHhr6tkKu/RsO62Nb8GIz46c7qCpHh0c3/1qiPTk7wahN7TeLL9u4z8YrKHEtUEeatBrXdakfmbE/DqDa4gMN9NW9KM3E2kIK8EoeANZ36bN31b084anLx6g5erjhr0tbFCguwm7u6s9Zgm3eH44fkm+ZnXkiOYoQhqxpQoIkHPxN3THfAwAjczOZszqglSalDTD5b/xM9jgy9YdTzB8mOje+yGrBnS3L0S9QXH0uBgmZEuS5UvOOX8J3ifcQsKtqmVEKTukvQWCUwtMPLerqspbg+DJWcNvgfDJqhpTBu7vZcX+DX43lGCcNphE6RsDupgau0xzJqtssYtwSqZiKR+MHSCY35BDY4NteXlWg3C4D81bhvjJq69t1q/OnSC7hq0UIzHNVcOOYAGmYQy2vQMlRfk7hY7BY2qlSO3IOxNZhY6eJKpqi9Thq6l9aESBEdrdtyCtTXmBk2zbk3hmQE9xxQYthoEjzs1ejqHWRofHEa81s4MoWCt3unUO9YX+J+D8PccjbDqla7DuezUqnpaJBj9WaxxCWakBBeWFhaWHDnsOAgpjdysjbt71zX3QUr3nbgwlkBBF6Gjug5gDscdqS15jjAYC51xVzpHnib3j8VJF3ScFVNF3egGqq8dpBzElXHP451xx8YgY3vQC5hcQR1UPD7YcPxwCW+2TFUOO77H60uAHKFNomAmuGDq0C+ImOq9r578DlwlmHBB/o4x6eNFKqGVCZx63f4yUZ+oigHVFeSdPMgQ1EFzgpujijtN4Dw1TlSCqglmgrcxWhUu8gQZuynBmjjhgvoRj7Dp3xNGyQZq4uhP5j9dQS8hOFo8R8/EuYlFeqqBzjxSRTCT6asIIWGlWGQY0lP8YHgBh0vQT9j8IDIsFp0leDwS9BpWjxeLMOeKrCweN53RAgGqLCjVxjrAZfixeLF4kZrix2KTNhbLC579s4BzoQRxJ+cqyJDq96GS8uyJcMYRRQVdNZgN3sbY0GgeX3QhFnH5fWgaVD9hCSonKFoRCgjxOUnVyvFHV44rVUD3C/KriSoLBiBEe2v4iFaz8sf/YP6oNKuAxReoBJURDPARARTB7q+DWUOF/UMS76+JSZeggoIZURFqXEI/Jy+aUDCjtKD0xyz0Gy2IoAq/08T7zC2GYChCCUAlBemErCIMQ8gSpAIqL9gj1MmPdu0TT7srO9cxP/seufHshbh/PkcmHiLBTKGFP2W1VciSGySBWFoFFIMopcgd0Gqhm2zLikEeI8HPo4FMi8wnGkeUF7QINWOlDBdWA+0GEgAbK4QsvdmYQWnksVxhhtyurwP8XQNn5gR/1yCTttGZHnphHX/XONFEJaiOILcINaNRxjbtGSiog40GwBVY2C2jUsqvrBu2IOgKGvl8fqNxks8XiGe7sLW1lS/A+TV9o7ED7++sr7Q0H6BrHFFU0EeoG41NA8WuwQauJHCyW8Art522JbiDJkphQbymK68YZEVoP9bKofbXZjbxFvfJSksXlKBCgrwihF08Q+IU1LBgq9wuty3BhjXVuj16lFda1uBiPba7A7BgGa8BdSAsQZUEOZ8iCmtwI4+y6RcsrKyvNxqG1al4qhWaoPUYWgtoqAahnV7YMTQ2oMqCXkK8HkRpuwV3drfwX2+uWIJ5/O06VZA8httfb2yk8dPt4i5mAKonyC5CLAhvyUjSFYSlicfbmd0yUdp1jMVEEIrjrWg0Mq/ANMhY3N7F382s4xrklaCqgh5CzWjvYMF82cDd2yZnn+qtdnlzs1w+yWGvVrmAxmjQbtuCaIixpizjbO7gObM7cL7NzTavBK03dfZ/TtID5HyqvAbIti9sQrRvAuzTd7t7GpR9EuueZ0qAd+XsX/PxAqouKPnB/KxLQ/B3gemHE8QlePYFXZdLZAjKXiBHrBf0AiUKnYnOL8JIrjFE85MAVFewz6vkBBNkASorKH+lq8FcKyyGzZlBCgovmBgtIKOHlRBkXnk3SkL/3OwW9pagWoKBCKURRX7MHo78KtDxCMpe/plGKGFInU0SUBXBUIR8RdYs7BamXcs9wsUdgCD3IuTBDFlT8y69SwNUQJBdhLKEFmPa+p83Gf9C7jRAFQTlCfmXcpeKLKC6ggLCcIa+Z5MAVEIwEGH/hnw/Rg8rIjgQwj4BVRSMhdD/LBxABQUDEgZVpD2BLKAqglxCuqEsIn1mjl9MFRjXp+eFIZQwZMzIK8C4KjAeQZehEzIjRyhAlPMbTAun4hK0n1wIyTT0Swom5frF18MxC5JXgG+Z3td4QbmSUgUbFFA5wd5L+cNdTUpFpoPdfmpc+ZT9crRkaemHUwpQcUHymgJENitFmcbNa+GoAc+KYBdNojpFJet9KF7AUxFkhAXLj1fRZxsz4FkSpCQwIgsuJj38Hs+0oDBeRKpwzG9BbUGUnuGA7ayXV1+Q0+sDefUECDINB/PaiRC0Mlg6+0WTJHgqGQmGzUgwdGzBHP6fecN+AH6h3vTzXH2+iGC9J3oRzssyXt01LRI0RgmTfGorP0qYbP0fAasidrUvKIoAAAAASUVORK5CYII="
                        }
                        alt="logo"
                        className="w-15 h-15 rounded-full border border-[#ccc]"
                      />
                      <div className="font-semibold text-[1.2rem] text-[#000000]">
                        {company.company}
                      </div>
                    </div>
                  )) :
                    (
                      <div className="flex justify-center w-full items-center flex-col py-8">
                        <h3 className="text-lg font-medium text-gray-600">You haven't applied to any jobs yet</h3>
                        <p className="mt-2 text-gray-500">Start your job search and apply to exciting opportunities!</p>
                        <button
                          className="mt-4 w-fit bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer transition-colors"
                        >
                          Browse Jobs
                        </button>
                      </div>
                    )}
                </div>
                {canScrollRight && (
                  <button
                    onClick={scrollRight}
                    className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-white p-2 rounded-full shadow-md cursor-pointer"
                  >
                    <AiOutlineRight size={24} />
                  </button>
                )}
              </div>
            </div>
            <div>
              <div className="font-semibold text-2xl text-[#707070] mb-4 family-outfit">Recommend Jobs</div>
              <div className="flex flex-col gap-4 family-outfit">
                <JobCard
                  data={reportData?.data?.recommendedJobs}
                  active={"No"}
                />
              </div>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="w-[23%] flex-shrink-0 flex flex-col family-outfit">
            {/* Profile Card */}
            <div className="bg-[#F6F3EA] rounded-3xl shadow p-6 flex flex-col items-center mb-5 cursor-pointer" onClick={() => navigate("/profile")}>
              <img
                src={reportData?.data?.basicCandidateInfo?.profileImage || "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQF02Jj8T2t7PdkytAw42HDuuSz7yXguKn8Lg&s"}
                alt="avatar"
                className="w-25 h-25 rounded-full mb-2 border border-[#ccc]"
              />
              <div className="font-semibold text-[1.4rem] text-center text-[#FC6935]">
                {reportData?.data?.basicCandidateInfo?.name}
              </div>
              <div className="text-[1rem] font-normal text-[#707070] mb-2">
                {reportData?.data?.basicCandidateInfo?.role}
              </div>
              <hr className="w-full border-b border-[#fff] mb-4 mt-4" />
              <div className="w-full flex items-center gap-2.5">
                <div
                  className={`bg-[#ccc] h-2 rounded-full w-full`}
                >
                  <div className={`w-[${reportData?.data?.profileCompletion}%] rounded-full h-full bg-green-500`}></div>
                </div>
                <span className="text-[1rem] font-medium text-[#707070]">{reportData?.data?.profileCompletion}%</span>
              </div>
              <button
                className="text-[#FC6935] cursor-pointer text-[1rem] underline flex justify-between items-center w-full font-semibold mt-2.5"
                onClick={() => navigate("/profile")}
              >
                Complete Your Profile

                <IoIosArrowForward className="text-[#FC6935]" />
              </button>
            </div>
            {/* Recent Activity */}
            {/* <h3 className="font-semibold text-md text-[#707070] mb-4">Recent Activity</h3>

            <div className="bg-[#F6F3EA] rounded-3xl shadow p-6">
              <ul className="text-sm text-[#000000] flex flex-col gap-2">
                <li>
                  Your application has been accepted by{" "}
                  <span className="text-orange-500 font-semibold">
                    [Company Name]
                  </span>
                  .
                </li>
                <li>
                  You've received a message from{" "}
                  <span className="text-orange-500 font-semibold">
                    [Company Name]
                  </span>
                  .
                </li>
                <li>
                  <span className="text-orange-500 font-semibold">
                    [Company Name]
                  </span>{" "}
                  has shortlisted your profile!
                </li>
                <li>
                  Your application to{" "}
                  <span className="text-orange-500 font-semibold">
                    [Company Name]
                  </span>{" "}
                  is under review.
                </li>
                <li>
                  Interview scheduled with{" "}
                  <span className="text-orange-500 font-semibold">
                    [Company Name]
                  </span>{" "}
                  on <span className="text-orange-500 font-semibold">[Date]</span>.
                </li>
              </ul>
            </div> */}
          </div>
        </>
      )}
    </div>
  );
};

export default ReportPage;
