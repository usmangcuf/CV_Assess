import React, { useState } from "react";
import Options from "../../myJobs/Options";
import JobCard from "../../job/JobCard";
import { jobs } from "../../json/Jobs";

export default function LandingMyJob() {
  const [selectedOption, setSelectedOption] = useState("Saved");

  const filteredJobs = jobs.filter((job) => {
    if (selectedOption === "Saved") return job.isSaved;
    if (selectedOption === "Applied") return job.applied;
    return false;
  });
  const options = ["Saved", "Applied"];

  return (
    <div className="family-outfit mt-[5.8rem]">
      <div className="px-20 w-full flex gap-16">
        <div className="w-[20%] border-r-3 border-[#F7F7F7] fixed h-screen">
          <div className="py-12">
            <Options
              options={options}
              selectedOption={selectedOption}
              setSelectedOption={setSelectedOption}
            />
          </div>
        </div>

        <div className="w-[80%] ml-88">
          <div className="py-12">
            <JobCard data={filteredJobs} active={"No"} />
          </div>
        </div>
      </div>
    </div>
  );
}
