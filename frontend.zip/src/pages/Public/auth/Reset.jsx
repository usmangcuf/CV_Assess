import React, { useEffect, useState } from "react";
import Back from "../../../assets/img/arrow-back.svg";
import AuthBg from "../../../assets/img/auth-bg.png";
import { api } from "../../utlis/customAPI";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";

export default function Reset({ setProgress }) {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const validateEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleChangeEmail = (e) => {
    const value = e.target.value;
    if (!value) {
      setError("Email is required.");
      return;
    } else if (!validateEmail(value)) {
      setError("Please enter a valid email address.");
      return;
    }
    setError("");
    setEmail(value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email) {
      setError("Email is required.");
      return;
    }

    setProgress(30);
    api
      .post("/auth/forgot-password", { email })
      .then(({ data }) => {
        setSuccess(true);
        setProgress(60);
      })
      .catch((error) => {
        console.log(error);
        toast.error("Something went wrong!");
      })
      .finally(() => {
        setProgress(100);
      });
  };

  return (
    <div className="login bg-white p-[1.5rem] flex gap-x-[6.2rem]">
      <div className="left mt-[4.8rem] w-[50%]">
        <div className="flex flex-col top-sec">
          <Link
            to="/login"
            className="flex items-center gap-3.5 family-Ubuntu w-fit cursor-pointer"
          >
            <img src={Back} className="h-[0.8rem] w-[0.6rem]" />
            <span className="text-[1rem] text-[#707070] font-medium pb-[2px]">
              Login
            </span>
          </Link>
          <div className="flex flex-col mt-[1.5rem] ml-[4rem]">
            <h3 className="text-[1.5rem] font-[600] family-outfit">
              Forgot Password
            </h3>
            <p className="family-outfit font-[400] text-[#707070] text-[1rem] leading-[1.25rem] pt-[1rem] max-w-[21rem]">
              Enter your email to receive a reset link and regain access.
            </p>
          </div>
        </div>
        {/* <hr className="border-0 bg-[#D5D8DC] m-auto w-[300px] my-[1.5rem] h-[2px]" /> */}
        <form onSubmit={handleSubmit}>
          <div className="form-sec flex flex-col w-auto mt-[1.5rem] ml-[4rem] gap-[1.3rem]">
            <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
              <label className="font-[500] text-[1rem] text-[#707070]">
                Email address*
              </label>
              <input
                type="text"
                placeholder="Enter email address"
                defaultValue={email}
                onChange={(e) => handleChangeEmail(e)}
                className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
              />
              {error && (
                <span className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {error?.charAt(0).toUpperCase() + error?.slice(1)}
                </span>
              )}
              {success && (
                <span className="text-[0.8rem] text-green-600 pl-[1.5rem]">
                  Activation link has been sent to your email.
                </span>
              )}
            </div>
          </div>
          <div className="last-sec ml-[4rem] mt-[1.5rem] w-auto">
            <button
              type="submit"
              className="bg-[#FC6935] text-white family-outfit font-[600] text-[1rem] mt-[1.8rem] cursor-pointer rounded-[2.3rem] py-[0.7rem] px-[1.5rem] w-full"
            >
              Forgot Password
            </button>
          </div>
        </form>
        <div className="flex items-center mt-[1rem]">
          <span className="border border-[#D5D8DC] w-[50%] ml-[4rem]"></span>
          <span className="text-[#707070] font-[400] text-[12px] px-[0.6rem]">
            OR
          </span>
          <span className="border border-[#D5D8DC] w-[50%]"></span>
        </div>
        <div className="family-outfit font-[400] text-[16px] text-[#696F79] flex justify-center mt-[1.5rem]">
          Already have an account?{" "}
          <Link
            to="/login"
            className="relative text-[#FC6935] cursor-pointer hover:underline hover:decoration-[#FC6935]"
          >
            &nbsp;Sign In
          </Link>
        </div>
      </div>
      <div className="right w-[50%]">
        <img src={AuthBg} alt="" className="w-full h-full object-fill" />
      </div>
    </div>
  );
}
