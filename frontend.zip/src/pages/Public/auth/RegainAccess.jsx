import React from "react";
import Back from "../../../assets/img/arrow-back.svg";
import AuthBg from "../../../assets/img/auth-bg.png";
import PasswordField from "../../utlis/PasswordField";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { Link, useSearchParams } from "react-router-dom";
import { api } from "../../utlis/customAPI";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";

export default function RegainAccess({ setProgress }) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const emailFromURL = searchParams.get("email");
  const decodedEmail = decodeURIComponent(emailFromURL || "");

  const schema = yup.object().shape({
    email: yup.string().email().required("Email is required."),
    new_password: yup
      .string()
      .required("New Password is required.")
      .min(8, "Password must be at least 8 characters long."),
    // .matches(
    //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
    //   "Must contain at least 8 Characters, 1 Uppercase, 1 Lowercase, 1 Special Character, and 1 Number."
    // ),
    confirm_password: yup
      .string()
      .oneOf([yup.ref("new_password")], "Passwords must match."),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      email: decodedEmail,
      new_password: "",
      confirm_password: "",
    },
    shouldUnregister: true,
    shouldFocusError: false,
    mode: "onChange",
  });

  const onSubmit = (data) => {
    const payload = {
      email: data.email,
      newPassword: data.new_password,
      confirmPassword: data.confirm_password,
    };
    setProgress(30);
    api
      .post("/auth/reset-password", payload)
      .then(({ data }) => {
        navigate("/login");
        toast.success("Your password has been successfully changed.");
        setProgress(60);
      })
      .catch((error) => {
        console.log(error);
        toast.error("Something went wrong!");
      })
      .finally(() => {
        setProgress(100);
      });
  };

  return (
    <div className="login bg-white p-[1.5rem] flex gap-x-[6.2rem]">
      <div className="left mt-[4.8rem] w-[50%]">
        <div className="flex flex-col top-sec">
          <div className="flex items-center gap-3.5 family-Ubuntu w-fit cursor-pointer">
            <Link
              to="/login"
              className="flex items-center gap-3.5 family-Ubuntu w-fit cursor-pointer"
            >
              <img src={Back} className="h-[0.8rem] w-[0.6rem]" />
              <span className="text-[1rem] text-[#707070] font-medium pb-[2px]">
                Login
              </span>
            </Link>
          </div>
          <div className="flex flex-col mt-[1.5rem] ml-[4rem]">
            <h3 className="text-[1.5rem] font-[600] family-outfit">
              Reset Your Password
            </h3>
            <p className="family-outfit font-[400] text-[#707070] text-[1rem] leading-[1.25rem] pt-[1rem] max-w-[21rem]">
              Enter your new password below to reset your password.
            </p>
          </div>
        </div>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="form-sec flex flex-col w-auto mt-[1.5rem] ml-[4rem] gap-[1.3rem]">
            <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
              <label className="font-[500] text-[1rem] text-[#707070]">
                Email address*
              </label>
              <input
                type="text"
                placeholder="Enter email address"
                disabled
                readOnly
                {...register("email")}
                className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
              />
              {errors?.email && (
                <span className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors?.email?.message.charAt(0).toUpperCase() +
                    errors?.email?.message.slice(1)}
                </span>
              )}
            </div>
            <PasswordField
              validation={register}
              fieldName="new_password"
              label="New Password"
              error={errors?.new_password?.message}
            />
            <PasswordField
              validation={register}
              fieldName="confirm_password"
              label="Repeat Password"
              error={errors?.confirm_password?.message}
            />
          </div>
          <div className="last-sec ml-[4rem] mt-[2.25rem] w-auto">
            <button className="bg-[#FC6935] text-white family-outfit font-[600] text-[1rem] cursor-pointer rounded-[2.3rem] py-[0.7rem] px-[1.5rem] w-full">
              Reset Password
            </button>
          </div>
        </form>
      </div>
      <div className="right w-[50%]">
        <img src={AuthBg} alt="" className="w-full h-full object-fill" />
      </div>
    </div>
  );
}
