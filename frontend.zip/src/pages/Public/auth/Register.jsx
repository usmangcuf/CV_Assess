import React, { useEffect, useState } from "react";
import Back from "../../../assets/img/arrow-back.svg";
import Google from "../../../assets/img/google.svg";
import FB from "../../../assets/img/fb.svg";
import Apple from "../../../assets/img/apple.svg";
import AuthBg from "../../../assets/img/auth-bg.png";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import PasswordField from "../../utlis/PasswordField";
import Select from "react-select";
import { api } from "../../utlis/customAPI";
import toast from "react-hot-toast";

const options = [
  { value: "user", label: "Candidate" },
  { value: "company", label: "Company" },
];

export default function Register({ setProgress }) {
  const navigate = useNavigate();
  const [inputValue, setInputValue] = useState("");
  const [selectedOption, setSelectedOption] = useState(null);
  const [schema, setSchema] = useState(
    yup.object().shape({
      first_name: yup.string().required("First Name is required."),
      last_name: yup.string().required("Last Name is required."),
      email: yup.string().email().required("Email is required."),
      password: yup
        .string()
        .required("Password is required.")
        .min(8, "Password must be at least 8 characters long."),
      // .matches(
      //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
      //   "Must contain at least 8 Characters, 1 Uppercase, 1 Lowercase, 1 Special Character, and 1 Number."
      // ),
      confirm_password: yup
        .string()
        .oneOf([yup.ref("password")], "Passwords must match."),
      profile_type: yup
        .object()
        .shape({
          value: yup.string().required("Profile type is required."),
          label: yup.string().required("Profile type is required."),
        })
        .nullable()
        .required("Profile type is required."),
    }),
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    reset,
  } = useForm({
    resolver: yupResolver(schema),
  });

  const profileType = watch("profile_type");

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const newSchema = yup.object().shape({
      first_name: yup.string().required("First Name is required."),
      last_name: yup.string().required("Last Name is required."),
      email: yup.string().email().required("Email is required."),
      password: yup
        .string()
        .required("Password is required.")
        .min(8, "Password must be at least 8 characters long."),
      // .matches(
      //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
      //   "Must contain at least 8 Characters, 1 Uppercase, 1 Lowercase, 1 Special Character, and 1 Number."
      // ),
      confirm_password: yup
        .string()
        .oneOf([yup.ref("password")], "Passwords must match."),
      profile_type: yup
        .object()
        .shape({
          value: yup.string().required("Profile type is required."),
          label: yup.string().required("Profile type is required."),
        })
        .nullable()
        .required("Profile type is required."),
      ...(profileType?.value === "company" && {
        company_name: yup.string().required("Company Name is required."),
      }),
    });

    setSchema(newSchema);
  }, [profileType]);

  const onSubmit = (data) => {
    setProgress(30);

    const payload = {
      first_name: data.first_name,
      last_name: data.last_name,
      email: data.email,
      password: data.password,
      profile_type: data.profile_type.value,
      gender: "",
    };

    if (data.profile_type.value === "company") {
      payload.company_name = data.company_name;
    }

    api
      .post("/auth/sign_up", payload)
      .then((res) => {
        setProgress(60);
        navigate("/");
        toast.success("Signup successfully.");
        localStorage.setItem("ai-token", res.data.token);
        localStorage.setItem("ai-user", JSON.stringify(res.data.user));
      })
      .catch((error) => {
        console.log(error);
        toast.success("Something went wrong!");
      })
      .finally(() => {
        setProgress(100);
      });
  };

  const handleMenuOpen = () => {};

  return (
    <div className="register bg-white p-[1.5rem] flex gap-x-[6.2rem]">
      <div className="left mt-[4.8rem] w-[50%]">
        <div className="flex flex-col top-sec">
          <Link
            to="/login"
            className="flex items-center gap-3.5 family-Ubuntu w-fit cursor-pointer"
          >
            <img src={Back} className="h-[0.8rem] w-[0.6rem]" />
            <span className="text-[1rem] text-[#707070] font-medium pb-[2px]">
              Login
            </span>
          </Link>
          <div className="flex flex-col mt-[1.5rem] ml-[4rem]">
            <h3 className="text-[1.5rem] font-[600] family-outfit">
              Create your Account
            </h3>
            <p className="family-outfit font-[400] text-[#707070] text-[1rem] leading-[1.25rem] pt-[1rem] pb-[1.5rem] max-w-[21rem]">
              For security and personalized access, your credentials are
              required.
            </p>
          </div>
        </div>
        <hr className="border-0 bg-[#D5D8DC] m-auto w-[300px] my-[1.5rem] h-[2px]" />
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="form-sec flex flex-col w-auto mt-[1.5rem] ml-[4rem] gap-[1.3rem]">
            <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
              <label className="font-medium text-[1rem] text-[#707070]">
                First Name*
              </label>
              <input
                type="text"
                placeholder="Enter first name"
                {...register("first_name")}
                className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
              />
              {errors?.first_name && (
                <span className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors?.first_name?.message.charAt(0).toUpperCase() +
                    errors?.first_name?.message.slice(1)}
                </span>
              )}
            </div>
            <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
              <label className="font-medium text-[1rem] text-[#707070]">
                Last Name*
              </label>
              <input
                type="text"
                placeholder="Enter last name"
                {...register("last_name")}
                className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
              />
              {errors?.last_name && (
                <span className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors?.last_name?.message.charAt(0).toUpperCase() +
                    errors?.last_name?.message.slice(1)}
                </span>
              )}
            </div>
            <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
              <label className="font-medium text-[1rem] text-[#707070]">
                Email Address*
              </label>
              <input
                type="text"
                placeholder="Enter email address"
                {...register("email")}
                className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
              />
              {errors?.email && (
                <span className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors?.email?.message.charAt(0).toUpperCase() +
                    errors?.email?.message.slice(1)}
                </span>
              )}
            </div>
            <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
              <label className="font-medium text-[1rem] text-[#707070]">
                Profile Type*
              </label>
              <Select
                className="custom-selector"
                options={options}
                value={selectedOption}
                onBlur={register("profile_type").onBlur}
                onChange={(selected) => {
                  setSelectedOption(selected);
                  register("profile_type").onChange({
                    target: {
                      name: "profile_type",
                      value: selected,
                    },
                  });
                }}
                isSearchable
                onMenuOpen={handleMenuOpen}
                placeholder="Select type"
                inputValue={inputValue}
                onInputChange={(newValue) => setInputValue(newValue)}
              />
              {errors?.profile_type && (
                <span className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors?.profile_type?.value?.message}
                </span>
              )}
            </div>
            {profileType?.value === "company" && (
              <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
                <label className="font-medium text-[1rem] text-[#707070]">
                  Company Name*
                </label>
                <input
                  type="text"
                  placeholder="Enter company"
                  {...register("company_name")}
                  className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
                />
                {errors?.company_name && (
                  <span className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                    {errors?.company_name?.message.charAt(0).toUpperCase() +
                      errors?.company_name?.message.slice(1)}
                  </span>
                )}
              </div>
            )}
            <PasswordField
              validation={register}
              fieldName="password"
              label="Password"
              error={errors?.password?.message}
            />
            <PasswordField
              validation={register}
              fieldName="confirm_password"
              label="Repeat Password"
              error={errors?.confirm_password?.message}
            />
          </div>
          <div className="last-sec ml-[4rem] mt-[1.5rem] w-auto">
            <div className="flex items-center family-Ubuntu w-full">
              <input type="checkbox" className="w-[1rem] h-[1rem]" />
              &nbsp;&nbsp;
              <span className="font-medium text-[1rem] text-[#707070]">
                I agree to all terms, Privacy policy & Fee.*
              </span>
            </div>
            <button
              type="submit"
              className="bg-[#FC6935] text-white family-outfit font-[600] text-[1rem] mt-[1.8rem] cursor-pointer rounded-[2.3rem] py-[0.7rem] px-[1.5rem] w-full"
            >
              Register Account
            </button>
            <div className="">
              <div className="flex items-center mt-[1rem]">
                <span className="border border-[#D5D8DC] w-[50%]"></span>
                <span className="text-[#707070] font-[400] text-[12px] px-[0.6rem]">
                  OR
                </span>
                <span className="border border-[#D5D8DC] w-[50%]"></span>
              </div>
              <div className="family-outfit font-[400] text-[16px] text-[#696F79] flex justify-center mt-[1.5rem]">
                Already have an account?{" "}
                <Link
                  to="/login"
                  className="relative text-[#FC6935] cursor-pointer hover:underline hover:decoration-[#FC6935]"
                >
                  &nbsp;Sign In
                </Link>
              </div>
            </div>
          </div>
        </form>
      </div>
      <div className="right w-[50%]">
        <img src={AuthBg} alt="" className="w-full h-full object-fill" />
      </div>
    </div>
  );
}
