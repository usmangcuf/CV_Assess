import React, { useEffect } from "react";
import Back from "../../../assets/img/arrow-back.svg";
import Google from "../../../assets/img/google.svg";
import FB from "../../../assets/img/fb.svg";
import Apple from "../../../assets/img/apple.svg";
import AuthBg from "../../../assets/img/auth-bg.png";
import { Link, useNavigate } from "react-router-dom";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import PasswordField from "../../utlis/PasswordField";
import { api } from "../../utlis/customAPI";
import toast from "react-hot-toast";

export default function login({ setProgress, progress }) {
  const navigate = useNavigate();
  const schema = yup.object().shape({
    email: yup.string().email().required(),
    password: yup.string().required(),
  });

  const {
    handleSubmit,
    register,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const onSubmit = (data) => {
    setProgress(30);

    const payload = {
      email: data.email,
      password: data.password,
    };

    api
      .post("/auth/login", payload, { withCredentials: true })
      .then((res) => {
        setProgress(60);
        localStorage.setItem("ai-token", res.data.token);
        toast.success("Login successfully.");
        localStorage.setItem("ai-user", JSON.stringify(res.data.user));
        if (
          res.data.user.profile_type === "company" ||
          res.data.user.profile_type === "hr"
        ) {
          navigate("/company");
        }
        if (res.data.user.profile_type === "user") {
          navigate("/");
        }
      })
      .catch((error) => {
        console.log(error.response.data.message);
        toast.error(error.response.data.message);
      })
      .finally(() => {
        setProgress(100);
      });
  };

  return (
    <div className="login bg-white p-[1.5rem] flex gap-x-[6.2rem]">
      <div className="left mt-[4.8rem] w-[50%]">
        <div className="flex flex-col top-sec">
          <div className="flex items-center gap-3.5 family-Ubuntu w-fit cursor-pointer">
            <Link
              to="/home"
              className="flex items-center gap-3.5 family-Ubuntu w-fit cursor-pointer"
            >
              <img src={Back} className="h-[0.8rem] w-[0.6rem]" />
              <span className="text-[1rem] text-[#707070] font-medium pb-[2px]">
                Home
              </span>
            </Link>
          </div>
          <div className="flex flex-col mt-[1.5rem] ml-[4rem]">
            <h3 className="text-[1.5rem] font-[600] family-outfit">
              Welcome Back
            </h3>
            <p className="family-outfit font-[400] text-[#707070] text-[1rem] leading-[1.25rem] pt-[1rem] pb-[1.5rem] max-w-[21rem]">
              For security abd personalized access, your credentials are
              required.
            </p>
          </div>
        </div>
        <hr className="border-0 bg-[#D5D8DC] m-auto w-[300px] my-[1.5rem] h-[2px]" />
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="form-sec flex flex-col w-auto mt-[1.5rem] ml-[4rem] gap-[1.3rem]">
            <div className="family-outfit flex flex-col items-baseline gap-[0.6rem]">
              <label className="font-[500] text-[1rem] text-[#707070]">
                Email address*
              </label>
              <input
                type="text"
                placeholder="Enter email address"
                {...register("email")}
                className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
              />
              {errors?.email && (
                <span className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors?.email?.message.charAt(0).toUpperCase() +
                    errors?.email?.message.slice(1)}
                </span>
              )}
            </div>
            <PasswordField
              validation={register}
              label={"Password"}
              fieldName="password"
              error={errors?.password?.message}
            />
          </div>
          <div className="last-sec ml-[4rem] mt-[1.5rem] w-auto">
            <Link to="/forgot-password">
              <div className="w-fit float-right font-[500] text-[1rem] text-[#FC6935] family-outfit cursor-pointer">
                Forgot Password?
              </div>
            </Link>
            <button
              type="submit"
              disabled={progress}
              className="bg-[#FC6935] text-white family-outfit font-[600] text-[1rem] mt-[1.8rem] cursor-pointer rounded-[2.3rem] py-[0.7rem] px-[1.5rem] w-full"
            >
              Sign In
            </button>
            <div className="flex items-center mt-[1rem]">
              <span className="border border-[#D5D8DC] w-[50%]"></span>
              <span className="text-[#707070] font-[400] text-[12px] px-[0.6rem]">
                OR
              </span>
              <span className="border border-[#D5D8DC] w-[50%]"></span>
            </div>
            <div className="family-outfit font-[400] text-[16px] text-[#696F79] flex justify-center mt-[1.5rem]">
              Not have an account?{" "}
              <Link
                className="relative text-[#FC6935] cursor-pointer hover:underline hover:decoration-[#FC6935]"
                to="/signup"
              >
                &nbsp;Sign Up
              </Link>
            </div>
          </div>
        </form>
      </div>
      <div className="right w-[50%]">
        <img src={AuthBg} alt="" className="w-full h-full object-fill" />
      </div>
    </div>
  );
}
