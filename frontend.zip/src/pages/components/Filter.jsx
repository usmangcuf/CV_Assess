import { useEffect, useState } from "react";
import { Range } from "react-range";
import {
  employmentTypes as employmentTypeOptions,
  experienceLevels,
  jobLocationOptions,
} from "../json/jobFormUtils";

export default function Filter({ onFilterChange, currentQuery, loading }) {
  // — Local state for each filter —
  const [employmentTypes, setEmploymentTypes] = useState([]);
  const [jobLocations, setJobLocations] = useState([]);
  const [selectedLevels, setSelectedLevels] = useState([]);
  const [selectedSalary, setSelectedSalary] = useState(null);
  const [customRange, setCustomRange] = useState([1000, 25000]);
  // — Sync from URL query into local state —
  useEffect(() => {
    setEmploymentTypes(
      (currentQuery.job_type || "").split(",").filter(Boolean)
    );
    setJobLocations(
      (currentQuery.job_location || "").split(",").filter(Boolean)
    );
    setSelectedLevels((currentQuery.level || "").split(",").filter(Boolean));
  }, [currentQuery.job_type, currentQuery.job_location, currentQuery.level]);

  useEffect(() => {
    const { min_salary, max_salary } = currentQuery;
    if (min_salary && max_salary) {
      const min = Number(min_salary),
        max = Number(max_salary);
      setSelectedSalary({ min, max });
      setCustomRange([min, max]);
    } else {
      setSelectedSalary(null);
      setCustomRange([1000, 25000]);
    }
  }, [currentQuery.min_salary, currentQuery.max_salary]);

  // — Helpers —
  const toggleArrayValue = (arr, setter, value) =>
    setter((prev) =>
      prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value]
    );

  // — Actions —
  const clearAll = () => {
    setEmploymentTypes([]);
    setJobLocations([]);
    setSelectedLevels([]);
    setSelectedSalary(null);
    setCustomRange([1000, 25000]);
    onFilterChange({
      job_type: "",
      job_location: "",
      level: "",
      min_salary: "",
      max_salary: "",
    });
  };

  const applyFilters = () => {
    const filters = {};
    if (employmentTypes.length) filters.job_type = employmentTypes.join(",");
    if (jobLocations.length) filters.job_location = jobLocations.join(",");
    if (selectedLevels.length) filters.level = selectedLevels.join(",");
    if (selectedSalary) {
      filters.min_salary = selectedSalary.min;
      filters.max_salary = selectedSalary.max;
    }

    onFilterChange(filters);
  };

  const ShimmerItem = ({ width = "100%", height = "20px" }) => (
    <div
      className="animate-pulse bg-[#E1E3E8] rounded"
      style={{ width, height }}
    />
  );

  if (loading) {
    return (
      <div className="filter-side mt-2.5">
        <div className="mt-[3rem]">
          <div className="flex justify-between items-center mb-[1rem]">
            <ShimmerItem width="80px" height="20px" />
            <ShimmerItem width="50px" height="20px" />
          </div>
          <div className="relative">
            <ShimmerItem height="40px" />
          </div>
        </div>

        <div className="mt-[1.5rem]">
          <div className="flex justify-between items-center">
            <ShimmerItem width="120px" height="20px" />
            <ShimmerItem width="70px" height="20px" />
          </div>
          <div className="grid grid-cols-2 gap-2 mt-[1.5rem] pb-6 border-b-2 border-[#F7F7F7]">
            {[...Array(4)].map((_, i) => (
              <div className="flex items-center gap-3" key={i}>
                <ShimmerItem width="20px" height="20px" />
                <ShimmerItem width="80px" height="20px" />
              </div>
            ))}
          </div>
        </div>

        <div className="mt-[1.5rem]">
          <div className="flex justify-between items-center">
            <ShimmerItem width="150px" height="20px" />
            <ShimmerItem width="70px" height="20px" />
          </div>
          <div className="grid grid-cols-2 gap-2 mt-[1.5rem] pb-6 border-b-2 border-[#F7F7F7]">
            {[...Array(4)].map((_, i) => (
              <div className="flex items-center gap-3" key={i}>
                <ShimmerItem width="20px" height="20px" />
                <ShimmerItem width="100px" height="20px" />
              </div>
            ))}
          </div>
        </div>

        <div className="mt-[1.5rem]">
          <div className="flex justify-between items-center">
            <ShimmerItem width="120px" height="20px" />
            <ShimmerItem width="50px" height="20px" />
          </div>
          <div className="grid grid-cols-2 gap-2 mt-[1.5rem]">
            {[...Array(4)].map((_, i) => (
              <div className="flex items-center gap-2" key={i}>
                <ShimmerItem width="20px" height="20px" />
                <ShimmerItem width="100px" height="20px" />
              </div>
            ))}
          </div>
        </div>

        <ShimmerItem height="40px" className="mt-6" />
        <ShimmerItem height="40px" className="mt-4" />
      </div>
    );
  }
  return (
    <div className="filter-side mt-2.5 space-y-6">
      {/* Job Location */}
      <section>
        <header className="flex justify-between items-center">
          <h2 className="cursor-pointer text-[#707070] text-lg font-bold">
            Job Location
          </h2>
          <button
            className="text-[#FC6935]"
            onClick={() => {
              setJobLocations([]);
              onFilterChange({ job_location: "" });
            }}
          >
            Clear
          </button>
        </header>
        <div className="grid grid-cols-2 gap-2 mt-3">
          {jobLocationOptions.map(({ label, value }, idx) => (
            <label key={idx} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={jobLocations.includes(value)}
                onChange={() =>
                  toggleArrayValue(jobLocations, setJobLocations, value)
                }
                className="accent-orange-500"
              />
              <span className="text-[#707070]">{label}</span>
            </label>
          ))}
        </div>
      </section>

      {/* Employment Type */}
      <section>
        <header className="flex justify-between items-center">
          <h2 className="cursor-pointer text-[#707070] text-lg font-bold">
            Employment Type
          </h2>
          <button
            className="text-[#FC6935]"
            onClick={() => {
              setEmploymentTypes([]);
              onFilterChange({ job_type: "" });
            }}
          >
            Clear
          </button>
        </header>
        <div className="grid grid-cols-2 gap-2 mt-3">
          {employmentTypeOptions.map(({ label, value }, idx) => (
            <label key={idx} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={employmentTypes.includes(value)}
                onChange={() =>
                  toggleArrayValue(employmentTypes, setEmploymentTypes, value)
                }
                className="accent-orange-500"
              />
              <span className="text-[#707070]">{label}</span>
            </label>
          ))}
        </div>
      </section>

      {/* Experience Level */}
      <section>
        <header className="flex justify-between items-center">
          <h2 className="cursor-pointer text-[#707070] text-lg font-bold">
            Experience
          </h2>
          <button
            className="text-[#FC6935]"
            onClick={() => {
              setSelectedLevels([]);
              onFilterChange({ level: "" });
            }}
          >
            Clear
          </button>
        </header>
        <div className="grid grid-cols-2 gap-2 mt-3">
          {experienceLevels.map(({ label, value }, idx) => (
            <label key={idx} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={selectedLevels.includes(value)}
                onChange={() =>
                  toggleArrayValue(selectedLevels, setSelectedLevels, value)
                }
                className="accent-orange-500"
              />
              <span className="text-[#707070]">{label}</span>
            </label>
          ))}
        </div>
      </section>

      {/* Salary Range */}
      <section>
        <header className="flex justify-between items-center">
          <h2 className="text-[#707070] text-lg font-bold">Salary Range</h2>
          <button
            className="text-[#FC6935]"
            onClick={() => {
              setSelectedSalary(null);
              setCustomRange([1000, 25000]);
              onFilterChange({ min_salary: "", max_salary: "" });
            }}
          >
            Clear
          </button>
        </header>

        <div className="mt-4 px-2">
          <Range
            step={500}
            min={1000}
            max={50000}
            values={customRange}
            onChange={(vals) => {
              setCustomRange(vals);
              setSelectedSalary({ min: vals[0], max: vals[1] });
            }}
            renderTrack={({ props, children }) => (
              <div {...props} className="h-2 bg-gray-200 rounded-full relative">
                <div
                  className="absolute bg-[#FC6935] h-2 rounded-full"
                  style={{
                    left: `${((customRange[0] - 1000) / 49000) * 100}%`,
                    right: `${100 - ((customRange[1] - 1000) / 49000) * 100}%`,
                  }}
                />
                {children}
              </div>
            )}
            renderThumb={({ props }) => (
              <div
                {...props}
                className="w-5 h-5 bg-[#FC6935] rounded-full border-2 border-white"
              />
            )}
          />

          <div className="flex justify-between text-[#707070] font-medium mt-2">
            <span>Min: ${customRange[0]}</span>
            <span>Max: ${customRange[1]}</span>
          </div>
        </div>
      </section>

      {/* Actions */}
      <button
        onClick={applyFilters}
        className="w-full bg-[#FC6935] text-white py-2 rounded-full cursor-pointer"
      >
        Apply Filters
      </button>
      <button
        onClick={clearAll}
        className="w-full bg-white text-[#FC6935] border border-[#FC6935] py-2 rounded-full cursor-pointer"
      >
        Clear All
      </button>
    </div>
  );
}
