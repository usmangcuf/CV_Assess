import { Editor } from "@tinymce/tinymce-react";
import { useState } from "react";

export default function CustomEditor({
  value,
  onChange,
  placeholder,
  isReadOnly,
}) {
  const [isEditorLoading, setIsEditorLoading] = useState(true);

  return (
    <>
      {/* Always render the editor, but conditionally show a loading shimmer */}
      <Editor
        tinymceScriptSrc="/js/tinymce/tinymce.min.js" // link to local TinyMCE
        onInit={() => setIsEditorLoading(false)} // Set loading state to false when initialized
        value={value}
        init={{
          height: 400,
          menubar: false,
          statusbar: false,
          branding: false,
          readonly: isReadOnly,
          disabled: isReadOnly,
          placeholder: placeholder,
          plugins: [
            "advlist",
            "autolink",
            "lists",
            "link",
            "charmap",
            "preview",
            "anchor",
            "searchreplace",
            "visualblocks",
            "code",
            "fullscreen",
            "insertdatetime",
            "media",
            "table",
            "paste",
            "help",
            "wordcount",
          ],
          toolbar: isReadOnly
            ? false
            : "undo redo | formatselect | bold italic backcolor | \
            alignleft aligncenter alignright alignjustify | \
            bullist numlist outdent indent | removeformat | help",
          setup: (editor) => {
            editor.on("init", () => {
              if (isReadOnly) {
                editor.getBody().setAttribute("contenteditable", false); // Explicitly disable editing
              }
            });
          },
        }}
        onEditorChange={isReadOnly ? null : (newValue) => onChange(newValue)}
      />

      {/* Show a shimmer effect while the editor is loading */}
      {isEditorLoading && (
        <div className="h-[400px] border-2 border-[#eee] bg-white left-0 bottom-0 top-0 right-0 flex items-center justify-center absolute rounded-[10px]">
          <p style={{ color: "#888", fontSize: "14px" }}>Loading editor...</p>
        </div>
      )}
    </>
  );
}
