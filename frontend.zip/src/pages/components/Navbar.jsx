import React, { useEffect, useState } from "react";
import User from "../../assets/img/user.png";
import Noti from "../../assets/img/notification.svg";
import { Link, useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

export default function Navbar({ landing, progress }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const user = JSON.parse(localStorage.getItem("ai-user"));
  const token = localStorage.getItem("ai-token");

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDarkMode]);

  const handleLogOut = () => {
    localStorage.removeItem("ai-token");
    localStorage.removeItem("ai-user");
    navigate("/login");
  };

  const handleProtectedLinkClick = (e, path) => {
    e.preventDefault();
    if (!token) {
      toast("Please login to access this page");
      navigate("/login");
    } else {
      navigate(path);
    }
  };

  const getActiveClass = (paths) => {
    return paths.some((path) => location.pathname.startsWith(path))
      ? "text-[#000000]"
      : "text-[#707070]";
  };

  return (
    <div className="bg-[#F6F3EA] dark:bg-dark-900 family-outfit fixed top-0 w-available z-10 shadow-[0px_4px_10px_rgba(246,243,234,0.8)]">
      <div className="flex justify-between items-center">
        <div className="flex gap-[4rem]">
          <div>
            <a
              href="#"
              className="flex items-center py-[1.8rem] px-[5rem] cursor-default"
            >
              <span className="font-semibold text-[#000] text-[1.5rem] cursor-pointer">
                LOGO
              </span>
            </a>
          </div>
          <div className="flex items-center gap-[2.5rem]">
            <Link
              to="/home"
              className={`text-[#000000] text-[1rem] font-medium h-available relative flex items-center`}
            >
              {!progress && ["/", "/home"].includes(location.pathname) && (
                <span className="absolute bg-[#FC6935] w-available top-0 h-[0.188rem]"></span>
              )}
              Home
            </Link>

            <Link
              to="/view-job"
              className={`text-[#000000] text-[1rem] font-medium h-available relative flex items-center`}
            >
              {!progress && location.pathname.startsWith("/view-job") && (
                <span className="absolute bg-[#FC6935] w-available top-0 h-[0.188rem]"></span>
              )}
              Find Job
            </Link>

            {token && user && (
              <>
                <Link
                  to="/my-job"
                  onClick={(e) => handleProtectedLinkClick(e, "/my-job")}
                  className={`text-[#000000] text-[1rem] font-medium h-available relative flex items-center`}
                >
                  {!progress && ["/my-job"].includes(location.pathname) && (
                    <span className="absolute bg-[#FC6935] w-available top-0 h-[0.188rem]"></span>
                  )}
                  <span>My Jobs</span>
                </Link>
                <Link
                  to="/report"
                  onClick={(e) => handleProtectedLinkClick(e, "/report")}
                  className={`text-[#000000] text-[1rem] font-medium h-available relative flex items-center`}
                >
                  {!progress && ["/report"].includes(location.pathname) && (
                    <span className="absolute bg-[#FC6935] w-available top-0 h-[0.188rem]"></span>
                  )}
                  <span>Report</span>
                </Link>
              </>
            )}
          </div>
        </div>
        <div className="px-[5rem] flex gap-[1rem]">
          {user ? (
            <div className="flex items-center gap-[1rem] relative">
              <div className="border border-white rounded-full p-[0.75rem] cursor-pointer bg-white hover:bg-gray-100 transition-colors">
                <img
                  src={Noti}
                  className="w-[1rem] h-[1rem]"
                  alt="Notifications"
                />
              </div>

              <div className="relative group">
                <div className="user flex items-center gap-[0.75rem] cursor-pointer">
                  <img
                    src={user ? user?.personalInfo?.image_url : User}
                    className="w-[2.5rem] h-[2.5rem] object-cover rounded-full"
                    alt="User"
                  />
                  <div className="flex flex-col">
                    <strong className="text-[#000000] font-medium text-[1rem]">
                      {user?.first_name} {user?.last_name}
                    </strong>
                    <small className="text-[0.75rem] text-[#000] font-normal">
                      UI/UX Designer
                    </small>
                  </div>
                </div>

                <div
                  className="absolute right-0 top-full mt-2 w-56 origin-top-right scale-0 opacity-0 
                             group-hover:scale-100 group-hover:opacity-100 transition-all duration-200 
                             bg-white rounded-md shadow-lg z-50 overflow-hidden"
                >
                  <div className="py-1">
                    <Link
                      to="/profile"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-orange-600 transition-colors"
                    >
                      View Profile
                    </Link>
                    <button
                      onClick={handleLogOut}
                      className="w-full text-left px-4 py-2 cursor-pointer text-sm text-gray-700 hover:bg-orange-50 hover:text-orange-600 transition-colors"
                    >
                      Log Out
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div>
              <Link
                to="/login"
                className="hover:underline hover:text-[#FC6935] cursor-pointer"
              >
                Sign In
              </Link>{" "}
              /{" "}
              <Link
                to="/signup"
                className="hover:underline hover:text-[#FC6935] cursor-pointer"
              >
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
