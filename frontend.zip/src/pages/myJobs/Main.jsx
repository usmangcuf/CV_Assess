import React, { useState, useEffect } from "react";
import Options from "./Options";
import JobCard from "../job/JobCard";
import { api } from "../utlis/customAPI";
import toast from "react-hot-toast";
import { JobLoader } from "../utlis/shimmer";

export default function Main({ setProgress, progress }) {
  const [selectedOption, setSelectedOption] = useState("Saved");
  const [allJobs, setAllJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const options = ["Saved", "Applied"];

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setProgress(30);
        setLoading(true);
        const response = await api.get("/candidate/my-jobs");
        setAllJobs(response.data || []);
      } catch (error) {
        toast.error("Something went wrong!");
        console.error("Error fetching jobs:", error);
        setAllJobs([]);
      } finally {
        setProgress(100);
        setLoading(false);
      }
    };
    fetchJobs();
  }, []);

  useEffect(() => {
    if (selectedOption === "Applied") {
      setFilteredJobs(allJobs?.jobs?.filter(job => job?.isApplied));
    } else {
      setFilteredJobs(allJobs?.jobs?.filter(job => job?.isSaved));
    }
  }, [selectedOption, allJobs]);

  return (
    <div className="family-outfit mt-[5.8rem]">
      <div className="px-20 w-full flex gap-16">
        <div className="w-[20%] border-r-3 border-[#F7F7F7] fixed h-screen">
          <div className="py-12">
            <Options
              options={options}
              selectedOption={selectedOption}
              setSelectedOption={setSelectedOption}
            />
          </div>
        </div>

        <div className="w-[80%] ml-88">
          <div className="py-12">
            {loading ? (
              <div className="flex flex-col gap-6">
                {[...Array(5)].map((_, i) => (
                  <JobLoader key={i} />
                ))}
              </div>
            ) : filteredJobs?.length > 0 ? (

              <JobCard
                data={filteredJobs}
                active={"No"}
                loading={loading}
                setProgress={setProgress}
                progress={progress}
              />
            ) : (
              <>
                <div className="flex flex-col items-center justify-center py-12">
                  <img
                    src="https://cdn-icons-png.flaticon.com/512/4076/4076478.png"
                    alt="No jobs found"
                    className="w-32 h-32 opacity-50 mb-4"
                  />
                  <h3 className="text-xl font-semibold text-gray-600">
                    No jobs found
                  </h3>
                  <p className="text-gray-500 mt-2">
                    {selectedOption === "Saved"
                      ? "You haven't saved any jobs yet."
                      : "You haven't applied to any jobs yet."}
                  </p>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}