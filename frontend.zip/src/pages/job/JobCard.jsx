import React, { useEffect, useState } from "react";
import Save from "../../assets/img/save.svg";
import Saved from "../../assets/img/saved.svg";
import World from "../../assets/img/world-black.svg";
import Salary from "../../assets/img/salary.svg";
import JobType from "../../assets/img/job-type.svg";
import Google from "../../assets/img/google.svg";
import { Link } from "react-router-dom";
import { JobLoader } from "../utlis/shimmer";
import { api } from "../utlis/customAPI";
import numeral from "numeral";
import toast from "react-hot-toast";
import ApplyJob from "./applyJob";

export default function JobCard({
  active,
  data,
  loading,
  landing,
  setProgress,
  progress,
}) {
  const [jobs, setJobs] = useState();
  const [activeJob, setActiveJob] = useState(active === "No" ? null : 0);
  const [open, setOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);

  const handleOpen = (e, job) => {
    e.stopPropagation();
    e.preventDefault();
    const token = localStorage.getItem("ai-token");
    if (!token) {
      toast.error("Please login to apply for the job");
      return;
    }
    setOpen(true);
    setSelectedJob(job);
  };

  const handleClose = (e) => {
    setOpen(false);
  };

  useEffect(() => {
    setJobs(data);
  }, [data]);

  const handleSaveJob = (job_id, company_id, isSaved, e) => {
    e.preventDefault();
    e.stopPropagation();

    setProgress(30);
    const token = localStorage.getItem("ai-token");
    if (!token) {
      alert("Please login to save the job");
      return;
    }
    const payload = {
      company_id,
      job_id,
      action: isSaved ? "unsave" : "save",
    };
    api
      .post(`/candidate/toggle-save`, payload)
      .then(({ data }) => {
        setJobs((prevJobs) =>
          prevJobs.map((job) =>
            job._id === job_id ? { ...job, isSaved: !isSaved } : job
          )
        );
        setProgress(60);
        toast.success(`Job ${isSaved ? "Unsaved" : "Saved"} Successfully!`);
      })
      .catch((error) => {
        toast.error(error?.response?.data?.message);
        console.error(error);
      })
      .finally(() => {
        setProgress(100);
      });
  };

  const getDaysAgo = (dateString) => {
    const createdDate = new Date(dateString);
    const currentDate = new Date();

    const diffInMs = currentDate - createdDate;
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

    return diffInDays === 0 ? "Today" : `${diffInDays}`;
  };

  return (
    <div className="flex flex-col gap-6">
      {loading
        ? [...Array(7)].map((_, i) => <JobLoader key={i} />)
        : jobs?.map((job, i) => (
            <Link
              key={i}
              className={`p-[1.5rem] border-2 rounded-[1rem] job-card ${
                activeJob === i
                  ? "bg-[#F6F3EA] border-[#94949470]"
                  : "border-[#F7F7F7]"
              }`}
              to={`${
                landing ? `/home/view-job/${job._id}` : `/view-job/${job._id}`
              }`}
            >
              <div className="head flex justify-between items-center">
                <h1 className="font-semibold text-[1.5rem] cursor-pointer">
                  {job?.title}
                </h1>
                <div
                  className={`border-2 ${
                    activeJob === i
                      ? "border-[#94949470] bg-white"
                      : "border-[#F7F7F7]"
                  } rounded-full p-[0.75rem] cursor-pointer`}
                  onClick={(e) => {
                    handleSaveJob(
                      job._id,
                      job?.company_id?._id,
                      job?.isSaved,
                      e
                    );
                  }}
                >
                  <img
                    src={job?.isSaved ? Saved : Save}
                    className="w-[1rem] h-[1rem]"
                    alt=""
                  />
                </div>
              </div>

              <div className="job-detail mt-[0.75rem]">
                <div className="flex items-center justify-between gap-[3.5rem] w-fit">
                  <div className="flex items-center gap-[1rem]">
                    <img src={World} className="w-[1rem] h-[1rem]" alt="" />
                    <span className="text-[1rem] font-medium text-[#707070]">
                      {job?.location || job?.address}
                    </span>
                  </div>
                  <div className="flex items-center gap-[1rem]">
                    <img src={JobType} className="w-[1rem] h-[1rem]" alt="" />
                    <span className="text-[1rem] font-medium text-[#707070]">
                      {job?.type || job?.job_type}
                    </span>
                  </div>
                  <div className="flex items-center gap-[1rem]">
                    <img src={Salary} className="w-[1rem] h-[1rem]" alt="" />
                    <span className="text-[1rem] font-medium text-[#707070]">
                      ${numeral(job?.salary?.min || job?.min_salary).format('0.0a')} - $
                      {numeral(job?.salary?.max || job?.max_salary).format('0.0a')}
                    </span>
                  </div>
                </div>

                <div className="descripation mt-[2.25rem] max-w-[48rem] w-full">
                  <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: job?.description?.length > 1000 ? job?.description?.slice(0, 1000) + "..." : job?.description }} />
                </div>

                <div
                  className={`apply-job mt-[1rem] border-t ${
                    activeJob === i ? "border-[#94949470]" : "border-[#F7F7F7]"
                  }`}
                >
                  <div className="pt-[1rem] flex items-center justify-between">
                    <div className="company w-fit flex items-center gap-[1rem]">
                      <div
                        className={`logo ${
                          activeJob === i
                            ? "border-[#94949470] bg-white"
                            : "border-[#F7F7F7]"
                        } rounded-[1.3rem] p-[0.5rem] w-fit h-fit`}
                      >
                        <img
                          src={Google}
                          className="w-[1rem] h-[1rem] cursor-pointer"
                          alt=""
                        />
                      </div>
                      <div>
                        <span
                          className="text-[#000] text-[1rem] font-bold underline cursor-pointer"
                          title={job?.company_id?.company}
                        >
                          {job?.company_id?.company &&
                            job?.company_id?.company
                              .replace(/_/g, " ")
                              .replace(/\b\w/g, (char) => char.toUpperCase())}
                        </span>

                        <p className="text-[0.75rem] text-[#707070] font-normal">
                          Posted {job?.createdAt && getDaysAgo(job.createdAt)}{" "}
                          {getDaysAgo(job.createdAt) === "Today"
                            ? ""
                            : "days ago"}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-32">
                      <div className="flex items-center">
                        {/* <div className="flex -space-x-2">
                          {applicants?.map((applicant) => (
                            <img
                              key={applicant.id}
                              src={applicant.img}
                              alt="Applicant"
                              className={`w-10 h-10 rounded-full border-2 cursor-pointer ${
                                activeJob === i
                                  ? "border-[#94949470]"
                                  : "border-white"
                              } object-cover`}
                            />
                          ))}
                        </div> */}
{/* 
                        <span className="text-[#707070] text-[1rem] font-normal ml-3">
                          10+ Applications
                        </span> */}
                      </div>
                      <button
                        onClick={(e) => handleOpen(e, job)}
                        className={`${
                          job?.isApplied && activeJob === i
                            ? "text-[#FC6935] border-2 border-[#FC6935] bg-white"
                            : job?.isApplied
                            ? "text-[#FC6935] bg-[#F6F3EA]"
                            : "bg-[#FC6935] text-white"
                        } rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer`}
                        disabled={job?.isApplied}
                      >
                        {job?.isApplied ? "Applied" : "Apply Now"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
      <ApplyJob
        open={open}
        handleClose={handleClose}
        selectedJob={selectedJob}
        setProgress={setProgress}
        progress={progress}
      />
    </div>
  );
}
