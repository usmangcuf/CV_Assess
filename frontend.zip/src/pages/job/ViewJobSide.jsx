import React, { useState } from "react";
import User1 from "../../assets/img/user1.png";
import User2 from "../../assets/img/user2.png";
import User3 from "../../assets/img/user3.png";
import Share from "../../assets/img/share.svg";
import SaveOrange from "../../assets/img/save-orange.svg";
import Down from "../../assets/img/arrow-down.svg";
import { FiChevronDown, FiChevronUp } from "react-icons/fi";

const faqs = [
  {
    question: "Does this company sponsor visas?",
    answer:
      "Visa sponsorship is rare unless specifically mentioned in the job listing. Generally, you'll need an active work visa to be eligible for these positions.",
  },
  {
    question: "Can Open Doors refer me for this Position?",
    answer:
      "Open Doors can assist in your application but does not guarantee a referral.",
  },
];

export default function ViewJobSide() {
  const [openIndex, setOpenIndex] = useState(null);
  const [loading, setLoading] = useState(true);

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const applicants = [
    { id: 1, img: User1 },
    { id: 2, img: User2 },
    { id: 3, img: User3 },
  ];
  return (
    <div className="bg-[#F6F3EA] p-6 rounded-2xl">
      <div className="pb-[1.75rem] border-b-2 border-white">
        <h1 className="font-semibold text-2xl">Apply for this job:</h1>
        <p className="text-[1rem] font-normal pt-4">
          A graphic design job involves creating visual content for branding,
          marketing, and digital platforms. Designers use creativity and
          software tools to craft logos
        </p>

        <div className="flex items-center mt-6">
          <div className="flex -space-x-2">
            {applicants.map((applicant) => (
              <img
                key={applicant.id}
                src={applicant.img}
                alt="Applicant"
                className={`w-10 h-10 rounded-full border-2 border-white object-cover cursor-pointer`}
              />
            ))}
          </div>

          <span className="text-[#707070] text-[1rem] font-normal ml-3">
            10+ Applications
          </span>
        </div>

        <button className="mt-8 bg-[#FC6935] text-white text-[1rem] font-semibold rounded-[3.1rem] w-full py-[0.6rem] text-center cursor-pointer">
          Apply Now
        </button>

        <div className="mt-7">
          <div className="flex justify-between">
            <div className="text-[#FC6935] text-[1rem] font-semibold py-[0.6rem] px-[3.1rem] border border-[#FC6935] rounded-[3.1rem] flex gap-3 cursor-pointer">
              <img src={Share} alt="" />
              Share
            </div>
            <div className="text-[#FC6935] text-[1rem] font-semibold py-[0.6rem] px-[3.1rem] border border-[#FC6935] rounded-[3.1rem] flex gap-3 cursor-pointer">
              <img src={SaveOrange} alt="" />
              Save
            </div>
          </div>
        </div>
      </div>

      <div className="mt-[2.25rem]">
        <h2 className="text-2xl font-semibold mb-4">FAQ:</h2>
        {faqs.map((faq, index) => (
          <div
            key={index}
            className={`py-3 ${index === faqs.length - 1 ? "!pb-0" : ""}`}
          >
            <button
              onClick={() => toggleFAQ(index)}
              className="flex justify-between items-center w-full text-left text-[1rem] font-medium cursor-pointer"
            >
              {faq.question}
              {openIndex === index ? (
                <img
                  src={Down}
                  className="transition-transform duration-300 rotate-180"
                />
              ) : (
                <img src={Down} className="transition-transform duration-300" />
              )}
            </button>
            {openIndex === index && (
              <p className="mt-3 text-[#707070] text-base font-normal">
                {faq.answer}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
