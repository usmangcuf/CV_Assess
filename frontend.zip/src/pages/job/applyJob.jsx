import React, { useState } from "react";
import { Modal, Box, Typography, Button } from "@mui/material";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import toast from "react-hot-toast";
import { api } from "../utlis/customAPI";
import { IoIosClose } from "react-icons/io";
import { supabase } from "../Private/lib/supabase";
import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";

export default function ApplyJob({
  open,
  handleClose,
  selectedJob,
  setProgress,
  progress,
}) {
  const [loading, setLoading] = useState(false);
  const [resumeFile, setResumeFile] = useState(null);

  const formSchema = yup.object().shape({
    name: yup.string().required("Name is required"),
    email: yup.string().email("Invalid email").required("Email is required"),
    phone: yup.string().required("Phone number is required"),
    resume: yup
      .mixed()
      .required("Resume is required")
      .test("fileType", "Only PDF files are accepted", (value) => {
        if (!value) return true;
        return value && value[0]?.type === "application/pdf";
      }),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm({
    resolver: yupResolver(formSchema),
  });

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setResumeFile(file);
      setValue("resume", e.target.files);
    }
  };

  const handleRemoveFile = () => {
    setResumeFile(null);
    setValue("resume", null);
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) {
      fileInput.value = "";
    }
  };

  const uploadResumeToSave = async (file) => {
    try {
      const fileName = `resumes/${Date.now()}_${file.name}`;

      const { data, error } = await supabase.storage
        .from("fyp-pdf")
        .upload(fileName, file);

      if (error) throw error;
      const expiresIn = 60 * 60 * 24 * 7;
      const {
        data: { signedUrl },
      } = await supabase.storage
        .from("fyp-pdf")
        .createSignedUrl(fileName, expiresIn);

      return signedUrl;
    } catch (error) {
      console.error("Upload error:", error);
      throw error;
    }
  };

  const onSubmit = async (data) => {
    setLoading(true);
    setProgress(40);

    try {
      const pdfUrl = await uploadResumeToSave(resumeFile);

      const formData = new FormData();
      formData.append("job_id", selectedJob?._id);
      formData.append("company_id", selectedJob?.company_id?._id);
      formData.append("name", data.name);
      formData.append("email", data.email);
      formData.append("phone", data.phone);
      formData.append("resume", resumeFile);
      formData.append("resume_url", pdfUrl);

      const res = await api.post("/candidate/apply-job", formData);
      toast.success("Job applied successfully!");
      setProgress(80);
      reset();
      handleClose();
      setResumeFile(null);
    } catch (err) {
      console.log(err);
      toast.error(err?.response?.data?.error || "Error applying for job");
    } finally {
      setProgress(100);
      setLoading(false);
    }
  };

  return (
    <div>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "50%",
            bgcolor: "background.paper",
            border: "1px solid #ccc",
            p: 4,
            borderRadius: 2,
          }}
        >
          <Typography id="keep-mounted-modal-title" variant="h5" component="h2">
            Enter your details
          </Typography>
          <form
            className="flex flex-col gap-4 mt-4"
            onSubmit={handleSubmit(onSubmit)}
            encType="multipart/form-data"
          >
            <div className="flex gap-1 flex-col">
              <input
                type="text"
                placeholder="Name"
                {...register("name")}
                className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
              />
              {errors.name && (
                <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors.name.message}
                </p>
              )}
            </div>

            <div className="flex gap-1 flex-col">
              <input
                type="email"
                placeholder="Email"
                {...register("email")}
                className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full"
              />
              {errors.email && (
                <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors.email.message}
                </p>
              )}
            </div>

            <div className="flex gap-1 flex-col">
              <PhoneInput
                {...register("phone")}
                defaultCountry="PK"
                className="border border-[#D5D8DC] rounded-[2.3rem] py-[0.7rem] px-[1.5rem] text-[#494949] w-full outline-0"
              />
              {errors.phone && (
                <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors.phone.message}
                </p>
              )}
            </div>

            <div className="flex gap-1 flex-col">
              <label className="block">
                <span className="sr-only">Upload Resume (PDF)</span>
                <input
                  type="file"
                  accept=".pdf,application/pdf"
                  onChange={handleFileChange}
                  className="block text-sm text-gray-500
                    file:mr-4 file:py-2 file:px-4
                    file:rounded-full file:border-0
                    file:text-sm file:font-semibold
                    file:bg-[#FC6935] file:text-white
                    hover:file:bg-[#e55b2a] w-fit"
                />
              </label>
              {errors.resume && (
                <p className="text-[0.8rem] text-red-600 pl-[1.5rem]">
                  {errors.resume.message}
                </p>
              )}
              {resumeFile && (
                <div className="flex items-center justify-between bg-gray-100 rounded-md p-2 mt-2 w-fit">
                  <span className="text-sm text-gray-600 truncate max-w-xs">
                    {resumeFile.name}
                  </span>
                  <button
                    type="button"
                    onClick={handleRemoveFile}
                    className="text-gray-500 hover:text-red-500 focus:outline-none"
                  >
                    <IoIosClose fontSize="23px" />
                  </button>
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className={`bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer ${
                loading ? 'opacity-90 cursor-not-allowed' : ''
              }`}
            >
              {loading ? 'Applying...' : 'Submit Application'}
            </button>
          </form>
        </Box>
      </Modal>
    </div>
  );
}
