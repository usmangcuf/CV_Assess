import { useEffect, useRef, useState } from "react";
import {
  IMG_applications,
  IMG_createJob,
  IMG_dashboard,
  IMG_hr,
  IMG_interviews,
  IMG_jobs,
} from "./utlis/Images";

import "react-datepicker/dist/react-datepicker.css";
const customScrollListStyle = `
.custom-scroll-list {
  scrollbar-width: none; /* Firefox */
  -ms-overflow-style: none; /* IE 10+ */
}
.custom-scroll-list::-webkit-scrollbar {
  display: none; /* Chrome, Safari, Opera */
}
`;

import {
  Link,
  Navigate,
  Outlet,
  useLocation,
  useNavigate,
} from "react-router-dom";
const menuItems = [
  { label: "Dashboard", icon: IMG_dashboard, route: "/company/dashboard" },
  { label: "Jobs", icon: IMG_jobs, route: "/company/jobs" },
  {
    label: "Applications",
    icon: IMG_applications,
    route: "/company/applications",
  },
  { label: "Interviews", icon: IMG_interviews, route: "/company/interviews" },
  { label: "Recruiters", icon: IMG_hr, route: "/company/recruiters" },
];

export default function CompanyLayout() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [profile, setProfile] = useState();
  const hasRedirected = useRef(false);

  useEffect(() => {
    setProfile(JSON.parse(localStorage.getItem("ai-user")));
    const styleTag = document.createElement("style");
    styleTag.innerHTML = customScrollListStyle;
    document.head.appendChild(styleTag);
    return () => {
      document.head.removeChild(styleTag);
    };
  }, []);

  const token = localStorage.getItem("ai-token");
  const userStr = localStorage.getItem("ai-user");
  let profileType = null;

  if (userStr) {
    try {
      const user = JSON.parse(userStr);
      profileType = user.profile_type;
    } catch (e) {
      // ignore, will redirect below
    }
  }

  // After all hooks, do redirects
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  if (!userStr || !profileType) {
    return <Navigate to="/login" replace />;
  }
  if (!hasRedirected.current) {
    hasRedirected.current = true;
    if (profileType === "user") {
      return <Navigate to="/home" replace />;
    } else if (profileType === "company" || profileType === "hr") {
      return <Navigate to="/company/dashboard" replace />;
    }
  }

  const handleLogOut = () => {
    localStorage.removeItem("ai-token");
    localStorage.removeItem("ai-user");
    navigate("/login");
  };

  const shouldShow = (pathname, hidePaths = []) =>
    !hidePaths.some((path) => pathname.includes(path));

  const isShowSideBar = shouldShow(pathname, ["create-job", "update-job"]);
  const isShowNavHeader = shouldShow(pathname, ["create-job", "update-job"]);
  
  return (
    <div style={{ display: "flex", background: "#F6F3EA", maxHeight: "100vh" }}>
      {/* Sidebar */}
      {isShowSideBar && (
        <aside
          style={{
            width: 260,
            background: "#F6F3EA",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            padding: 0,
            minHeight: "100vh",
          }}
        >
          {/* Top: Logo, Profile, Menu */}
          <div>
            {/* Logo */}
            <div
              style={{
                fontWeight: 700,
                fontSize: 28,
                padding: "15px 0 0 15px",
                letterSpacing: 0,
              }}
            >
              LOGO
            </div>
            {/* Profile Card */}
            <div style={{ margin: "10px 0 0 0", padding: "0 15px 0 15px" }}>
              <div
                style={{
                  borderBottom: "2px solid #FFFFFF",
                  borderTop: "2px solid #FFFFFF",
                  paddingBottom: 18,
                  paddingTop: 18,
                  display: "flex",
                  alignItems: "center",
                  gap: 14,
                  paddingRight: 18,
                  cursor: "pointer",
                }}
                onClick={() => navigate("/company/profile")}
              >
                <img
                  src={profile?.personalInfo?.image_url}
                  alt="profile"
                  style={{ width: 44, height: 44, borderRadius: "50%" }}
                />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 15, color: "#222" }}>
                    {profile && `${profile?.first_name} ${profile?.last_name}`}
                  </div>
                  <div
                    style={{ fontSize: 12.5, color: "#787878", marginTop: 2 }}
                  >
                    {profile && profile?.email}
                  </div>
                </div>
              </div>
            </div>
            {/* Menu Label */}
            <div
              style={{
                color: "#B0B0B0",
                fontSize: 12.5,
                fontWeight: 500,
                margin: "22px 0 0 15px",
                letterSpacing: 0.2,
              }}
            >
              Menu
            </div>
            {/* Menu */}
            <nav style={{ marginTop: 10 }}>
              <ul
                className="custom-scroll-list"
                style={{
                  listStyle: "none",
                  padding: 0,
                  margin: 0,
                  height: "50vh",
                  overflow: "auto",
                }}
              >
                {menuItems
                  .filter((item) => {
                    if (
                      profile?.profile_type === "hr" &&
                      item.label === "Recruiters"
                    ) {
                      return false; // exclude Recruiters for hr
                    }
                    return true;
                  })
                  .map((item, idx) => (
                    <li key={idx} style={{ marginBottom: 4 }}>
                      <Link
                        to={item.route}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 13,
                          background:
                            pathname.includes(item.route) ||
                            (item.label === "Jobs" &&
                              pathname.includes("/company/job/"))
                              ? "#FFEFE7"
                              : "transparent",
                          color:
                            pathname.includes(item.route) ||
                            (item.label === "Jobs" &&
                              pathname.includes("/company/job/"))
                              ? "#FF7A2F"
                              : "#6D6D6D",
                          borderRadius: 18,
                          fontWeight:
                            pathname.includes(item.route) ||
                            (item.label === "Jobs" &&
                              pathname.includes("/company/job/"))
                              ? 600
                              : 500,
                          padding:
                            pathname.includes(item.route) ||
                            (item.label === "Jobs" &&
                              pathname.includes("/company/job/"))
                              ? "9px 18px 9px 16px"
                              : "9px 18px 9px 16px",
                          cursor: "pointer",
                          fontSize: 15.2,
                          marginRight: 16,
                          marginLeft: 16,
                          boxShadow:
                            pathname.includes(item.route) ||
                            (item.label === "Jobs" &&
                              pathname.includes("/company/job/"))
                              ? "0px 1px 4px #fff0e6"
                              : "none",
                          transition: "background 0.2s, color 0.2s",
                        }}
                      >
                        <span
                          style={{
                            width: 22,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                          }}
                        >
                          <img
                            src={item.icon}
                            style={{
                              filter:
                                pathname.includes(item.route) ||
                                (item.label === "Jobs" &&
                                  pathname.includes("/company/job/"))
                                  ? "invert(48%) sepia(92%) saturate(2325%) hue-rotate(1deg) brightness(103%) contrast(101%)"
                                  : "none",
                            }}
                          />
                        </span>
                        {item.label}
                      </Link>
                    </li>
                  ))}
              </ul>
            </nav>
          </div>
          {/* Bottom: Profile Progress & Logout */}
          <div style={{ padding: "0 32px 32px 32px" }}>
            <div
              style={{
                borderTop: "1px solid #e7e3dc",
                paddingTop: 24,
                marginBottom: 14,
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  marginBottom: 9,
                }}
              >
                <div
                  style={{
                    flex: 1,
                    height: 6,
                    background: "#e7e3dc",
                    borderRadius: 6,
                    marginRight: 10,
                  }}
                >
                  <div
                    style={{
                      width: "70%",
                      height: 6,
                      background: "#23b26d",
                      borderRadius: 6,
                    }}
                  ></div>
                </div>
                <span
                  style={{ fontSize: 13, fontWeight: 600, color: "#232323" }}
                >
                  70%
                </span>
              </div>
              <div
                style={{
                  color: "#FF7A2F",
                  fontWeight: 600,
                  fontSize: 14,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                Complete Your Profile{" "}
                <span style={{ fontSize: 18, fontWeight: 700 }}>{">"}</span>
              </div>
            </div>
            <div
              onClick={() => navigate("/company/change-password")}
              className="py-5 flex items-center font-medium border-t-1 border-t-[#e7e3dc] text-[#B0B0B0] cursor-pointer gap-3 text-[15px]"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                fill="none"
                viewBox="0 0 24 24"
                stroke="#B0B0B0"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0110 0v4" />
              </svg>
              Change Password
            </div>

            <div
              onClick={handleLogOut}
              className="py-5 flex items-center font-medium border-t-1 border-t-[#e7e3dc] text-[#B0B0B0] cursor-pointer gap-3 text-[15px]"
            >
              <svg
                width="20"
                height="20"
                fill="none"
                stroke="#B0B0B0"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="10" cy="10" r="8" />
                <path d="M10 13v-3" />
                <circle cx="10" cy="15.5" r=".8" fill="#B0B0B0" />
              </svg>
              Log Out
            </div>
          </div>
        </aside>
      )}
      {/* Main Content */}
      <main
        style={{
          flex: 1,
          background: "#F6F3EA",
          maxHeight: "100vh",
          overflow: "auto",
        }}
      >
        {/* Header Bar */}
        {isShowNavHeader && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "13px 32px 14px 16px",
              background: "#fff",
              borderTopLeftRadius: 18,
              borderTopRightRadius: 18,
            }}
          >
            {/* Left Nav */}
            <div style={{ display: "flex", alignItems: "center", gap: 32 }}>
            
            </div>
          
            {/* Right Icons */}
            <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
              {/* Create Job Button */}
              <button
                style={{
                  background: "#FF7A2F",
                  color: "#fff",
                  border: "none",
                  borderRadius: 22,
                  fontWeight: 600,
                  fontSize: 15,
                  padding: "10px 26px 10px 18px",
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  cursor: "pointer",
                }}
                onClick={() => navigate("/company/create-job")}
              >
                {/* Placeholder pencil SVG */}
                <img src={IMG_createJob} alt="" />
                Create Job
              </button>
            </div>
          </div>
        )}
        {/* Main Outlet */}
        <Outlet />
      </main>
    </div>
  );
}
