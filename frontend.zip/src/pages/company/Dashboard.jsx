import moment from "moment";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { api } from "../utlis/customAPI";
import DashboardLoader from "../utlis/loader/DashboardLoader";

const CompanyDashboard = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    totalApplications: 0,
    totalShortlisted: 0,
    totalPostedJobs: 0,
    totalHRs: 0,
    jobChartData: [],
    applicationChartData: [],
    recentJobs: [],
    recentApplications: [],
    hrList: [],
    pendingInterviews: [],
  });
  const fetchDashBoardData = async () => {
    try {
      const response = await api.post(`/company/generate_report`);
      setDashboardData(response?.data);
    } catch (error) {
      toast.error(
        error?.response?.data?.message || "Error fetching dashboard data"
      );
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashBoardData();
  }, []);

  const {
    totalApplications,
    totalShortlisted,
    totalPostedJobs,
    totalHRs,
    jobChartData,
    applicationChartData,
    recentJobs,
    recentApplications,
    hrList,
    pendingInterviews,
  } = dashboardData;

  return (
    <div className="bg-[#F6F3EA] overflow-y-auto family-outfit min-h-screen">
      <div
        className="flex items-center mb-1 justify-between px-6 py-2 pb-5 bg-[#FFFFFF]"
        style={{ borderBottomLeftRadius: 18, borderBottomRightRadius: 18 }}
      >
        <h1 className="text-[2.1rem] font-semibold text-[#000000]">
          Dashboard
        </h1>
      </div>
      {isLoading ? (
        <DashboardLoader />
      ) : (
        <div className="flex flex-col gap-1 overflow-x-auto rounded-[1.13rem]">
          {/* Top Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-1">
            {[
              {
                title: "Total Applications",
                value: totalApplications,
                color: "#10b981", // green
              },
              {
                title: "Interview",
                value: totalShortlisted,
                color: "#f59e0b", // amber
              },
              {
                title: "Posted Jobs",
                value: totalPostedJobs,
                color: "#3b82f6", // blue
              },
              {
                title: "Recruiters",
                value: totalHRs,
                color: "#8b5cf6", // purple
              },
            ].map((card, idx) => {
              const percent = Math.min(card.value / 100, 1); // Adjust as needed
              return (
                <div
                  key={idx}
                  className="bg-white rounded-3xl flex flex-row items-center px-8 py-6 gap-1 min-h-[120px]"
                  style={{ minWidth: 280 }}
                >
                  {/* Circular Progress */}
                  <div className="relative w-20 h-20 flex items-center justify-center">
                    <svg width="80" height="80" className="block">
                      <circle
                        cx="40"
                        cy="40"
                        r="32"
                        fill="none"
                        stroke="#E5E7EB" // consistent gray background
                        strokeWidth="8"
                      />
                      <circle
                        cx="40"
                        cy="40"
                        r="32"
                        fill="none"
                        stroke={card.color}
                        strokeWidth="8"
                        strokeDasharray={2 * Math.PI * 32}
                        strokeDashoffset={2 * Math.PI * 32 * (1 - percent)}
                        strokeLinecap="round"
                        style={{ transition: "stroke-dashoffset 0.5s" }}
                      />
                    </svg>
                    <span
                      className="absolute inset-0 flex items-center justify-center text-2xl font-bold"
                      style={{ color: card.color }}
                    >
                      {card.value}
                    </span>
                  </div>

                  {/* Textual Info */}
                  <div className="flex flex-col justify-center items-start">
                    <div className="font-semibold text-lg text-gray-800 mb-1">
                      {card.title}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Chart and Tables section - two per row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-1">
            {/* Jobs Overview Chart */}

            <div className="bg-white rounded-3xl shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Jobs Overview
              </h2>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={jobChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#fff", borderRadius: 8 }}
                  />
                  <Bar dataKey="Jobs" fill="#2563eb" />{" "}
                  {/* Tailwind blue-600 */}
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Recent Jobs Table */}
            <div className="bg-white rounded-3xl shadow-md p-6 overflow-auto">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Recent Jobs
              </h2>
              <table className="min-w-full whitespace-nowrap">
                <thead>
                  <tr>
                    <th className="px-3 py-4 text-left">
                      <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">
                        Sr.
                      </span>
                    </th>
                    <th className="px-6 py-4 text-left">
                      <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">
                        JOB TITLE
                      </span>
                    </th>
                    <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">
                      JOB TYPE
                    </th>
                    <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">
                      DATE S/E
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {recentJobs && recentJobs.length > 0 ? (
                    recentJobs.map((job, idx) => (
                      <tr
                        key={idx}
                        className="border-t border-[#F4F4F5] hover:bg-[#FAFAFA] transition"
                      >
                        <td className="px-6 py-4 items-center">
                          <div className="font-semibold text-[#18181B] text-base">
                            {idx + 1}
                          </div>
                        </td>
                        <td className="px-6 py-4 flex items-center gap-4">
                          <div className="font-semibold text-[#18181B] text-base mt-1.5">
                            {job.title || "-- --"}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-[#18181B] font-medium text-sm">
                          {job.job_type || "-- --"}
                        </td>
                        <td className="px-4 py-4 text-[#18181B] text-sm">
                          <div>
                            {job.start_date
                              ? moment(job.start_date).format("LL")
                              : "-- --"}
                          </div>
                          <div className="text-xs text-[#A1A1AA]">
                            {job.end_date
                              ? moment(job.end_date).format("LL")
                              : "-- --"}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={4} className="h-24 text-center">
                        No jobs found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Recent Applications Table */}
            <div className="bg-white rounded-3xl shadow-md p-6 overflow-auto">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Recent Applications
              </h2>
              <table className="min-w-full whitespace-nowrap">
                <thead>
                  <tr>
                    <th className="px-3 py-4 text-left">
                      <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">
                        Sr.
                      </span>
                    </th>
                    <th className="px-6 py-4 text-left">
                      <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">
                        NAME / TITLE
                      </span>
                    </th>
                    <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">
                      APPLIED JOB
                    </th>
                    <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">
                      EMAIL / PHONE
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {recentApplications.length > 0 ? (
                    recentApplications.map((application, idx) => (
                      <tr
                        key={idx}
                        className="border-t border-[#F4F4F5] hover:bg-[#FAFAFA] transition"
                      >
                        <td className="px-6 py-4 items-center">
                          <div className="font-semibold text-[#18181B] text-base">
                            {idx + 1}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="font-semibold text-[#18181B] text-base cursor-pointer hover:underline">
                            {application.name || "-- --"}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-[#18181B] text-sm">
                          <div
                            className="cursor-pointer text-blue-700 underline"
                            onClick={() =>
                              window.open(
                                `/company/job/${application.job_id?.id}`,
                                "_blank"
                              )
                            }
                          >
                            {application.job_id?.title || "-- --"}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-[#18181B] text-sm">
                          <div>{application.email || "-- --"}</div>
                          <div className="text-xs text-[#A1A1AA]">
                            {application.phone || "-- --"}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="text-center py-4">
                        No applications found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Applications Overview Chart */}
            <div className="bg-white rounded-3xl shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Applications Overview
              </h2>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={applicationChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#fff", borderRadius: 8 }}
                  />
                  <Bar dataKey="Total" fill="#2563eb" /> {/* blue-600 */}
                  <Bar dataKey="Shortlisted" fill="#16a34a" /> {/* green-600 */}
                  <Bar dataKey="Rejected" fill="#dc2626" /> {/* red-600 */}
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Recruiter List */}
            <div className="bg-white rounded-3xl shadow-md p-6 overflow-auto">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Recruiters
              </h2>
              <table className="min-w-full whitespace-nowrap">
                <thead>
                  <tr className="text-[#A1A1AA] text-xs font-semibold">
                    <th className="px-3 py-4 text-left">
                      <span className="ml-2">Sr.</span>
                    </th>
                    <th className="px-6 py-4 text-left">
                      <span className="ml-2">NAME</span>
                    </th>
                    <th className="px-4 py-4 text-left">EMAIL</th>
                    <th className="px-4 py-4 text-left">CREATED AT</th>
                  </tr>
                </thead>
                <tbody>
                  {hrList.map((hr, idx) => {
                    const [first_name, ...lastParts] = hr.name.split(" ");
                    const last_name = lastParts.join(" ");

                    return (
                      <tr
                        key={idx}
                        className="border-t border-[#F4F4F5] hover:bg-[#FAFAFA] transition"
                      >
                        <td className="px-6 py-4 items-center">
                          <div className="font-semibold text-[#18181B] text-base">
                            {idx + 1}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="font-semibold text-[#18181B] text-base cursor-pointer">
                            {first_name} {last_name}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-[#18181B] font-medium text-sm">
                          {hr.email}
                        </td>
                        <td className="px-4 py-4 text-[#18181B] text-sm">
                          {moment(hr.createdAt).format("LL")}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Interview List */}
            <div className="bg-white rounded-3xl shadow-md p-6 overflow-auto">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Pending Interviews
              </h2>
              <table className="min-w-full whitespace-nowrap">
                <thead>
                  <tr className="text-[#A1A1AA] text-xs font-semibold">
                    <th className="px-3 py-4 text-left">
                      <span className="ml-2">Sr.</span>
                    </th>
                    <th className="px-6 py-4 text-left">
                      <span className="ml-2">NAME / TITLE</span>
                    </th>
                    <th className="px-4 py-4 text-left">APPLIED JOB</th>
                    <th className="px-4 py-4 text-left">EMAIL / PHONE</th>
                  </tr>
                </thead>
                <tbody>
                  {pendingInterviews
                    .filter((application) => application.status === "interview")
                    .map((application, idx) => (
                      <tr
                        key={application.id}
                        className="border-t border-[#F4F4F5] hover:bg-[#FAFAFA] transition"
                      >
                        <td className="px-6 py-4 items-center">
                          <div className="font-semibold text-[#18181B] text-base">
                            {idx + 1}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="font-semibold text-[#18181B] text-base cursor-pointer">
                            {application.full_name || "-- --"}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-[#18181B] font-medium text-sm">
                          <div
                            className="cursor-pointer text-blue-700 underline"
                            onClick={() =>
                              window.open(
                                `/company/job/${application.job_id?.id}`,
                                "_blank"
                              )
                            }
                          >
                            {application.job_id?.title || "-- --"}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-[#18181B] text-sm">
                          <div>{application.email || "-- --"}</div>
                          <div className="text-xs text-[#A1A1AA]">
                            {application.phone || "-- --"}
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CompanyDashboard;
