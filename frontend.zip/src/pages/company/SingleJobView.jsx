import React, { useEffect, useState } from "react";
import { AiOutlineInfoCircle } from "react-icons/ai";
import JobInfo from "./JobInfo";
import JobApplication from "./JobApplication";
import { api } from "../utlis/customAPI";
import Loader from "../utlis/loader/loader";
import { useParams } from "react-router-dom";
import toast from "react-hot-toast";
import ScanModal from "./scanModel";

const SingleJobView = ({ progress, setProgress }) => {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState("jobInfo");
  const [data, setData] = useState({
    job: null,
    loading: false,
    applications: null,
    totalPages: 1,
    page: 1,
  });
  const [loading, setLoading] = useState(false);
  const [loadingScan, setLoadingScan] = useState(false);
  const [applicationsIds, setApplicationsIds] = useState([]);

  const [showScanInput, setShowScanInput] = useState(false);
  const [scanNumber, setScanNumber] = useState(1);
  const [scanModal, setScanModal] = useState({ open: false, data: null });

  const renderTabContent = () => {
    switch (activeTab) {
      case "applications":
      case "shortlisted":
      case "interview":
      case "hired":
        const filteredApplications = data.applications?.filter((app) => {
          switch (activeTab) {
            case "applications":
              return true;
            case "shortlisted":
              return app.status === "shortlisted";
            case "hired":
              return app.status === "hired";
            case "Interview":
              return app.status === "interviewing";
            default:
              return false;
          }
        });

        return (
          <JobApplication
            progress={progress}
            setProgress={setProgress}
            applications={filteredApplications}
            totalPages={data.totalPages}
            page={data.page}
            setApplications={setData}
            onPageChange={(newPage) => {
              setData((prev) => ({ ...prev, page: newPage }));
              api
                .get(`/company/job-applications/${id}?page=${newPage}`)
                .then((res) => {
                  const filtered = res.data.applications.filter((app) => {
                    switch (activeTab) {
                      case "applications":
                        return true;
                      case "shortlisted":
                        return app.status === "shortlisted";
                      case "onBoarded":
                        return app.status === "hired";
                      case "interviewing":
                        return app.status === "interviewing";
                      default:
                        return false;
                    }
                  });
                  setData((prev) => ({
                    ...prev,
                    applications: filtered,
                    totalPages: Math.ceil(filtered.length / 20),
                  }));
                });
            }}
            loading={loading}
            setLoading={setLoading}
          />
        );
      default:
        return (
          <JobInfo progress={progress} setProgress={setProgress} data={data} />
        );
    }
  };

  const TabButton = ({ children, active, onClick }) => (
    <button
      className={`w-fit font-medium text-[#707070] text-[1rem] cursor-pointer ${active ? "border-b-4 border-[#FC6935]" : ""
        }`}
      onClick={onClick}
    >
      {children}
    </button>
  );

  useEffect(() => {
    const fetchData = async () => {
      setData((prev) => ({ ...prev, loading: true }));
      setLoading(true);
      try {
        const [jobRes, appsRes] = await Promise.all([
          api.get(`/company/job/${id}`),
          api.get(`/company/job-applications/${id}?page=1`),
        ]);
        setData((prev) => ({
          ...prev,
          job: jobRes.data.job,
          applications: appsRes.data.applications,
          totalPages: appsRes.data.totalPages,
        }));
        setApplicationsIds(appsRes.data.applicationIds);
      } catch (error) {
        console.log(error);
      } finally {
        setData((prev) => ({ ...prev, loading: false }));
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleScanSubmit = () => {
    const num = Number(scanNumber);
    if (isNaN(num)) {
      toast.error("Please enter a valid number.");
      return;
    }
    if (num < 1) {
      toast.error("Number must be at least 1");
      return;
    }
    if (num > applicationsIds.length) {
      toast.error(`Number cannot be greater than ${applicationsIds.length}`);
      return;
    }

    setLoadingScan(true);
    const payload = {
      applications_id: applicationsIds,
      total_top: num,
    };
    api
      .post(`/company/application/scan`, payload)
      .then((res) => {
        toast.success("Applications scanned successfully");
        setShowScanInput(false);
        setScanModal({ open: true, data: res.data.results });
      })
      .catch((err) => {
        toast.error("Something went wrong!");
      })
      .finally(() => {
        setLoadingScan(false);
      });
  };

  const handleScanButtonClick = () => {
    setShowScanInput(true);
    setScanNumber(applicationsIds.length + 1);
  };

  const handleScanCancel = () => {
    setShowScanInput(false);
  };

  const updateApplicationStatus = (applicationId, newStatus) => {
    setData(prev => ({
      ...prev,
      applications: prev.applications.map(app =>
        app._id == applicationId
          ? { ...app, status: newStatus }
          : app
      )
    }));
  };
  
  return (
    <>
      {loadingScan && <Loader />}
      <div className="bg-[#F6F3EA] overflow-y-auto family-outfit">
        <div
          className="flex flex-col mb-1 justify-between px-6 py-2 pb-5 bg-[#FFFFFF]"
          style={{ borderBottomLeftRadius: 18, borderBottomRightRadius: 18 }}
        >
          {loading || progress ? (
            <>
              <div className="flex items-center justify-between">
                <div className="h-10 w-64 bg-gray-200 rounded-lg animate-pulse"></div>
              </div>

              <div className="flex items-center bg-gray-200 rounded-[3rem] w-full max-w-xl px-[0.7rem] py-[0.5rem] mt-2.5">
                <div className="w-5 h-5 bg-gray-300 rounded-full mr-2 animate-pulse"></div>
                <div className="h-4 bg-gray-300 rounded-full animate-pulse w-3/4"></div>
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <h1 className="text-[2.1rem] font-semibold text-[#000000]">
                  {data?.job?.title}
                </h1>
              </div>
              <div className="flex items-center bg-[#E6F6EF] rounded-[3rem] w-fit px-[0.7rem] py-[0.5rem] mt-2.5 font-normal text-[0.8rem] text-[#05A15F]">
                <AiOutlineInfoCircle className="text-[#05A15F] text-[1rem] mr-1" />
                Type prompts like "Top 12 candidates" in the search bar and get
                instant, smart results!
              </div>
            </>
          )}

          <div className="flex items-center justify-between">
            <div className="flex gap-8 mt-3">
              <TabButton
                active={activeTab === "jobInfo"}
                onClick={() => setActiveTab("jobInfo")}
              >
                Job Info
              </TabButton>
              <TabButton
                active={activeTab === "applications"}
                onClick={() => setActiveTab("applications")}
              >
                Applications
              </TabButton>
              <TabButton
                active={activeTab === "shortlisted"}
                onClick={() => setActiveTab("shortlisted")}
              >
                Shortlisted
              </TabButton>
              <TabButton
                active={activeTab === "interview"}
                onClick={() => setActiveTab("interview")}
              >
                Interviewing
              </TabButton>
              <TabButton
                active={activeTab === "hired"}
                onClick={() => setActiveTab("hired")}
              >
                Hired
              </TabButton>
            </div>
            {showScanInput ? (
              <div className="flex items-center gap-2 mt-3">
                <div className="flex flex-col">
                  <input
                    type="number"
                    min="1"
                    max={applicationsIds.length}
                    value={scanNumber}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (value === "") {
                        setScanNumber("");
                        return;
                      }
                      const num = Number(value);
                      if (isNaN(num)) return;
                      if (num > applicationsIds.length) {
                        toast.error(`Number cannot be greater than ${applicationsIds.length}`);
                        return;
                      }
                      if (num >= 1) {
                        setScanNumber(num);
                      }
                    }}
                    className="border rounded px-2 py-1 w-24"
                  />
                </div>
                <button
                  onClick={handleScanSubmit}
                  className="bg-[#FC6935] text-white rounded px-3 py-1 font-medium cursor-pointer"
                  disabled={loadingScan}
                >
                  Submit
                </button>
                <button
                  onClick={handleScanCancel}
                  className="bg-gray-300 text-black rounded px-3 py-1 font-medium cursor-pointer"
                  disabled={loadingScan}
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={handleScanButtonClick}
                className="flex items-center justify-center text-white gap-2 mt-3 text-[1rem] cursor-pointer bg-[#FC6935] rounded-[3rem] font-medium px-[0.5rem] py-[0.3rem]"
              >
                Scan Applications
              </button>
            )}
          </div>
        </div>
        <div className="">{renderTabContent()}</div>
      </div>

      <ScanModal
        data={scanModal}
        setScanModal={setScanModal}
        updateApplicationStatus={updateApplicationStatus}
        setProgress={setProgress}
      />
    </>
  );
};

export default SingleJobView;
