import { Box, Modal, FormControl, Select, MenuItem } from "@mui/material";
import moment from "moment";
import { useEffect, useState } from "react";
import { api } from "../utlis/customAPI";

const ScanModal = ({ data, setScanModal, updateApplicationStatus, setProgress }) => {
    const [applications, setApplications] = useState([]);

    useEffect(() => {
        setApplications(data?.data?.map(app => app?.application));
    }, [data]);
    const statusOptions = ['pending', 'interview', 'shortlisted', 'rejected', 'hired'];

    const handleStatusChange = (event, applicationId) => {
        const newStatus = event.target.value;
        setApplications(prevApps =>
            prevApps.map(app =>
                app._id === applicationId
                    ? {
                        ...app,
                        status: newStatus
                    }
                    : app
            )
        );
        setProgress(30)
        api.put(`/company/update_application_status`, { application_id: applicationId, status: newStatus })
            .then((res) => {
                updateApplicationStatus(applicationId, newStatus);
                setProgress(40)
            }).finally(() => {
                setProgress(100)
            })
    };

    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '70%',
        bgcolor: 'background.paper',
        borderRadius: '1.13rem',
        boxShadow: 24,
        p: 4,
    };

    return (
        <Modal
            open={data?.open}
            onClose={() => setScanModal({ open: false, data: null })}
            aria-labelledby="scan-modal-title"
            aria-describedby="scan-modal-description"
        >
            <Box sx={style}>
                <h2 id="scan-modal-title" className="text-[2rem] font-semibold text-[#707070] mb-4">
                    Scan Results
                </h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full whitespace-nowrap">
                        <thead>
                            <tr>
                                <th className="px-3 py-4 text-left">
                                    <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">Sr.</span>
                                </th>
                                <th className="px-6 py-4 text-left">
                                    <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">NAME / TITLE</span>
                                </th>
                                <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">EMAIL / PHONE</th>
                                <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">APPLIED DATE</th>
                                <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">RESUME SCORE</th>
                                <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">RESUME URL</th>
                                <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">STATUS</th>
                            </tr>
                        </thead>
                        <tbody>
                            {applications?.length > 0 ? (
                                applications?.map((result, idx) => (
                                    <tr key={idx} className="border-t border-[#F4F4F5] hover:bg-[#FAFAFA] transition">
                                        <td className="px-6 py-4 items-center">
                                            <div className="font-semibold text-[#18181B] text-base">
                                                {idx + 1}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="font-semibold text-[#18181B] text-base cursor-pointerunderline">
                                                {result?.full_name || "-- --"}
                                            </div>
                                        </td>
                                        <td className="px-4 py-4 text-[#18181B] text-sm">
                                            <div>{result?.email || "-- --"}</div>
                                            <div className="text-xs text-[#A1A1AA]">
                                                {result?.phone || "-- --"}
                                            </div>
                                        </td>
                                        <td className="px-4 py-4 text-[#18181B] text-sm">
                                            <div>
                                                {result?.applied_at
                                                    ? moment(result?.applied_at).format("LL")
                                                    : "-- --"}
                                            </div>
                                        </td>
                                        <td className="px-4 py-4 text-[#18181B] text-sm">
                                            <div className="font-medium text-[#4D7CFE]">
                                                {result?.resume_score}%
                                            </div>
                                        </td>
                                        <td className="px-4 py-4 text-[#18181B] text-sm">
                                            <div
                                                className="cursor-pointer text-blue-700 underline"
                                                onClick={() =>
                                                    window.open(result?.resume_url, "_blank")
                                                }
                                            >
                                                {result?.resume_url ? "Click here" : "-- --"}
                                            </div>
                                        </td>
                                        <td className="px-4 py-4 text-[#18181B] text-sm">
                                            <FormControl fullWidth>
                                                <Select
                                                    value={result?.status || 'pending'}
                                                    onChange={(e) => handleStatusChange(e, result?._id)}
                                                    size="small"
                                                    sx={{
                                                        backgroundColor: result?.status === "pending"
                                                            ? "#FFF8E6"
                                                            : result?.status === "interview"
                                                                ? "#E6F6EF"
                                                                : result?.status === "shortlisted"
                                                                    ? "#E6F6EF"
                                                                    : result?.status === "rejected"
                                                                        ? "#FFE6E6"
                                                                        : result?.status === "hired"
                                                                            ? "#E6F6EF"
                                                                            : "#ccc",
                                                        color: result?.status === "pending"
                                                            ? "#FFB201"
                                                            : result?.status === "interview"
                                                                ? "#05A15F"
                                                                : result?.status === "shortlisted"
                                                                    ? "#05A15F"
                                                                    : result?.status === "rejected"
                                                                        ? "#FF0000"
                                                                        : result?.status === "hired"
                                                                            ? "#05A15F"
                                                                            : "#000",
                                                        borderRadius: '0.7rem',
                                                        padding: '0.4rem',
                                                        '& .MuiSelect-select': {
                                                            padding: '0',
                                                            textAlign: 'center'
                                                        }
                                                    }}
                                                >
                                                    {statusOptions.map((option) => (
                                                        <MenuItem key={option} value={option}>
                                                            {option.charAt(0).toUpperCase() + option.slice(1)}
                                                        </MenuItem>
                                                    ))}
                                                </Select>
                                            </FormControl>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={7} className="text-center py-4">No scan results found</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Box>
        </Modal>
    );
};

export default ScanModal;