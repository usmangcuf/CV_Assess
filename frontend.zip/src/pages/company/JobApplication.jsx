import moment from "moment";
import React, { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { api } from "../utlis/customAPI";

const JobApplication = ({
  progress,
  setProgress,
  applications = [],
  totalPages = 1,
  page = 1,
  onPageChange,
  setApplications,
  loading,
  setLoading
}) => {
  const [deleteModal, setDeleteModal] = useState({
    open: false,
    application: null
  });
  const navigate = useNavigate();

  const openDeleteModal = (application) =>
    setDeleteModal({ open: true, application });

  const closeDeleteModal = () =>
    setDeleteModal({ open: false, application: null });

  const handleDeleteApplication = async (application) => {
    try {
      setProgress(30)
      await api.delete(`/company/application/${application._id}`);
      setApplications(prev => ({
        ...prev,
        applications: prev.applications.filter(item => item?._id !== application._id)
      }));
      toast.success("Application deleted successfully");
      closeDeleteModal();
      setProgress(60)
    } catch (err) {
      toast.error("Failed to delete application");
    } finally {
      setProgress(100)
    }
  };

  const handlePageChange = (n) => {
    if (n >= 1 && n <= totalPages) {
      onPageChange(n);
    }
  };

  return (
    <div className="bg-[#F6F3EA] overflow-y-auto family-outfit">
      <div className="overflow-x-auto rounded-[1.13rem] bg-white w-full">
        <table className="min-w-full whitespace-nowrap">
          <thead>
            <tr>
              <th className="px-3 py-4 text-left">
                <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">Sr.</span>
              </th>
              <th className="px-6 py-4 text-left">
                <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">NAME / TITLE</span>
              </th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">EMAIL / PHONE</th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">APPLIED DATE</th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">RESUME</th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">STATUS</th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 5 }).map((_, idx) => (
                <tr key={idx} className="border-t border-[#F4F4F5] animate-pulse">
                  <td className="px-6 py-4">
                    <div className="h-4 w-6 bg-gray-200 rounded" />
                  </td>
                  <td className="px-6 py-4">
                    <div className="h-4 w-32 bg-gray-200 rounded mb-2" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-20 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-16 bg-gray-200 rounded mb-1" />
                    <div className="h-3 w-12 bg-gray-100 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-14 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-14 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4 relative">
                    <div className="h-8 w-8 bg-gray-200 rounded-full mx-auto" />
                  </td>
                </tr>
              ))
            ) : applications.length > 0 ? (
              applications.map((application, idx) => (
                <tr key={application._id} className="border-t border-[#F4F4F5] hover:bg-[#FAFAFA] transition">
                  <td className="px-6 py-4 items-center">
                    <div className="font-semibold text-[#18181B] text-base">
                      {idx + 1}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-semibold text-[#18181B] text-base cursor-pointer hover:underline">
                      {application.full_name || "-- --"}
                    </div>
                  </td>
                  <td className="px-4 py-4 text-[#18181B] text-sm">
                    <div>{application.email || "-- --"}</div>
                    <div className="text-xs text-[#A1A1AA]">
                      {application.phone || "-- --"}
                    </div>
                  </td>
                  <td className="px-4 py-4 text-[#18181B] text-sm">
                    <div>
                      {application.applied_at
                        ? moment(application.applied_at).format("LL")
                        : "-- --"}
                    </div>
                  </td>
                  <td className="px-4 py-4 text-[#18181B] text-sm">
                    <div
                      className="cursor-pointer text-blue-700 underline"
                      onClick={() => window.open(application.resume_url, "_blank")}
                    >
                      {application.resume_url ? "Click here" : "-- --"}
                    </div>
                  </td>
                  <td className="px-4 py-4 text-[#18181B] text-sm">
                    <div
                      className="font-medium rounded-[0.7rem] p-[0.4rem] text-center"
                      style={{
                        backgroundColor: application.status === "pending"
                          ? "#FFF8E6"
                          : "#ccc",
                        color: application.status === "pending"
                          ? "#FFB201"
                          : "#000",
                      }}
                    >
                      {application.status
                        ? application.status.charAt(0).toUpperCase() +
                        application.status.slice(1)
                        : "-- --"}
                    </div>
                  </td>
                  <td className="px-4 py-4 relative">
                    <ActionMenu
                      job={application}
                      onDelete={openDeleteModal}
                      isLastItem={idx === applications.length - 1}
                    />
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="text-center py-4">No applications found</td>
              </tr>
            )}
          </tbody>
        </table>

        {applications.length > 0 && totalPages > 1 && (
          <div className="flex items-center justify-between mt-6 px-6 pb-6">
            <button
              className="flex items-center gap-2 px-4 py-2 border border-[#FF6A3D] text-[#FF6A3D] rounded-full bg-white hover:bg-[#FFF2ED] transition"
              onClick={() => handlePageChange(page - 1)}
              disabled={page === 1}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Previous
            </button>
            <div className="flex gap-2">
              {[...Array(totalPages)].map((_, n) => (
                <button
                  key={n + 1}
                  onClick={() => handlePageChange(n + 1)}
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${n + 1 === page
                    ? "bg-[#FFF2ED] text-[#FF6A3D]"
                    : "bg-[#F4F4F5] text-[#A1A1AA]"
                    }`}
                >
                  {n + 1}
                </button>
              ))}
            </div>
            <button
              className="flex items-center gap-2 px-4 py-2 border border-[#FF6A3D] text-[#FF6A3D] rounded-full bg-white hover:bg-[#FFF2ED] transition"
              onClick={() => handlePageChange(page + 1)}
              disabled={page === totalPages}
            >
              Next
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/10 backdrop-blur-sm">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm">
            <h2 className="text-lg font-semibold mb-4">Confirm Deletion</h2>
            <p className="mb-6">Are you sure you want to delete this application?</p>
            <div className="flex justify-end gap-3">
              <button
                className="px-4 py-2 rounded bg-gray-200 hover:bg-gray-300"
                onClick={closeDeleteModal}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 rounded bg-red-500 text-white hover:bg-red-600"
                onClick={() => handleDeleteApplication(deleteModal.application)}
                disabled={progress}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ActionMenu Component
function ActionMenu({ job, onDelete, isLastItem }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const btnRef = useRef(null);

  useEffect(() => {
    function handleClick(e) {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target) &&
        btnRef.current &&
        !btnRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    }

    if (open) {
      document.addEventListener("mousedown", handleClick);
    } else {
      document.removeEventListener("mousedown", handleClick);
    }

    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  return (
    <div className="relative inline-block text-left">
      <button
        ref={btnRef}
        onClick={() => setOpen(v => !v)}
        className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-[#F4F4F5] focus:outline-none"
      >
        <svg className="w-5 h-5 text-[#A1A1AA]" fill="currentColor" viewBox="0 0 20 20">
          <circle cx="10" cy="4" r="1.5" />
          <circle cx="10" cy="10" r="1.5" />
          <circle cx="10" cy="16" r="1.5" />
        </svg>
      </button>

      {open && (
        <div
          ref={menuRef}
          className={`absolute right-0 z-20 w-32 origin-top-right ${isLastItem ? "bottom-full mb-2" : "mt-2"
            } rounded-xl bg-white shadow-lg focus:outline-none animate-fade-in`}
        >
          <button
            onClick={() => {
              onDelete(job);
              setOpen(false);
            }}
            className="w-full flex items-center gap-2 px-4 py-2 text-sm text-[#EF4444] hover:bg-[#FEE2E2] rounded-xl"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M6 18L18 6M6 6l12 12" />
            </svg>
            Delete
          </button>
        </div>
      )}
    </div>
  );
}

export default JobApplication;