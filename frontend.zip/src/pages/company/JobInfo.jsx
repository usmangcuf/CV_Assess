import React, { useState } from "react";
import CalenderIcon from "../../assets/img/calender-black.svg";
import RankIcon from "../../assets/img/rank.svg";
import JobIcon from "../../assets/img/job-type.svg";
import WorldIcon from "../../assets/img/world-black.svg";
import SalaryIcon from "../../assets/img/salary.svg";
import EducationIcon from "../../assets/img/education-black.svg";
import Edit from "../../assets/img/edit.svg";
import Delete from "../../assets/img/delete.svg";
import Share from "../../assets/img/share.svg";
import { CompanyJobLoader } from "../utlis/shimmer";
import numeral from "numeral";
import moment from "moment";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { api } from "../utlis/customAPI";
import { formatName } from "../../pages/utlis/helper";
import CustomEditor from "../components/CustomEditor";
const JobInfo = ({ progress, setProgress, data }) => {
  const navigate = useNavigate();

  const handleDelete = async () => {
    setProgress(30);
    try {
      setProgress(60);
      const res = await api.delete(`/company/job/${data?.job?._id}`);
      navigate("/company/jobs");
      toast.success("Job deleted successfully");
    } catch (error) {
      toast.error("Something went wrong!");
      console.log(error);
    } finally {
      setProgress(100);
    }
  };

  return (
    <>
      {data.loading ? (
        <CompanyJobLoader />
      ) : (
        <>
          <div className="flex items-stretch gap-2.5">
            <div className="flex items-start justify-between w-[70%] bg-white px-6 py-6 rounded-[1.13rem]">
              <div className="flex flex-col gap-9 w-[33%]">
                <div className="flex items-center font-medium gap-4 text-black">
                  <img
                    src={CalenderIcon}
                    alt="Calendar"
                    className="mr-2 w-5 h-5"
                  />
                  <span>
                    {data?.job?.createdAt
                      ? moment(data?.job?.createdAt).format("LL")
                      : "-- --"}
                  </span>
                </div>
                <div className="flex items-center font-medium gap-4 text-black">
                  <img src={JobIcon} alt="Job Type" className="mr-2 w-5 h-5" />
                  <span>{data?.job?.job_type}</span>
                </div>
                <div className="flex items-center font-medium gap-4 text-black">
                  <img
                    src={WorldIcon}
                    alt="Location"
                    className="mr-2 w-5 h-5"
                  />
                  <span>{data?.job?.address}</span>
                </div>
              </div>
              <div className="flex flex-col gap-9 border-l w-[33%] border-gray-200 pl-10 h-available">
                <div className="flex items-center font-medium gap-4 text-black">
                  <img src={RankIcon} alt="Level" className="mr-2 w-5 h-5" />
                  <span>{formatName(data?.job?.level)}</span>
                </div>
                {data?.job?.status && (
                  <div className="bg-[#E6F6EF] text-[#05A15F] text-[0.8rem] font-medium px-[0.5rem] py-[0.2rem] rounded-[1rem] w-fit">
                    {data?.job?.status}
                  </div>
                )}
              </div>
              <div className="flex flex-col gap-9 border-l w-[33%] border-gray-200 pl-10 h-available">
                <div className="flex items-center font-medium gap-4 text-black">
                  <img src={SalaryIcon} alt="Salary" className="mr-2 w-5 h-5" />
                  <span>
                    ${numeral(data?.job?.min_salary).format("0.0a")} - $
                    {numeral(data?.job?.max_salary).format("0.0a")}
                  </span>
                </div>
                <div className="flex items-center font-medium gap-4 text-black">
                  <img
                    src={EducationIcon}
                    alt="Level"
                    className="mr-2 w-5 h-5"
                  />
                  <span>{data?.job?.education}</span>
                </div>
                <div className="text-[0.8rem] font-medium px-[0.5rem] py-[0.2rem] rounded-[1rem] w-fit"></div>
              </div>
            </div>
            <div className="flex items-center justify-between w-[30%] bg-white px-6 py-6 rounded-[1.13rem]">
              <div className="flex flex-col gap-4 w-full">
                <button
                  className="flex items-center justify-center gap-2 text-[1rem] cursor-pointer bg-[#FC6935] rounded-[3rem] py-[0.7rem]"
                  onClick={() =>
                    navigate(`/company/update-job/${data?.job?._id}`)
                  }
                >
                  <img src={Edit} alt="edit" />
                  <span className="text-white font-semibold text-[1rem]">
                    Edit
                  </span>
                </button>
                <button
                  className="flex items-center justify-center gap-2 text-[1rem] border border-[#FC6935] cursor-pointer rounded-[3rem] py-[0.7rem]"
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                    toast.success("Link copied to clipboard");
                  }}
                >
                  <img src={Share} alt="edit" />
                  <span className="text-[#FC6935] font-semibold text-[1rem]">
                    Share
                  </span>
                </button>
                <button
                  className="flex items-center justify-center gap-2 text-[#FF3929] cursor-pointer border border-[#FF3929] rounded-[3rem] py-[0.7rem]"
                  onClick={() => handleDelete()}
                >
                  <img src={Delete} alt="delete" />
                  <span className="text-[#FF3929] font-semibold text-[1rem]">
                    Delete
                  </span>
                </button>
              </div>
            </div>
          </div>
          <div className="mt-1 bg-white rounded-[1.13rem] px-8 py-8 space-y-4">
            <div>
              <h3 className="text-[1.5rem] font-semibold text-[#707070] mb-2">
                About the job
              </h3>
              <div className="relative">
                <CustomEditor
                  value={data?.job?.description}
                  isReadOnly={true}
                />
              </div>
            </div>

            <div>
              <h3 className="text-[1.5rem] font-semibold text-[#707070] mb-2">
                Key Responsibilities
              </h3>
              <div className="relative">
                <CustomEditor
                  value={data?.job?.key_responsibilities}
                  isReadOnly={true}
                />
              </div>
            </div>

            <div>
              <h3 className="text-[1.5rem] font-semibold text-[#707070] mb-2">
                Skills
              </h3>
              <div className="flex flex-wrap gap-3">
                {data?.job?.skills?.map((skill, skIdx) => (
                  <span
                    className="bg-[#FFEDE5] text-[#FC6935] rounded-full px-4 py-2 text-[1rem] font-medium"
                    key={skIdx}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default JobInfo;
