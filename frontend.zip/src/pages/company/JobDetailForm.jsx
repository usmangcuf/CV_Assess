import { useEffect, useState } from "react";
import JobBasicInfoForm from "../common/job/JobBasicInfoForm";
import JobDetails from "../common/job/JobDetails";
import { api } from "../utlis/customAPI";
import ArrowLeftIcon from "../../assets/img/arrow-left.svg";
import ListBulletActive from "../../assets/img/list-bullet-active.svg";
import ListBulletInActive from "../../assets/img/list-bullet-inactive.svg";
import toast from "react-hot-toast";
import { useNavigate, useParams } from "react-router-dom";

function JobDetailForm({ setProgress }) {
  const navigate = useNavigate();
  const { id } = useParams();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const [formData, setFormData] = useState({
    title: "",
    job_location: "",
    job_type: "",
    level: "",
    start_date: null,
    end_date: null,
    pay_type: "",
    min_salary: "",
    max_salary: "",
    education: "",
    address: "",
    description: "",
    key_responsibilities: "",
    skills: [],
  });

  // ✅ Fetch job if id is available (edit mode)
  const handleFetchJobDetail = async () => {
    try {
      setProgress(30);
      const response = await api.get(`/company/job/${id}`);
      setFormData(response.data.job);
      setProgress(70);
    } catch (error) {
      toast.error(
        error?.response?.data?.message || "Error fetching job details"
      );
    } finally {
      setProgress(100);
    }
  };

  useEffect(() => {
    if (id) handleFetchJobDetail();
  }, [id]);

  // ✅ Handle input changes and clear field errors
  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => {
      const updated = { ...prev };
      delete updated[field];
      return updated;
    });
  };

  // ✅ Step 1 validation
  const validateStepOne = () => {
    const requiredFields = ["title", "job_type", "job_location", "level"];
    const newErrors = {};
    requiredFields.forEach((field) => {
      if (!formData[field]) {
        newErrors[field] = `${field.replace("_", " ")} is required`;
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // ✅ Final validation
  const validateFinalSubmission = () => {
    const newErrors = {};
    if (!formData.description) {
      newErrors.description = "Description is required";
    }
    setErrors((prev) => ({ ...prev, ...newErrors }));
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = (e) => {
    e.preventDefault();
    if (validateStepOne()) {
      setStep(2);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep((prev) => prev - 1);
    } else {
      navigate(-1);
    }
  };

  const handleJobSubmit = async (e) => {
    e.preventDefault();
    if (!validateFinalSubmission()) return;
    try {
      setProgress(30);
      setIsLoading(true);
      if (id) {
        await api.put(`/company/job/${id}`, formData);
        toast.success("Job updated successfully.");
      } else {
        await api.post("/company/create-job", formData);
        toast.success("Job created successfully.");
      }
      setProgress(70);
      navigate(-1);
    } catch (error) {
      toast.error(error.response?.data?.message || "Error saving job detail.");
    } finally {
      setProgress(100);
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full bg-white  flex py-20">
      {/* Side tabs */}
      <div className="w-1/4">
        <div className="m-auto w-fit">
          <button
            onClick={handleBack}
            className="flex items-center cursor-pointer text-[#FC6935] mb-5 py-[8px] px-[14px] border-[#FC6935] rounded-full border-1 gap-[8px]"
          >
            <img src={ArrowLeftIcon} alt="back icon" /> Back
          </button>
          <ul>
            {[
              { label: "Basic Info", value: 1 },
              { label: "Job Details", value: 2 },
            ].map(({ label, value }) => (
              <li
                key={value}
                className={`mb-4 py-[9px] cursor-pointer px-[24px] flex items-center text-[16px] gap-[10px] w-[190px] rounded-full font-semibold ${
                  step === value
                    ? "text-[#FC6935] bg-[#FC69351A]"
                    : "text-[#707070]"
                }`}
                onClick={() => {
                  if (value === 2 && !validateStepOne()) return;
                  setStep(value);
                }}
              >
                <img
                  src={step === value ? ListBulletActive : ListBulletInActive}
                  alt="job form"
                />
                {label}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Main form section */}
      <div className="w-1/2 px-10 border-l-[2px] border-r-[2px] border-l-[#F7F7F7] border-r-[#F7F7F7]">
        <form className="flex flex-col gap-[1.3rem]">
          {step === 1 ? (
            <JobBasicInfoForm
              formData={formData}
              handleChange={handleChange}
              errors={errors}
            />
          ) : (
            <JobDetails
              formData={formData}
              handleChange={handleChange}
              errors={errors}
            />
          )}
          <div className="flex justify-between mt-6">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="border border-[#FC6935] cursor-pointer text-[#FC6935] rounded-full px-[25px] py-[11px] font-semibold"
            >
              Cancel
            </button>
            {step === 1 ? (
              <button
                type="button"
                onClick={handleNext}
                className="bg-[#FC6935] text-white cursor-pointer px-[25px] py-[11px] rounded-full font-semibold"
              >
                Continue
              </button>
            ) : (
              <button
                type="submit"
                onClick={handleJobSubmit}
                disabled={isLoading}
                className="bg-[#FC6935] text-white cursor-pointer px-[25px] py-[11px] rounded-full font-semibold"
              >
                {id ? "Update Job" : "Publish Job"}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

export default JobDetailForm;
