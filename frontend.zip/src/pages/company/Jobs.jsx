import { useRef, useState, useEffect } from "react";
import "./companyStyle.scss";
import { api } from "../utlis/customAPI";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import moment from "moment/moment";
import numeral from "numeral";

const Jobs = ({ setProgress, progress }) => {
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [title, setTitle] = useState("");
  const [isDelete, setIsDelete] = useState(false);
  const [jobs, setJobs] = useState([]);
  const [totalPages, setTotalPages] = useState(0);
  const [deleteModal, setDeleteModal] = useState({ open: false, job: null });
  const [isLoading, setIsLoading] = useState(false);

  const handleDeleteJob = async (job) => {
    setIsDelete(true);
    setProgress(30);
    try {
      await api.delete(`/company/job/${job._id}`);
      setProgress(80);
      setDeleteModal({ open: false, job: null });
      setJobs((prevJobs) => prevJobs.filter((j) => j._id !== job._id));
      toast.success("Job deleted successfully");
    } catch (err) {
      toast.error("Failed to delete job");
    } finally {
      setIsDelete(false);
      setProgress(100);
    }
  };

  const openDeleteModal = (job) => setDeleteModal({ open: true, job });
  const closeDeleteModal = () => setDeleteModal({ open: false, job: null });

  const fetchJobs = async () => {
    setIsLoading(true);
    setProgress(30);
    try {
      const res = await api.get(`/company/jobs?page=${page}&title=${title}`);
      setProgress(70);
      setJobs(res.data.jobs);
      setTotalPages(res.data.totalPages);
    } catch (err) {
      console.log(err);
      toast.error("Failed to fetch jobs");
    } finally {
      setIsLoading(false);
      setProgress(100);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, [page, title]);

  const handlePageChange = (n) => {
    if (n >= 1 && n <= totalPages) setPage(n);
  };

  return (
    <div className="bg-[#F6F3EA] overflow-y-auto family-outfit">
      <div
        className="flex items-center mb-1 justify-between px-6 py-2 pb-5 bg-[#FFFFFF]"
        style={{ borderBottomLeftRadius: 18, borderBottomRightRadius: 18 }}
      >
        <h1 className="text-[2.1rem] font-semibold text-[#000000]">All Jobs</h1>
        <div className="flex items-center gap-3">
          <div className="relative">
            <input
              type="text"
              placeholder="Search title"
              className="rounded-full pl-10 pr-4 py-2 bg-[#F4F4F5] text-[#71717A] text-base outline-none w-56"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <svg
              className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#A1A1AA]"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35" />
            </svg>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto rounded-[1.13rem] bg-white px-6 py-6 min-h-[90vh]">
        <table className="min-w-full whitespace-nowrap">
          <thead>
            <tr className="">
              <th className="px-3 py-4 text-left">
                <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">
                  Sr.
                </span>
              </th>
              <th className="px-6 py-4 text-left">
                <span className="ml-2 font-medium text-[0.9rem] text-[#707070]">
                  JOB TITLE
                </span>
              </th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">
                JOB TYPE
              </th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">
                DATE S/E
              </th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">
                Min Salary
              </th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">
                Max Salary
              </th>
              <th className="px-4 py-4 text-left font-medium text-[0.9rem] text-[#707070]">
                ACTION
              </th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, idx) => (
                <tr
                  key={idx}
                  className="border-t border-[#F4F4F5] animate-pulse"
                >
                  <td className="px-6 py-4">
                    <div className="h-4 w-6 bg-gray-200 rounded" />
                  </td>
                  <td className="px-6 py-4">
                    <div className="h-4 w-32 bg-gray-200 rounded mb-2" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-20 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-16 bg-gray-200 rounded mb-1" />
                    <div className="h-3 w-12 bg-gray-100 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-14 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-14 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4 relative">
                    <div className="h-8 w-8 bg-gray-200 rounded-full" />
                  </td>
                </tr>
              ))
            ) : jobs.length > 0 ? (
              jobs.map((job, idx) => (
                <tr
                  key={job._id}
                  className="border-t border-[#F4F4F5] hover:bg-[#FAFAFA] transition"
                >
                  <td className="px-6 py-4 items-center">
                    <div>
                      <div className="font-semibold text-[#18181B] text-base">
                        {idx + 1}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 flex items-center gap-4">
                    <div>
                      <div
                        className="font-semibold text-[#18181B] text-base cursor-pointer hover:underline mt-1.5"
                        onClick={() => navigate(`/company/job/${job?._id}`)}
                      >
                        {job.title ? job.title : "-- --"}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-[#18181B] font-medium text-sm">
                    {job.job_type ? job.job_type : "-- --"}
                  </td>
                  <td className="px-4 py-4 text-[#18181B] text-sm">
                    <div>
                      {job.start_date
                        ? moment(job.start_date).format("LL")
                        : "-- --"}
                    </div>
                    <div className="text-xs text-[#A1A1AA]">
                      {job.end_date
                        ? moment(job.end_date).format("LL")
                        : "-- --"}
                    </div>
                  </td>
                  <td className="px-4 py-4 text-[#18181B] text-sm">
                    <div>
                      {job.min_salary
                        ? numeral(job.min_salary).format("0.0a")
                        : "-- --"}
                    </div>
                  </td>
                  <td className="px-4 py-4 text-[#18181B] text-sm">
                    <div>
                      {job.max_salary
                        ? numeral(job.max_salary).format("0.0a")
                        : "-- --"}
                    </div>
                  </td>
                  <td className="px-4 py-4 relative">
                    <ActionMenu
                      job={job}
                      onDelete={openDeleteModal}
                      isLastItem={idx === jobs.length - 1}
                    />
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="h-24 text-center">
                  No jobs found
                </td>
              </tr>
            )}
          </tbody>
        </table>

        {!isLoading && totalPages > 1 && (
          <div className="flex items-center justify-between mt-6">
            <button
              className="flex items-center gap-2 px-4 py-2 border border-[#FF6A3D] text-[#FF6A3D] rounded-full bg-white hover:bg-[#FFF2ED] transition disabled:opacity-50"
              onClick={() => handlePageChange(page - 1)}
              disabled={page === 1}
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M15 19l-7-7 7-7" />
              </svg>
              Previous
            </button>
            <div className="flex items-center gap-2">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((n) => (
                <button
                  key={n}
                  onClick={() => handlePageChange(n)}
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-[#A1A1AA] ${
                    n === page ? "bg-[#FFF2ED] text-[#FF6A3D]" : "bg-[#F4F4F5]"
                  } cursor-pointer`}
                >
                  {n}
                </button>
              ))}
            </div>
            <button
              className="flex items-center gap-2 px-4 py-2 border border-[#FF6A3D] text-[#FF6A3D] rounded-full bg-white hover:bg-[#FFF2ED] transition disabled:opacity-50"
              onClick={() => handlePageChange(page + 1)}
              disabled={page === totalPages}
            >
              Next
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        )}
      </div>

      {deleteModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/10 backdrop-blur-sm">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm">
            <h2 className="text-lg font-semibold mb-4">Confirm Deletion</h2>
            <p className="mb-6">Are you sure you want to delete this job?</p>
            <div className="flex justify-end gap-3">
              <button
                className="px-4 py-2 rounded bg-gray-200 hover:bg-gray-300"
                onClick={closeDeleteModal}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 rounded bg-red-500 text-white hover:bg-red-600 disabled:opacity-50"
                onClick={() => handleDeleteJob(deleteModal.job)}
                disabled={isDelete}
              >
                {isDelete ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

function ActionMenu({ job, onDelete, isLastItem }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const btnRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    function handleClick(e) {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target) &&
        btnRef.current &&
        !btnRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    }
    if (open) {
      document.addEventListener("mousedown", handleClick);
    } else {
      document.removeEventListener("mousedown", handleClick);
    }
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  function handleDelete(item) {
    setOpen(false);
    if (onDelete) onDelete(item);
  }

  return (
    <div className="relative inline-block text-left">
      <button
        ref={btnRef}
        onClick={() => setOpen((v) => !v)}
        className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-[#F4F4F5] focus:outline-none"
      >
        <svg
          className="w-5 h-5 text-[#A1A1AA]"
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <circle cx="10" cy="4" r="1.5" />
          <circle cx="10" cy="10" r="1.5" />
          <circle cx="10" cy="16" r="1.5" />
        </svg>
      </button>
      {open && (
        <div
          ref={menuRef}
          className={`absolute right-0 z-20 mt-2 w-32 origin-top-right ${
            isLastItem ? "bottom-full mb-2" : "mt-2"
          } rounded-xl bg-white shadow-lg focus:outline-none animate-fade-in`}
        >
          <div>
            <button
              onClick={() => handleDelete(job)}
              className="w-full flex items-center gap-2 px-4 py-2 text-sm text-[#EF4444] hover:bg-[#FEE2E2] rounded-t-xl"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M6 18L18 6M6 6l12 12" />
              </svg>
              Delete
            </button>
            <button
              onClick={() => navigate(`/company/update-job/${job?._id}`)}
              className="w-full flex items-center gap-2 px-4 py-2 text-sm text-[#F59E42] hover:bg-[#FFF7ED]"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M15.232 5.232l3.536 3.536M9 11l6 6M3 17v4h4l11-11a2.828 2.828 0 00-4-4L3 17z" />
              </svg>
              Update
            </button>
            <button
              onClick={() => navigate(`/company/job/${job?._id}`)}
              className="w-full flex items-center gap-2 px-4 py-2 text-sm text-[#2563EB] hover:bg-[#DBEAFE] rounded-b-xl"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <circle cx="12" cy="12" r="3" />
                <path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 9.542 7-1.274 4.057-5.065 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              View
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Jobs;
