import React, { useEffect, useRef, useState } from "react";
import { api } from "../utlis/customAPI";
import { useNavigate } from "react-router-dom";
import moment from "moment";

const Interviews = ({ setProgress, progress }) => {
  const navigate = useNavigate();
  const [applications, setApplications] = useState([]);
  const [totalPages, setTotalPages] = useState(0);
  const [deleteModal, setDeleteModal] = useState({
    open: false,
    application: null,
  });
  const [page, setPage] = useState(1);
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setProgress(20);
    api
      .get(`/company/applications?page=${page}`)
      .then((res) => {
        setProgress(70);
        setApplications(res?.data?.applications);
        setTotalPages(res?.data?.totalPages);
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setProgress(100);
      });
  }, [page]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(true);
      const searchParams = title ? `&search=${title}` : '';
      api
        .get(`/company/applications?page=${page}${searchParams}`)
        .then((res) => {
          setApplications(res?.data?.applications);
          setTotalPages(res?.data?.totalPages);
          setPage(1);
        })
        .catch((err) => {
          console.log(err);
        })
        .finally(() => {
          setLoading(false);
        });
    }, 500);

    return () => clearTimeout(timer);
  }, [title]);
  const handlePageChange = (n) => {
    if (n >= 1 && n <= totalPages) setPage(n);
  };
  const openDeleteModal = (application) =>
    setDeleteModal({ open: true, application });

  const closeDeleteModal = () =>
    setDeleteModal({ open: false, application: null });

  const handleDeleteJob = async (application) => {
    try {
      setProgress(20);
      await api.delete(`/company/application/${application._id}`);
      setApplications((prev) => prev.filter((app) => app._id !== application._id));
      setProgress(70);
    } catch (err) {
      console.error('Error deleting application:', err);
    } finally {
      setProgress(100);
      closeDeleteModal();
    }
  };

  return (
    <div className="bg-[#F6F3EA] overflow-y-auto family-outfit">
      <div
        className="flex items-center mb-1 justify-between px-6 py-2 pb-5 bg-[#FFFFFF]"
        style={{ borderBottomLeftRadius: 18, borderBottomRightRadius: 18 }}
      >
        <h1 className="text-[2.1rem] font-semibold text-[#000000]">
          Interviews
        </h1>
        <div className="flex items-center gap-3">
          <div className="relative">
            <input
              type="text"
              placeholder="Search title"
              className="rounded-full pl-10 pr-4 py-2 bg-[#F4F4F5] text-[#71717A] text-base outline-none w-56"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <svg
              className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#A1A1AA]"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35" />
            </svg>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[1.13rem] px-6 py-6 overflow-x-auto min-h-[90vh]">
        {(progress||loading) ? (
          <table className="min-w-full whitespace-nowrap">
            <thead>
              <tr className="text-[#A1A1AA] text-xs font-semibold">
                <th className="px-3 py-4 text-left">
                  <span className="ml-2">Sr.</span>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="ml-2">NAME / TITLE</span>
                </th>
                <th className="px-4 py-4 text-left">APPLIED JOB</th>
                <th className="px-4 py-4 text-left">EMAIL / PHONE</th>
                <th className="px-4 py-4 text-left">APPLIED DATE</th>
                <th className="px-4 py-4 text-left">RESUME</th>
                <th className="px-4 py-4 text-left">STATUS</th>
                <th className="px-4 py-4 text-left">ACTION</th>
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: 5 }).map((_, idx) => (
                <tr
                  key={idx}
                  className="border-t border-[#F4F4F5] animate-pulse"
                >
                  <td className="px-6 py-4">
                    <div className="h-4 w-6 bg-gray-200 rounded" />
                  </td>
                  <td className="px-6 py-4">
                    <div className="h-4 w-32 bg-gray-200 rounded mb-2" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-20 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-16 bg-gray-200 rounded mb-1" />
                    <div className="h-3 w-12 bg-gray-100 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-14 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-14 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4">
                    <div className="h-4 w-14 bg-gray-200 rounded" />
                  </td>
                  <td className="px-4 py-4 relative">
                    <div className="h-8 w-8 bg-gray-200 rounded-full mx-auto" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : applications?.length === 0 ? (
          <div className="text-center py-12">
            <h3 className="text-lg font-medium text-gray-900">
              No Applications Found
            </h3>
            <p className="mt-2 text-sm text-gray-500">
              You haven't received any job applications yet.
            </p>
          </div>
        ) : (
          <table className="min-w-full whitespace-nowrap">
            <thead>
              <tr className="text-[#A1A1AA] text-xs font-semibold">
                <th className="px-3 py-4 text-left">
                  <span className="ml-2">Sr.</span>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="ml-2">NAME / TITLE</span>
                </th>
                <th className="px-4 py-4 text-left">APPLIED JOB</th>
                <th className="px-4 py-4 text-left">EMAIL / PHONE</th>
                <th className="px-4 py-4 text-left">APPLIED DATE</th>
                <th className="px-4 py-4 text-left">RESUME</th>
                <th className="px-4 py-4 text-left">STATUS</th>
                <th className="px-4 py-4 text-left">ACTION</th>
              </tr>
            </thead>
            <tbody>
              {applications.filter((application) => application.status === "interview").map((application, idx) => (
                <React.Fragment key={application.id}>
                  <tr className="border-t border-[#F4F4F5] hover:bg-[#FAFAFA] transition">
                    <td className="px-6 py-4 items-center">
                      <div>
                        <div className="font-semibold text-[#18181B] text-base">
                          {idx + 1}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 flex items-center gap-4">
                      <div className="font-semibold text-[#18181B] text-base cursor-pointer">
                        {application.full_name
                          ? application.full_name
                          : "-- --"}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-[#18181B] font-medium text-sm">
                      <div
                        className="cursor-pointer text-blue-700 underline"
                        onClick={() =>
                          window.open(`/company/job/${application.job_id?.id}`, '_blank')
                        }
                      >
                        {application?.job_id?.title || "-- --"}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-[#18181B] text-sm">
                      <div>
                        {application.email || "-- --"}
                      </div>
                      <div className="text-xs text-[#A1A1AA]">
                        {application.phone || "-- --"}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-[#18181B] text-sm">
                      <div>
                        {application.applied_at
                          ? moment(application.applied_at).format("LL")
                          : "-- --"}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-[#18181B] text-sm">
                      <div
                        className="cursor-pointer text-blue-700 underline"
                        onClick={() =>
                          window.open(application.resume_url, "_blank")
                        }
                      >
                        {application.resume_url ? "Click here" : "-- --"}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-[#18181B] text-sm">
                      <div
                        className="font-medium rounded-[0.7rem] p-[0.4rem] text-center"
                        style={{
                          backgroundColor:
                            application.status === "pending"
                              ? "#FFF8E6"
                              : "#ccc",
                          color:
                            application.status === "pending"
                              ? "#FFB201"
                              : "#000",
                        }}
                      >
                        {application.status
                          ? application.status.charAt(0).toUpperCase() +
                            application.status.slice(1)
                          : "-- --"}
                      </div>
                    </td>
                    <td className="px-4 py-4 relative">
                      <ActionMenu
                        application={application}
                        onDelete={openDeleteModal}
                        isLastItem={idx === applications.length - 1}
                      />
                    </td>
                  </tr>
                  {application?.description && (
                    <tr>
                      <td colSpan="8" className="p-4">
                        <div className="descripation mt-[2.25rem] max-w-[48rem]">
                          <div
                            dangerouslySetInnerHTML={{
                              __html: application?.description,
                            }}
                          />
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        )}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-6">
            <button
              className="flex items-center gap-2 px-4 py-2 border border-[#FF6A3D] text-[#FF6A3D] rounded-full bg-white hover:bg-[#FFF2ED] transition"
              onClick={() => handlePageChange(page - 1)}
              disabled={page === 1}
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M15 19l-7-7 7-7" />
              </svg>
              Previous
            </button>
            <div className="flex items-center gap-2">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((n) => (
                <button
                  key={n}
                  onClick={() => handlePageChange(n)}
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-[#A1A1AA] ${
                    n === page ? "bg-[#FFF2ED] text-[#FF6A3D]" : "bg-[#F4F4F5]"
                  } cursor-pointer`}
                >
                  {n}
                </button>
              ))}
            </div>
            <button
              className="flex items-center gap-2 px-4 py-2 border border-[#FF6A3D] text-[#FF6A3D] rounded-full bg-white hover:bg-[#FFF2ED] transition"
              onClick={() => handlePageChange(page + 1)}
              disabled={page === totalPages}
            >
              Next
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        )}
      </div>
      {deleteModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/10 backdrop-blur-sm">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm">
            <h2 className="text-lg font-semibold mb-4">Confirm Deletion</h2>
            <p className="mb-6">Are you sure you want to delete this job?</p>
            <div className="flex justify-end gap-3">
              <button
                className="px-4 py-2 rounded bg-gray-200 hover:bg-gray-300"
                onClick={closeDeleteModal}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 rounded bg-red-500 text-white hover:bg-red-600 cursor-pointer"
                onClick={() => handleDeleteJob(deleteModal.application)}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

function ActionMenu({ application, onDelete, isLastItem }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const btnRef = useRef(null);

  useEffect(() => {
    function handleClick(e) {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target) &&
        btnRef.current &&
        !btnRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    }
    if (open) {
      document.addEventListener("mousedown", handleClick);
    } else {
      document.removeEventListener("mousedown", handleClick);
    }
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  function handleDelete(item) {
    setOpen(false);
    if (onDelete) onDelete(item);
  }

  return (
    <div className="relative inline-block text-left">
      <button
        ref={btnRef}
        onClick={() => setOpen((v) => !v)}
        className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-[#F4F4F5] focus:outline-none"
      >
        <svg
          className="w-5 h-5 text-[#A1A1AA]"
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <circle cx="10" cy="4" r="1.5" />
          <circle cx="10" cy="10" r="1.5" />
          <circle cx="10" cy="16" r="1.5" />
        </svg>
      </button>
      {open && (
        <div
          ref={menuRef}
          className={`absolute right-0 z-20 ${isLastItem ? 'bottom-full mb-2' : 'mt-2'} w-32 origin-top-right rounded-xl bg-white shadow-lg focus:outline-none animate-fade-in`}
        >
          <div>
            <button
              onClick={() => handleDelete(application)}
              className="w-full flex items-center gap-2 px-4 py-2 text-sm text-[#EF4444] hover:bg-[#FEE2E2] rounded-xl"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M6 18L18 6M6 6l12 12" />
              </svg>
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Interviews;
