import "./companyStyle.scss";
import PasswordField from "../utlis/PasswordField";
import { api } from "../utlis/customAPI";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import toast from "react-hot-toast";

const ChangePassword = ({ setProgress }) => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const formSchema = yup.object().shape({
    oldPassword: yup.string().required("Old password is required"),
    newPassword: yup
      .string()
      .min(6, "New password must be at least 6 characters")
      .required("New password is required"),
    confirmPassword: yup
      .string()
      .oneOf([yup.ref("newPassword")], "Passwords must match")
      .required("Confirm password is required"),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(formSchema),
  });

  const onSubmit = async (data) => {
    setIsLoading(true);
    setProgress(30);
    try {
      await api.post(`/auth/change-password`, data);
      setProgress(60);
      toast.success("Password changed successfully");
      navigate(-1);
    } catch (error) {
      toast.error(error?.response?.data?.message || "Change password error:");
    } finally {
      setIsLoading(false);
      setProgress(100);
    }
  };

  return (
    <div className="bg-[#F6F3EA] overflow-y-auto">
      {/* Header */}
      <div
        className="flex items-center mb-1 justify-between px-6 py-2 pb-5 bg-[#FFFFFF]"
        style={{ borderBottomLeftRadius: 18, borderBottomRightRadius: 18 }}
      >
        <h1 className="text-[2.5rem] font-bold text-[#18181B]">
          Change Password
        </h1>
      </div>

      {/* Form */}
      <div className="overflow-x-auto rounded-2xl bg-[#FFFFFF] max-w-[55%] shadow-sm px-6 py-6">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="form-sec flex flex-col  gap-[1.3rem]">
            <PasswordField
              validation={register}
              fieldName="oldPassword"
              label="Old Password"
              error={errors?.oldPassword?.message}
            />
            <PasswordField
              validation={register}
              fieldName="newPassword"
              label="New Password"
              error={errors?.newPassword?.message}
            />
            <PasswordField
              validation={register}
              fieldName="confirmPassword"
              label="Confirm Password"
              error={errors?.confirmPassword?.message}
            />
          </div>
          <div className="flex justify-end gap-4 mt-[1.3rem]">
            <button
              type="button"
              onClick={() => navigate(-1)}
              disabled={isLoading}
              className="border border-[#FC6935] cursor-pointer text-[#FC6935] rounded-full px-[25px] py-[11px] font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
            >
              {isLoading ? "Changing..." : "Change Password"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ChangePassword;
