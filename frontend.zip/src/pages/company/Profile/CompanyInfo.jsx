import React, { useRef } from "react";
import { RiUploadCloud2Line } from "react-icons/ri";
import { CiCamera } from "react-icons/ci";
import ViewIcon from "../../../assets/img/preview.svg";
import Select from "react-select";
import toast from "react-hot-toast";
import "../companyStyle.scss"

const CompanyInformation = ({ data, updateData, onNext }) => {
  const fileInputRef = useRef(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    updateData({
      ...data,
      [name]: value,
    });
  };

  const triggerFileUpload = () => {
    fileInputRef.current.click();
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.match('image.*')) {
        toast.error('Please select an image file (PNG, JPG, JPEG)');
        return;
      }
  
      if (file.size > 2 * 1024 * 1024) {
        toast.error('Profile image size should be less than 2MB');
        return;
      }
  
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64Image = reader.result;
  
        updateData({
          ...data,
          image_url: base64Image,
          imageFile: file,
        });
      };
  
      reader.readAsDataURL(file);
    }
  };
  
  const teamSizeOptions = [
    { value: "2-10", label: "2-10" },
    { value: "11-50", label: "11-50" },
    { value: "51-100", label: "51-100" },
    { value: "101-500", label: "101-500" },
    { value: "501-1000", label: "501-1000" },
    { value: "1000+", label: "1000+" },
  ];

  const languageOptions = [
    { value: "Urdu", label: "Urdu" },
    { value: "English", label: "English" },
    { value: "Spanish", label: "Spanish" },
    { value: "French", label: "French" },
  ];

  return (
    <div className="">
      <div className="flex justify-between items-start">
        <h1 className="text-2xl font-semibold text-[#171725] mb-6">
          Company Information
        </h1>
        <div className="flex items-center gap-1">
          <img src={ViewIcon} alt="Preview" />{" "}
          <span className="text-[1rem] font-semibold text-[#FC6935]">
            View Preview
          </span>
        </div>
      </div>

      <div className="mb-8 flex items-center gap-8">
        {data?.image_url ? (
          <img
            src={data.image_url}
            className="w-25 h-25 bg-[#D9D9D9] rounded-full flex items-center justify-center object-cover"
            alt="Profile"
          />
        ) : (
          <div className="w-25 h-25 bg-[#D9D9D9] rounded-full flex items-center justify-center">
            <CiCamera className="w-6 h-6" />
          </div>
        )}
        <div className="">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/png, image/jpeg, image/jpg"
            className="hidden"
          />
          <button
            onClick={triggerFileUpload}
            className="flex items-center bg-[#FC6935] text-white text-[1rem] font-semibold rounded-full cursor-pointer px-4 py-2 transition-colors"
          >
            <RiUploadCloud2Line />
            &nbsp; Upload
          </button>
          <p className="text-[#707070] text-sm mt-1">PNG, JPG,JPEG (2MB)</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Company Name</h2>
          <input
            type="text"
            name="full_name"
            value={data?.full_name || ""}
            onChange={handleInputChange}
            placeholder="Company Name"
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          />
        </div>

        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Email*</h2>
          <input
            type="text"
            readOnly
            disabled
            value={data?.email || ""}
            placeholder="Enter email address"
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          />
        </div>

        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Joining Date</h2>
          <input
            type="date"
            name="joining_date"
            value={data?.joining_date || ""}
            onChange={handleInputChange}
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          />
        </div>

        <div className="mb-4">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Team Size</h2>
          <Select
            options={teamSizeOptions}
            value={teamSizeOptions.find((option) => option.value === data?.team_size)}
            onChange={(selectedOption) =>
              updateData({ ...data, team_size: selectedOption.value })
            }
            className="w-full py-[5px] px-6 pr-[0.6rem] border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
            classNamePrefix="react-select xyz"
          />
        </div>

        <div className="mb-4 col-span-1 md:col-span-2">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">Address</h2>
          <input
            name="address"
            value={data?.address || ""}
            onChange={handleInputChange}
            placeholder="Address"
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          />
        </div>

        <div className="mb-4 col-span-1 md:col-span-2">
          <h2 className="text-[1rem] text-[#696F79] mb-3">Languages</h2>
          <Select
            options={languageOptions}
            value={languageOptions.find((option) => option.value === data?.language)}
            onChange={(selectedOption) =>
              updateData({ ...data, language: selectedOption.value })
            }
            className="w-full py-[5px] px-6 pr-[0.6rem] border border-[#ACB2B980] rounded-full focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
            classNamePrefix="react-select xyz"
          />
        </div>

        <div className="mb-4 col-span-1 md:col-span-2">
          <h2 className="text-[1rem] text-[#696F79] mb-2.5">About Me</h2>
          <textarea
            name="about_company"
            value={data?.about_company || ""}
            onChange={handleInputChange}
            placeholder="Write about yourself"
            rows="4"
            className="w-full py-3 px-6 border border-[#ACB2B980] rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#FC6935]"
          ></textarea>
        </div>
      </div>

      <div className="flex justify-end mt-8">
        <button
          onClick={onNext}
          className="bg-[#FC6935] text-white rounded-[3.1rem] px-[1.5rem] py-[0.6rem] font-semibold text-[1rem] cursor-pointer"
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default CompanyInformation;
