import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import ProfileSide from "./ProfileSide";
import CompanyInformation from "./CompanyInfo";
import ContactInfo from "./ContactInfo";
import { api } from "../../utlis/customAPI";
import {
  apiToFrontendFormatCompany,
  frontendToApiFormatCompany,
  getInitialProfileDataCompany,
} from "../../Private/Profile/helper";

export default function Profile({ setProgress }) {
  const [selectedOption, setSelectedOption] = useState("Company Information");
  const options = ["Company Information", "Contact Information"];
  const token = localStorage.getItem("ai-token");
  const [profileData, setProfileData] = useState(
    getInitialProfileDataCompany()
  );

  useEffect(() => {
    if (token) {
      setProgress(20);
      api
        .get("/company/get-profile")
        .then(({ data }) => {
          console.log(data);
          const formattedData = apiToFrontendFormatCompany(data);
          setProfileData(formattedData);
          setProgress(59);
        })
        .catch((error) => {
          console.log(error);
          setProfileData(getInitialProfileDataCompany());
        })
        .finally(() => setProgress(100));
    }
  }, [token]);

  const updateProfileData = (section, newData) => {
    setProfileData((prev) => {
      if (typeof newData === "object" && !Array.isArray(newData)) {
        return {
          ...prev,
          [section]: {
            ...prev[section],
            ...newData,
          },
        };
      }
      return {
        ...prev,
        [section]: newData,
      };
    });
  };
  const handleNext = () => {
    const currentIndex = options.indexOf(selectedOption);
    if (currentIndex < options.length - 1) {
      setSelectedOption(options[currentIndex + 1]);
    }
  };

  const handlePrevious = () => {
    const currentIndex = options.indexOf(selectedOption);
    if (currentIndex > 0) {
      setSelectedOption(options[currentIndex - 1]);
    }
  };

  const handleSubmit = async () => {
    setProgress(30);
    console.log(profileData, "profileData");
    const apiPayload = frontendToApiFormatCompany(profileData);
    await api
      .put("/company/update-profile", apiPayload)
      .then((res) => {
        const user = JSON.parse(localStorage.getItem("ai-user"));
        const updateUser = {
          ...user,
          personalInfo: {
            ...user.personalInfo,
            image_url: res?.data?.profile?.personalInformation?.image_url,
          },
        };
        localStorage.setItem("ai-user", JSON.stringify(updateUser));
        setProgress(70);
        toast.success("Profile updated successfully");
      })
      .catch((error) => {
        console.error(error);
        toast.error("Failed to update profile");
      })
      .finally(() => setProgress(100));
  };

  const selectedSection = () => {
    switch (selectedOption) {
      case "Company Information":
        return (
          <CompanyInformation
            data={profileData.personalInfo}
            updateData={(newData) => updateProfileData("personalInfo", newData)}
            onNext={handleNext}
            isFirst={true}
          />
        );
      default:
        return (
          <ContactInfo
            data={profileData.contactInfo}
            updateData={(newData) => updateProfileData("contactInfo", newData)}
            onSubmit={handleSubmit}
            onPrevious={handlePrevious}
            isLast={true}
          />
        );
    }
  };

  return (
    <div className="family-outfit bg-white">
      <div className="px-16 w-full">
        <div className="py-12">{selectedSection()}</div>
      </div>
    </div>
  );
}
