export default function Options({
    options,
    selectedOption,
    setSelectedOption,
  }) {
    return (
      <div className="p-4 pl-0">
        <ul className="space-y-2">
          {options?.map((option) => (
            <li
              key={option}
              onClick={() => setSelectedOption(option)}
              className={`flex items-center gap-4.5 cursor-pointer rounded-full px-6 py-2.5 text-[1rem] font-medium ${
                selectedOption === option
                  ? "bg-[#F6F3EA] text-[#FC6935]"
                  : "text-[#707070]"
              }`}
            >
              <span
                className={`w-3 h-3 rounded-full border-3 ${
                  selectedOption === option
                    ? "border-[#FC6935]"
                    : "border[#707070]"
                }`}
              />
              {option}
            </li>
          ))}
        </ul>
      </div>
    );
  }
  