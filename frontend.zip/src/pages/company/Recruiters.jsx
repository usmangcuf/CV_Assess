import moment from "moment/moment";
import { useEffect, useRef, useState } from "react";
import toast from "react-hot-toast";
import { FaUser } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { api } from "../utlis/customAPI";
import "./companyStyle.scss";
import RecruiterDetailModal from "../common/recruiter/RecruiterDetailModal";
const Recruiters = ({ setProgress }) => {
  const [page, setPage] = useState(1);
  const [query, setQuery] = useState("");
  const [isDelete, setIsDelete] = useState(false);
  const [recruiters, setRecruiters] = useState([]);
  const [totalPages, setTotalPages] = useState(0);
  const [deleteModal, setDeleteModal] = useState({
    open: false,
    recruiter: null,
  });
  const [recruiterModal, setRecruiterModal] = useState({
    open: false,
    recruiter: null,
  });
  const handleRefreshRecruitersList = (type, data) => {
    setRecruiters((prev) => {
      switch (type) {
        case "delete":
          return prev.filter((r) => r._id !== data);
        case "add":
          return [...prev, data];
        case "update":
          return prev.map((r) => (r._id === data._id ? data : r));
        default:
          return prev;
      }
    });
  };

  const handleDeleteRecruiter = async (recruiter) => {
    setIsDelete(true);
    setProgress(30);
    try {
      await api.delete(`/company/remove-hr/${recruiter._id}`);
      setProgress(80);
      setDeleteModal({ open: false, recruiter: null });
      handleRefreshRecruitersList("delete", recruiter._id);
      toast.success("Recruiter deleted successfully");
    } catch (err) {
      toast.error("Failed to delete recruiter");
      setIsDelete(false);
      setProgress(100);
    } finally {
      setIsDelete(false);
      setProgress(100);
    }
  };

  const openDeleteModal = (recruiter) =>
    setDeleteModal({ open: true, recruiter });
  const closeDeleteModal = () =>
    setDeleteModal({ open: false, recruiter: null });

  const fetchRecruiters = async () => {
    setProgress(30);
    await api
      .get(`/company/get-hr?page=${page}&search=${query}`)
      .then((res) => {
        setProgress(70);
        setRecruiters(res.data.hrList);
        setTotalPages(res.data.totalPages);
      })
      .catch((err) => {
        console.log(err);
        setProgress(100);
      })
      .finally(() => {
        setProgress(100);
      });
  };
  useEffect(() => {
    fetchRecruiters();
  }, [page, query]);

  const handlePageChange = (n) => {
    if (n >= 1 && n <= totalPages) setPage(n);
  };
  const handleOpenRecruiterModal = (selected) => {
    setRecruiterModal({ open: true, recruiter: selected });
  };
  const handleCloseRecruiterModal = () => {
    setRecruiterModal({ open: false, recruiter: null });
  };
  return (
    <div className="bg-[#F6F3EA] overflow-y-auto">
      {/* Header */}
      <div
        className="flex items-center mb-1 justify-between px-6 py-2 pb-5 bg-[#FFFFFF]"
        style={{ borderBottomLeftRadius: 18, borderBottomRightRadius: 18 }}
      >
        <h1 className="text-[2.5rem] font-bold text-[#18181B]">
          All Recruiters
        </h1>
        <div className="flex items-center gap-3">
          <div className="relative">
            <input
              type="text"
              placeholder="Search By Name"
              className="rounded-full pl-10 pr-4 py-2 bg-[#F4F4F5] text-[#71717A] text-base outline-none w-56"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <svg
              className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#A1A1AA]"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35" />
            </svg>
          </div>
          <button
            onClick={() => handleOpenRecruiterModal(null)}
            className="bg-[#FF7A2F] text-white cursor-pointer border-0 rounded-full font-bold text-[14px] py-2 px-4 flex items-center gap-2"
          >
            <FaUser />
            Add Recruiter
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-2xl bg-[#FFFFFF] shadow-sm px-6 pb-6">
        <table className="min-w-full whitespace-nowrap">
          <thead>
            <tr className="text-[#A1A1AA] text-xs font-semibold">
              <th className="px-3 py-4 text-left">
                <span className="ml-2">Sr.</span>
              </th>
              <th className="px-6 py-4 text-left">
                <span className="ml-2">NAME</span>
              </th>
              <th className="px-4 py-4 text-left">EMAIL</th>
              <th className="px-4 py-4 text-left">GENDER</th>
              <th className="px-4 py-4 text-left">CREATED AT</th>
              <th className="px-4 py-4 text-left">ACTION</th>
            </tr>
          </thead>
          <tbody>
            {recruiters.length === 0
              ? Array.from({ length: 5 }).map((_, idx) => (
                  <tr
                    key={idx}
                    className="border-t border-[#F4F4F5] animate-pulse"
                  >
                    <td className="px-6 py-4">
                      <div className="h-4 w-6 bg-gray-200 rounded" />
                    </td>
                    <td className="px-6 py-4">
                      <div className="h-4 w-32 bg-gray-200 rounded mb-2" />
                    </td>
                    <td className="px-4 py-4">
                      <div className="h-4 w-20 bg-gray-200 rounded" />
                    </td>
                    <td className="px-4 py-4">
                      <div className="h-4 w-14 bg-gray-200 rounded" />
                    </td>
                    <td className="px-4 py-4">
                      <div className="h-4 w-16 bg-gray-200 rounded mb-1" />
                    </td>
                    <td className="px-4 py-4 relative">
                      <div className="h-8 w-8 bg-gray-200 rounded-full" />
                    </td>
                  </tr>
                ))
              : recruiters.map((recruiter, idx) => (
                  <tr
                    key={idx}
                    className="border-t border-[#F4F4F5] hover:bg-[#FAFAFA] transition"
                  >
                    <td className="px-6 py-4 items-center">
                      <div>
                        <div className="font-semibold text-[#18181B] text-base">
                          {idx + 1}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 flex items-center gap-4">
                      {/* <input type="checkbox" className="accent-[#E5E7EB] w-4 h-4" /> */}
                      <div>
                        <div className="font-semibold text-[#18181B] text-base cursor-pointer">
                          {recruiter?.first_name} {recruiter?.last_name}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-[#18181B] font-medium text-sm">
                      {recruiter?.email}
                    </td>
                    <td className="px-4 py-4 text-[#18181B] text-sm capitalize">
                      {recruiter?.gender || "-- --"}
                    </td>
                    <td className="px-4 py-4 text-[#18181B] text-sm">
                      {moment(recruiter?.createdAt).format("LL")}
                    </td>
                    <td className="px-4 py-4 relative">
                      <ActionMenu
                        recruiter={recruiter}
                        onDelete={openDeleteModal}
                        onUpdate={() => handleOpenRecruiterModal(recruiter)}
                      />
                    </td>
                  </tr>
                ))}
          </tbody>
        </table>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-6">
            <button
              className="flex items-center gap-2 px-4 py-2 border border-[#FF6A3D] text-[#FF6A3D] rounded-full bg-white hover:bg-[#FFF2ED] transition"
              onClick={() => handlePageChange(page - 1)}
              disabled={page === 1}
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M15 19l-7-7 7-7" />
              </svg>
              Previous
            </button>
            <div className="flex items-center gap-2">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((n) => (
                <button
                  key={n}
                  onClick={() => handlePageChange(n)}
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-[#A1A1AA] ${
                    n === page ? "bg-[#FFF2ED] text-[#FF6A3D]" : "bg-[#F4F4F5]"
                  } cursor-pointer`}
                >
                  {n}
                </button>
              ))}
            </div>
            <button
              className="flex items-center gap-2 px-4 py-2 border border-[#FF6A3D] text-[#FF6A3D] rounded-full bg-white hover:bg-[#FFF2ED] transition"
              onClick={() => handlePageChange(page + 1)}
              disabled={page === totalPages}
            >
              Next
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/10 backdrop-blur-sm">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm">
            <h2 className="text-lg font-semibold mb-4">Confirm Deletion</h2>
            <p className="mb-6">
              Are you sure you want to delete this recruiter?
            </p>
            <div className="flex justify-end gap-3">
              <button
                className="px-4 py-2 rounded bg-gray-200 hover:bg-gray-300"
                onClick={closeDeleteModal}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 rounded bg-red-500 text-white hover:bg-red-600"
                onClick={() => handleDeleteRecruiter(deleteModal.recruiter)}
                disabled={isDelete}
              >
                {isDelete ? "wait..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Recruiter Modal */}
      {recruiterModal?.open && (
        <RecruiterDetailModal
          open={recruiterModal?.open}
          handleClose={handleCloseRecruiterModal}
          setProgress={setProgress}
          recruiter={recruiterModal?.recruiter}
          handleRefreshRecruitersList={handleRefreshRecruitersList}
        />
      )}
    </div>
  );
};

function ActionMenu({ recruiter, onDelete, onUpdate }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const btnRef = useRef(null);

  // Close menu on outside click
  useEffect(() => {
    function handleClick(e) {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target) &&
        btnRef.current &&
        !btnRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    }
    if (open) {
      document.addEventListener("mousedown", handleClick);
    } else {
      document.removeEventListener("mousedown", handleClick);
    }
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  function handleDelete(item) {
    setOpen(false);
    if (onDelete) onDelete(item);
  }

  return (
    <div className="relative inline-block text-left">
      <button
        ref={btnRef}
        onClick={() => setOpen((v) => !v)}
        className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-[#F4F4F5] focus:outline-none"
      >
        <svg
          className="w-5 h-5 text-[#A1A1AA]"
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <circle cx="10" cy="4" r="1.5" />
          <circle cx="10" cy="10" r="1.5" />
          <circle cx="10" cy="16" r="1.5" />
        </svg>
      </button>
      {open && (
        <div
          ref={menuRef}
          className="absolute right-0 z-20 mt-2 w-32 origin-top-right rounded-xl bg-white shadow-lg focus:outline-none animate-fade-in"
        >
          <div>
            <button
              onClick={() => handleDelete(recruiter)}
              className="w-full flex items-center gap-2 px-4 py-2 text-sm text-[#EF4444] hover:bg-[#FEE2E2] rounded-t-xl"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M6 18L18 6M6 6l12 12" />
              </svg>
              Delete
            </button>
            <button
              onClick={() => onUpdate(recruiter)}
              className="w-full flex items-center gap-2 px-4 py-2 text-sm text-[#F59E42] hover:bg-[#FFF7ED]"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path d="M15.232 5.232l3.536 3.536M9 11l6 6M3 17v4h4l11-11a2.828 2.828 0 00-4-4L3 17z" />
              </svg>
              Update
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Recruiters;
