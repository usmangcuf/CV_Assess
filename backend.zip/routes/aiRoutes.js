const express = require("express");
const router = express.Router();
const { GoogleGenerativeAI } = require("@google/generative-ai");
const OpenAI = require("openai");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_KEY);
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function generateJob({ title, description, key_responsibilities }) {

  if (!title || typeof title !== "string") {
    return { error: "Title is required and must be a string." };
  }

  if (!description && !key_responsibilities) {
    return { error: "Either 'description' or 'key_responsibilities' must be true." };
  }

  let prompt = `You are a professional job assistant.\n\n`;
  prompt += `Job Title: ${title}\n\n`;

  if (description) {
    prompt += `Generate a professional, well-structured HTML-formatted job description for the above role. Include sections like Introduction, Responsibilities, and Requirements. Use proper HTML tags such as <h2>, <p>, <ul>, <li> so it's ready to paste into a rich text editor.`;
  } else if (key_responsibilities) {
    prompt += `Generate a clear, well-formatted HTML list of key responsibilities for the job title above. Use proper HTML tags like <h2>, <ul>, and <li> to structure the content.`;
  }

  const resp = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
    max_tokens: 2000,
  });

  let html = resp.choices[0].message.content.trim();

  html = html.replace(/\\n/g, "").replace(/\r?\n/g, "");

  return html;
}



router.post("/generate", async (req, res) => {
  try {
    const jobText = await generateJob(req.body);
    res.json(jobText);
  } catch (err) {
    res.status(500).json({ error: err });
  }
});

module.exports = router;
