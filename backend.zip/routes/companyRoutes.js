const express = require("express");
const {
  createJob,
  getJobs,
  getSingleJob,
  updateJob,
  deleteJob,
  getApplications,
  getSingleApplication,
  deleteApplication,
  scanApplication,
  addHrUser,
  removeHrUser,
  getHrList,
  getSingleHr,
  generateReport,
  updateApplicationStatus,
  getJobApplications,
  updateHrUser,
} = require("../controllers/companyControllers");
const { authenticateToken } = require("../midleware/authenticateToken");
const { updateCompanyProfile, getCompanyProfile } = require("../controllers/CompanyProfileController");

const router = express.Router();

// POST || login blood bank

router.post("/create-job", authenticateToken, createJob);
router.get("/jobs", authenticateToken, getJobs);
router.get("/job/:job_id", authenticateToken, getSingleJob);
router.put("/job/:job_id", authenticateToken, updateJob);
router.delete("/job/:job_id", authenticateToken, deleteJob);

//application routes
router.get("/applications", authenticateToken, getApplications);
router.get("/job-applications/:job_id", authenticateToken, getJobApplications);
router.get(
  "/application/:application_id",
  authenticateToken,
  getSingleApplication
);
router.delete(
  "/application/:application_id",
  authenticateToken,
  deleteApplication
);

router.post("/application/scan", authenticateToken, scanApplication);

router.post("/add-hr", authenticateToken, addHrUser);
router.delete("/remove-hr/:hrId", authenticateToken, removeHrUser);
router.get("/get-hr", authenticateToken, getHrList);
router.get("/get-hr/:hrId", authenticateToken, getSingleHr);
router.post("/generate_report", authenticateToken, generateReport);
router.put(
  "/update_application_status",
  authenticateToken,
  updateApplicationStatus
);
router.put("/update_hr/:hrId", authenticateToken, updateHrUser);

router.put("/update-profile", authenticateToken, updateCompanyProfile);

router.get("/get-profile", authenticateToken, getCompanyProfile);

module.exports = router;
