const express = require("express");
const { authenticateToken } = require("../midleware/authenticateToken");
const {
  getAllJobs,
  applyJob,
  getMyJobs,
  toggleSaveJob,
} = require("../controllers/candidateController");
const { upload } = require("../midleware/pdf-parser");
const {
  updateProfile,
  getProfile,
  getCandidateReport,
} = require("../controllers/CandidateProfileController");
const { getSingleJob } = require("../controllers/companyControllers");

const router = express.Router();

// candidate routes for APIS
router.get("/all-jobs", getAllJobs);
router.get("/job/:job_id", getSingleJob);
router.post("/apply-job", authenticateToken, upload.single("resume"), applyJob);

router.get("/my-jobs", authenticateToken, getMyJobs);
router.post("/toggle-save", authenticateToken, toggleSaveJob);

router.put(
  "/update-profile",
  authenticateToken,
  // upload.single("image"),
  updateProfile
);
router.get("/get-profile", authenticateToken, getProfile);

// Candidate activity report route
router.get("/report", authenticateToken, getCandidateReport);

module.exports = router;
