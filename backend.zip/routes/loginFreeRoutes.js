const express = require("express");
const { authenticateToken } = require("../midleware/authenticateToken");
const {
  getAllJobs,
  fileUploader,
  getSimilarJobs,
} = require("../controllers/loginFreeControllers");
const { getSingleJob } = require("../controllers/companyControllers");
const { upload } = require("../midleware/pdf-parser");

const router = express.Router();

// Login Free APIS
router.get("/all-jobs", getAllJobs);
router.get("/job/:job_id", getSingleJob);

router.post("/file-upload", upload.single("resume"), fileUploader);

module.exports = router;
