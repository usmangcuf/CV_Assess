const express = require("express");
const {
  signUp,
  login,
  forgotPassword,
  resetPassword,
  changePassword,
} = require("../controllers/authControllers");
const { authenticateToken } = require("../midleware/authenticateToken");

const router = express.Router();

// POST || login blood bank

router.post("/sign_up", signUp);
router.post("/login", login);
router.post("/forgot-password", forgotPassword);
router.post("/reset-password", resetPassword);
router.post("/change-password", authenticateToken, changePassword);

module.exports = router;
