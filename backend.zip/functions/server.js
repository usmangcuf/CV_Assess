const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("../config/connectionDB");
const serverless = require("serverless-http");

dotenv.config();

const app = express();

app.use(cors({ origin: "*", credentials: true }));
app.use(express.json());

connectDB();

app.get("/", (req, res) => {
  res.send(`Server is running on Netlify. Secret: ${process.env.JWT_SECRET}`);
});

app.use("/api/auth", require("../routes/authRoutes"));
app.use("/api/company", require("../routes/companyRoutes"));
app.use("/api", require("../routes/loginFreeRoutes"));
app.use("/api/candidate", require("../routes/candidateRoutes"));
app.use("/api/ai", require("../routes/aiRoutes"));

module.exports.handler = serverless(app);
