const mongoose = require("mongoose");

const CompanyPersonalInformationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    image_url: String,
    full_name: String,
    company_name: String,
    email: String,
    address: String,
    language: String,
    about_company: String,
    team_size: String,
    joining_date: Date,
  },
  { strict: false }
);

const SocialMediaSchema = new mongoose.Schema(
  {
    platform: String,
    link: String,
  },
  { _id: true }
);
const CompanyContactInformationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    phone_num: String,
    phone_num_optional: String,
    email: String,
    email_optional: String,
    website_url: String,
    social_media_urls: [SocialMediaSchema], 
  },
  { strict: false }
);

module.exports = {
  CompanyContactInformation: mongoose.model(
    "CompanyContactInformation",
    CompanyContactInformationSchema
  ),
  CompanyPersonalInformation: mongoose.model(
    "CompanyPersonalInformation",
    CompanyPersonalInformationSchema
  )
};
