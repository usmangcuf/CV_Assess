const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const User = new Schema(
  {
    first_name: { type: String, required: true },
    last_name: { type: String, required: true },
    email: { type: String, required: true },
    password: { type: String },
    company: { type: String },
    image_url: { type: String },
    company_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    gender: { type: String },
    about_company: { type: String },
    profile_type: {
      type: String,
      enum: ["company", "hr", "user"],
      default: "user",
    },
    createdAt: { type: Date, default: Date.now },
  },
  { strict: false }
);

const Job = new Schema(
  {
    title: { type: String, required: true },
    job_type: { type: String, required: true },
    min_salary: { type: String },
    max_salary: { type: String },
    pay_type: { type: String },
    description: { type: String, required: true },
    education: { type: String },
    address: { type: String },
    level: { type: String },
    key_responsibilities: { type: String },
    skills: { type: Array },
    job_location: {
      type: String,
    },
    start_date: {
      type: Date,
    },
    end_date: {
      type: Date,
    },
    company_id: { type: Schema.Types.ObjectId, ref: "User", required: true },
    createdAt: { type: Date, default: Date.now },
  },
  { strict: false }
);



const Application = new Schema(
  {
    candidate_id: { type: Schema.Types.ObjectId, ref: "User", required: true },
    job_id: { type: Schema.Types.ObjectId, ref: "Job", required: true },
    company_id: { type: Schema.Types.ObjectId, ref: "User", required: true }, // Employer
    status: {
      type: String,
      enum: ["pending", "interview", "shortlisted", "rejected", "hired"],
      default: "pending",
    },
    resume_url: { type: String, required: true },
    full_name: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: String, required: true },
    resume_desc: { type: String },
    resume_score: { type: Number },
    applied_at: { type: Date, default: Date.now },
  },
  { strict: false }
);

const MyJob = new Schema({
  candidate: { type: Schema.Types.ObjectId, ref: "User" },
  job: { type: Schema.Types.ObjectId, ref: "Job", required: true },
  company: { type: Schema.Types.ObjectId, ref: "User" },
  isSaved: { type: Boolean, default: false },
  isApplied: { type: Boolean, default: false },
});

module.exports = {
  User: mongoose.model("User", User),
  Job: mongoose.model("Job", Job),
  Application: mongoose.model("Application", Application),
  MyJob: mongoose.model("MyJobs", MyJob),
};
