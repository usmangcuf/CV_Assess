const mongoose = require("mongoose");

const PersonalInformationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    image_url: String,
    full_name: String,
    email: String,
    date_of_birth: Date,
    gender: String,
    address: String,
    pay_rate: {
      type: {
        period: { type: String, enum: ["hourly", "weekly", "monthly"] },
        currency: String,
        amount: Number,
      },
      default: {},
    },
    language: String,
    about: String,
    resume_url: String,
  },
  { strict: false }
);

const EducationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    institute: String,
    degree: String,
    field_of_study: String,
    start_date: Date,
    end_date: Date,
    is_present: { type: Boolean, default: false },
    description: String,
  },
  { strict: false }
);

const workHistorySchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    company: String,
    job_title: String,
    job_type: String,
    city: String,
    start_date: Date,
    end_date: Date,
    is_present: { type: Boolean, default: false },
    description: String,
  },
  { strict: false }
);

const CertificationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    institute: String,
    title: String,
    doc_url: String,
    description: String,
  },
  { strict: false }
);

const SocialMediaSchema = new mongoose.Schema(
  {
    platform: String,
    link: String,
  },
  { _id: true }
);

const ContactInformationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    phone_num: String,
    phone_num_optional: String,
    email: String,
    email_optional: String,
    portfolio_url: String,
    website_url: String,
    social_media_urls: [SocialMediaSchema],
  },
  { strict: false }
);

module.exports = {
  ContactInformation: mongoose.model(
    "ContactInformation",
    ContactInformationSchema
  ),
  Certification: mongoose.model("Certification", CertificationSchema),
  Education: mongoose.model("Education", EducationSchema),
  PersonalInformation: mongoose.model(
    "PersonalInformation",
    PersonalInformationSchema
  ),
  WorkHistory: mongoose.model("WorkHistory", workHistorySchema),
};
