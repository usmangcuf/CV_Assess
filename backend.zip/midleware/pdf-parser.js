const express = require("express");
const multer = require("multer");
const path = require("path");

// const upload = multer({ dest: "uploads/" });

const storage = multer.memoryStorage();
const upload = multer({ storage });

module.exports = { upload };
