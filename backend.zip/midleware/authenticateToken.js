const jwt = require("jsonwebtoken");
const { User } = require("../models/Model");

async function authenticateToken(req, res, next) {
  let token;
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    try {
      token = req.headers.authorization.split(" ")[1];

      //decodes token id
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      req.User = await User.findById({ _id: decoded.id });
      next();
    } catch (error) {
      res.status(401).send({
        data: {
          success: false,
          mag: "Not authorized, token failed",
        },
      });
    }
  }

  if (!token) {
    res.status(401).send({
      success: false,
      mag: "Not authorized, no token",
    });
  }
}

module.exports = {
  authenticateToken,
};
