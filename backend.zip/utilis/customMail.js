require("dotenv").config();
const nodemailer = require("nodemailer");

const sendMail = async (sendTo, subject, messagePlain, messageHtml) => {
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });

    const message = {
      from: '"Job Portal" <noreply@jobportal.com>',
      to: sendTo,
      subject: subject,
      text: messagePlain,
      html: messageHtml,
    };

    const info = await transporter.sendMail(message);
    console.log(`✅ Test email sent: ${info.messageId}`);
    console.log(`📩 Preview URL: ${nodemailer.getTestMessageUrl(info)}`);

    return { success: true, previewUrl: nodemailer.getTestMessageUrl(info) };
  } catch (error) {
    console.error(`❌ Error sending email: ${error.message}`);
    return { success: false, error: error.message };
  }
};

module.exports = { sendMail };
