const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("./config/connectionDB");

const app = express();

const corsConfig = {
  origin: "*",
  credentials: true,
  methods: ["GET", "PUT", "PATCH", "POST", "DELETE"],
};
app.options("", cors(corsConfig));
app.use(cors(corsConfig));
app.use(express.json());
dotenv.config();

connectDB();

app.get("/", (req, res) => {
  res.send("nshshsh");
});
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/company", require("./routes/companyRoutes"));
app.use("/api/candidate", require("./routes/candidateRoutes"));
app.use("/api", require("./routes/loginFreeRoutes"));
app.use("/api/ai", require("./routes/aiRoutes"));

// Start server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
