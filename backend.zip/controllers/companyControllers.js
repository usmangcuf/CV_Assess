const dotenv = require("dotenv");
dotenv.config();
const { Job, Application, User } = require("../models/Model");

const cosineSimilarity = require("cosine-similarity");
const natural = require("natural");
const { hashPassword } = require("../utilis/passwordHash");
const { sendMail } = require("../utilis/customMail");
const { CompanyPersonalInformation } = require("../models/CompanyProfileModels");
const TfIdf = natural.TfIdf;

const createJob = async (req, res) => {
  if (req.User.profile_type === "user") {
    return res.status(400).json({
      success: false,
      message: "Only Company and HR can create Job",
    });
  }
  try {
    const requiredFields = ["title", "job_type", "description"];
    const missingFields = requiredFields.filter((field) => !req.body[field]);

    if (missingFields.length > 0) {
      return res.status(400).json({
        success: false,
        message: `${missingFields.join(", ")} is required.`,
      });
    }

    const {
      title,
      job_type,
      min_salary,
      max_salary,
      description,
      education,
      address,
      level,
      key_responsibilities,
      start_date,
      end_date,
      pay_type,
      job_location,
      skills,
    } = req.body;

    const newJob = new Job({
      title,
      job_type,
      min_salary,
      max_salary,
      description,
      education,
      address,
      level,
      key_responsibilities,
      start_date: new Date(start_date),
      end_date: new Date(end_date),
      pay_type,
      job_location,
      company_id:
        req.User.profile_type === "hr" ? req.User.company_id : req.User._id,
      skills,
    });

    await newJob.save();

    res.status(201).json({
      success: true,
      message: "Job created successfully!",
      job: newJob,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const getJobs = async (req, res) => {
  try {
    const {
      title,
      job_type,
      min_salary,
      max_salary,
      education,
      address,
      level,
      start_date,
      end_date,
      pay_type,
      job_location,
      page = 1,
    } = req.query;
    // filters
    const filter = { company_id: req.User._id };
    if (title) filter.title = { $regex: title, $options: "i" };
    if (job_type) filter.job_type = job_type;
    if (min_salary) filter.min_salary = { $gte: min_salary };
    if (max_salary) filter.max_salary = { $lte: max_salary };
    if (education) filter.education = { $regex: education, $options: "i" };
    if (address) filter.address = { $regex: address, $options: "i" };
    if (level) filter.level = level;
    if (start_date) filter.start_date = { $gte: start_date };
    if (end_date) filter.end_date = { $lte: end_date };
    if (pay_type) filter.pay_type = { $regex: pay_type, $options: "i" };
    if (job_location)
      filter.job_location = { $regex: job_location, $options: "i" };

    const limit = 20;
    const skip = (page - 1) * limit;

    const jobs = await Job.find(filter)
      .populate({
        path: "company_id",
        select: "_id image_url first_name last_name company",
      })
      .skip(skip)
      .limit(limit);
    const totalJobs = await Job.countDocuments(filter);

    res.status(200).json({
      success: true,
      jobs,
      totalPages: Math.ceil(totalJobs / limit),
      currentPage: page,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

// const getSingleJob = async (req, res) => {
//   const { job_id } = req.params;
//   if (!job_id) {
//     return res.status(400).json({
//       message: "Job id is required",
//       success: false,
//     });
//   }
//   try {
//     const job = await Job.findById({
//       _id: job_id,
//     }).populate({
//       path: "company_id",
//       select: "_id image_url first_name last_name company about_company",
//     });
//     if (!job) {
//       return res.status(400).json({
//         success: false,
//         msg: "Job not found",
//       });
//     }

//     // Find similar jobs (by job_type or similar title, excluding this job)
//     const similarJobs = await Job.find({
//       _id: { $ne: job_id },
//       $or: [
//         { job_type: job.job_type },
//         { title: { $regex: job.title, $options: "i" } },
//       ],
//     }).limit(5);

//     res.status(200).json({
//       job,
//       similarJobs,
//       success: true,
//       msg: "Job fetch successfuly",
//     });
//   } catch (error) {
//     res.status(500).json({
//       success: false,
//       message: "Internal server error",
//       error: error.message,
//     });
//   }
// };


const getSingleJob = async (req, res) => {
  const { job_id } = req.params;
  if (!job_id) {
    return res.status(400).json({
      message: "Job id is required",
      success: false,
    });
  }

  try {
    const job = await Job.findById(job_id).populate({
      path: "company_id",
      select: "_id first_name last_name company",
    });

    if (!job) {
      return res.status(400).json({
        success: false,
        msg: "Job not found",
      });
    }

    const companyInfo = await CompanyPersonalInformation.findOne({
      user: job.company_id._id,
    }).select("image_url about_company");

    
    const similarJobs = await Job.find({
      _id: { $ne: job_id },
      $or: [
        { job_type: job.job_type },
        { title: { $regex: job.title, $options: "i" } },
      ],
    }).populate({
      path: "company_id",
      select: "_id image_url first_name last_name company",
    }).limit(5);

    res.status(200).json({
      job,
      companyInfo,
      similarJobs,
      success: true,
      msg: "Job fetch successfuly",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};


const updateJob = async (req, res) => {
  if (req.User.profile_type === "user") {
    return res.status(400).json({
      success: false,
      message: "Only Company and HR can update Job",
    });
  }
  try {
    const { job_id } = req.params;
    const updateData = req.body;

    const updatedJob = await Job.findByIdAndUpdate(
      { _id: job_id },
      updateData,
      {
        new: true,
      }
    );

    if (!updatedJob) {
      return res.status(404).json({ message: "Job not found" });
    }

    res
      .status(200)
      .json({ message: "Job updated successfully", job: updatedJob });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error updating job", error: error.message });
  }
};
const deleteJob = async (req, res) => {
  if (req.User.profile_type === "user") {
    return res.status(400).json({
      success: false,
      message: "Only Company and HR can create Job",
    });
  }
  try {
    const { job_id } = req.params;

    if (!job_id) {
      return res.status(400).json({
        message: "Job id is required",
        success: false,
      });
    }
    const deletedJob = await Job.findByIdAndDelete({ _id: job_id });

    if (!deletedJob) {
      return res.status(404).json({ message: "Job not found" });
    }

    res.status(200).json({ message: "Job deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error delete job", error: error.message });
  }
};

const getApplications = async (req, res) => {
  try {
    const { search, page = 1 } = req.query;

    const filter = {
      company_id:
        req.User.profile_type === "hr" ? req.User.company_id : req.User._id,
    };

    let jobIds = [];
    if (search) {
      // Find job IDs whose title matches the search string
      jobIds = await Job.find({
        title: { $regex: search, $options: "i" },
      }).distinct("_id");

      filter.$or = [
        { full_name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
        { phone: { $regex: search, $options: "i" } },
        { status: { $regex: search, $options: "i" } },
        { job_id: { $in: jobIds } },
      ];
    }

    const limit = 20;
    const skip = (page - 1) * limit;

    let applications = await Application.find(filter)
      .select("-resume_desc")
      .populate({
        path: "job_id",
        select: "_id title",
      })
      .skip(skip)
      .limit(limit);
    const totalApplications = await Application.countDocuments(filter);

    res.status(200).json({
      success: true,
      applications,
      totalPages: Math.ceil(totalApplications / limit),
      currentPage: page,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const getJobApplications = async (req, res) => {
  try {
    const { job_id } = req.params;
    if (!job_id) {
      return res.status(400).json({
        message: "Job id is required",
        success: false,
      });
    }
    const { search, page = 1 } = req.query;

    const filter = {
      job_id,
      company_id:
        req.User.profile_type === "hr" ? req.User.company_id : req.User._id,
    };

    let jobMatch = {};
    if (search) {
      filter.$or = [
        { full_name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
        { phone: { $regex: search, $options: "i" } },
        { status: { $regex: search, $options: "i" } },
      ];
    }

    const limit = 20;
    const skip = (page - 1) * limit;

    let applications = await Application.find(filter)
      .select("-resume_desc")
      .populate({
        path: "job_id",
        select: "_id title",
        match: Object.keys(jobMatch).length ? jobMatch : undefined,
      })
      .skip(skip)
      .limit(limit);
    applications = applications.filter((app) => app.job_id !== null);
    const totalApplications = await Application.countDocuments(filter);

    const allIds = await Application.find({
      job_id,
      company_id:
        req.User.profile_type === "hr" ? req.User.company_id : req.User._id,
    }).select("_id");
    const applicationIds = allIds.map((app) => app._id);

    res.status(200).json({
      success: true,
      applications,
      totalPages: Math.ceil(totalApplications / limit),
      currentPage: page,
      applicationIds,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const getSingleApplication = async (req, res) => {
  const { application_id } = req.params;
  if (!application_id) {
    return res.status(400).json({
      message: "Application id is required",
      success: false,
    });
  }
  try {
    const application = await Application.findById({
      _id: application_id,
    });
    if (!application) {
      return res.status(404).json({
        success: false,
        msg: "Application not found",
      });
    }
    res.status(200).json({
      application,
      success: true,
      msg: "Application fetch successfuly",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const deleteApplication = async (req, res) => {
  if (req.User.profile_type === "user") {
    return res.status(400).json({
      success: false,
      message: "Only Company and HR can delete application",
    });
  }
  try {
    const { application_id } = req.params;

    if (!application_id) {
      return res.status(400).json({
        message: "application id is required",
        success: false,
      });
    }
    const deletedApplication = await Application.findOneAndDelete({
      _id: application_id,
      company_id:
        req.User.profile_type === "hr" ? req.User.company_id : req.User._id,
    });

    if (!deletedApplication) {
      return res.status(404).json({ message: "Application not found" });
    }

    res.status(200).json({ message: "Application deleted successfully" });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error application job", error: error.message });
  }
};

const scanApplication = async (req, res) => {
  try {
    const { applications_id, total_top } = req.body;
    if (!total_top) {
      return res.status(400).json({
        success: false,
        message: "total_top is required",
      });
    }
    if (
      !applications_id ||
      !Array.isArray(applications_id) ||
      applications_id.length === 0
    ) {
      return res
        .status(400)
        .json({ success: false, message: "applications_id array required" });
    }

    const processApplication = async (appId) => {
      try {
        const application = await Application.findById(appId).populate(
          "job_id"
        );
        if (!application) {
          return { application_id: appId, error: "Application not found" };
        }

        const job = application.job_id;
        if (!job) {
          return { application_id: appId, error: "Job not found" };
        }

        const resumeText = application.resume_desc || "";
        const jobText = job.description || "";

        if (!resumeText || !jobText) {
          return {
            application_id: appId,
            error: "Missing resume or job description",
          };
        }

        const tfidf = new TfIdf();
        tfidf.addDocument(jobText);
        tfidf.addDocument(resumeText);

        const jobVector = tfidf.listTerms(0).map((term) => term.tfidf);
        const resumeVector = tfidf.listTerms(1).map((term) => term.tfidf);

        const score = cosineSimilarity(jobVector, resumeVector);
        application.resume_score = Math.round(score * 100);

        await application.save();

        const populatedApplication = await Application.findById(
          application._id
        ).select("-resume_desc");

        return {
          // application_id: appId,
          // resume_score: application.resume_score,
          application: populatedApplication,
        };
      } catch (err) {
        return { application_id: appId, error: err.message };
      }
    };

    const BATCH_SIZE = 10;
    const batches = [];
    for (let i = 0; i < applications_id.length; i += BATCH_SIZE) {
      batches.push(applications_id.slice(i, i + BATCH_SIZE));
    }

    const allResults = [];

    for (const batch of batches) {
      const batchResults = await Promise.allSettled(
        batch.map(processApplication)
      );
      batchResults.forEach((result) => {
        if (result.status === "fulfilled") {
          allResults.push(result.value);
        } else {
          allResults.push({
            application_id: result.reason.application_id,
            error: result.reason.message,
          });
        }
      });
    }

    const successfulApps = allResults.filter(
      (item) =>
        item.application && typeof item.application.resume_score === "number"
    );
    const errors = allResults.filter((item) => !item.application);

    successfulApps.sort(
      (a, b) => b.application.resume_score - a.application.resume_score
    );
    const topApplications = successfulApps.slice(0, total_top);
    return res.status(200).json({
      success: true,
      results: [...topApplications, ...errors],
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};

const addHrUser = async (req, res) => {
  try {
    const profile_type = req.User.profile_type;
    const _id = req.User._id;

    const { first_name, last_name, email, gender } = req.body;

    const generateRandomPassword = (length = 10) => {
      const chars =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
      let pass = "";
      for (let i = 0; i < length; i++) {
        pass += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return pass;
    };
    const password = generateRandomPassword();

    if (profile_type !== "company") {
      return res
        .status(403)
        .json({ message: "Only company profiles can add HR users." });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res
        .status(400)
        .json({ message: "User with this email already exists." });
    }

    const hashedPassword = await hashPassword(password);

    const newHr = new User({
      first_name,
      last_name,
      email,
      password: hashedPassword,
      company_id: _id,
      profile_type: "hr",
      gender,
    });

    await newHr.save();

    // Send email
    const loginLink = "https://ai-portal-six.vercel.app/login";
    const messagePlain = `Hello, you've been added as an HR.\n\nLogin here: ${loginLink}\n\nDetails:\nEmail: ${email}\nPassword: ${password}\nFirst Name: ${first_name}\nLast Name: ${last_name}`;

    const messageHtml = `
      <p>Hello <b>${first_name} ${last_name}</b>,</p>
      <p>You have been added as an <b>HR</b>.</p>
      <p><b>Login here:</b> <a href="${loginLink}" target="_blank">${loginLink}</a></p>
      <p><b>Your credentials:</b></p>
      <ul>
        <li><b>Email:</b> ${email}</li>
        <li><b>Password:</b> ${password}</li>
        <li><b>First Name:</b> ${first_name}</li>
        <li><b>Last Name:</b> ${last_name}</li>
      </ul>
    `;

    await sendMail(email, "You've been added as HR", messagePlain, messageHtml);

    return res
      .status(200)
      .json({
        message: "HR user created and email sent successfully.",
        hr: newHr,
      });
  } catch (error) {
    return res.status(500).json({ message: "Server error while adding HR." });
  }
};

// Update HR user by company
const updateHrUser = async (req, res) => {
  try {
    const profile_type = req.User.profile_type;
    const company_id = req.User._id;
    const { hrId } = req.params;
    const { first_name, last_name, email, gender } = req.body;

    if (profile_type !== "company") {
      return res
        .status(403)
        .json({ message: "Only company profiles can update HR users." });
    }

    const hrUser = await User.findOne({
      _id: hrId,
      company_id,
      profile_type: "hr",
    });
    if (!hrUser) {
      return res
        .status(404)
        .json({ message: "HR user not found for this company." });
    }

    // Check if email is being updated and is already taken
    if (email && email !== hrUser.email) {
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res
          .status(400)
          .json({ message: "User with this email already exists." });
      }
      hrUser.email = email;
    }
    if (first_name) hrUser.first_name = first_name;
    if (last_name) hrUser.last_name = last_name;
    if (gender) hrUser.gender = gender;

    await hrUser.save();
    return res
      .status(200)
      .json({ message: "HR user updated successfully.", hr: hrUser });
  } catch (error) {
    return res.status(500).json({ message: "Server error while updating HR." });
  }
};

const removeHrUser = async (req, res) => {
  try {
    const companyId = req.User._id;
    const profileType = req.User.profile_type;
    const { hrId } = req.params;

    if (profileType !== "company") {
      return res
        .status(403)
        .json({ message: "Only company profiles can remove HR users." });
    }

    const hrUser = await User.findOne({ _id: hrId, profile_type: "hr" });

    if (!hrUser) {
      return res.status(404).json({ message: "HR user not found." });
    }

    if (String(hrUser.company_id) !== String(companyId)) {
      return res
        .status(403)
        .json({ message: "You are not authorized to remove this HR user." });
    }

    await User.deleteOne({ _id: hrId });

    const messagePlain = `Hello ${hrUser.first_name},\n\nYou have been removed from the HR position in our software.`;
    const messageHtml = `
      <p>Hello <b>${hrUser.first_name}</b>,</p>
      <p>You have been <b>removed</b> from the HR position in our software.</p>
    `;

    await sendMail(
      hrUser.email,
      "HR Position Removed",
      messagePlain,
      messageHtml
    );

    res
      .status(200)
      .json({ message: "HR user removed successfully and email sent." });
  } catch (error) {
    console.error("Error removing HR:", error);
    res.status(500).json({ message: "Server error while removing HR." });
  }
};

const getHrList = async (req, res) => {
  try {
    const companyId = req.User._id;
    const { page = 1, search = "" } = req.query;
    const limit = 20;
    const skip = (page - 1) * limit;

    // Build base query
    const query = {
      profile_type: "hr",
      company_id: companyId,
    };

    // Add search filter if search keyword provided
    if (search && search.trim() !== "") {
      const searchRegex = new RegExp(search, "i");
      query.$or = [
        { first_name: searchRegex },
        { last_name: searchRegex },
        { email: searchRegex },
        // Add more fields to search as needed
      ];
    }

    const [hrList, total] = await Promise.all([
      User.find(query)
        .select("-password")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      User.countDocuments(query),
    ]);

    res.status(200).json({
      success: true,
      hrList,
      totalPages: Math.ceil(total / limit),
      currentPage: Number(page),
    });
  } catch (error) {
    console.error("Error fetching HR list:", error);
    res.status(500).json({ message: "Server error while fetching HR list." });
  }
};

const getSingleHr = async (req, res) => {
  try {
    const companyId = req.User._id;
    const { hrId } = req.params;

    const hrUser = await User.findOne({
      _id: hrId,
      profile_type: "hr",
      company_id: companyId,
    }).select("-password"); // exclude password

    if (!hrUser) {
      return res
        .status(404)
        .json({ message: "HR user not found or unauthorized access." });
    }

    res.status(200).json({ success: true, hrUser });
  } catch (error) {
    console.error("Error fetching HR:", error);
    res.status(500).json({ message: "Server error while fetching HR." });
  }
};

// const generateReport = async (req, res) => {
//   try {
//     const user = req.User;

//     // 1. Auto-detect company_id based on profile_type
//     let companyId;
//     if (user.profile_type === "company") {
//       companyId = user._id;
//     } else if (user.profile_type === "hr") {
//       companyId = user.company_id;
//     } else {
//       return res
//         .status(403)
//         .json({ error: "Access denied. Only HR or Company allowed." });
//     }

//     // 2. Get date range or default to current month
//     const start_date = req.body.start_date;
//     const end_date = req.body.end_date;

//     const startDate = start_date
//       ? new Date(start_date)
//       : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
//     const endDate = end_date ? new Date(end_date) : new Date();

//     // 3. Find Jobs posted by the company
//     const jobs = await Job.find({
//       company_id: companyId,
//       createdAt: { $gte: startDate, $lte: endDate },
//     }).select("_id");

//     const jobIds = jobs.map((job) => job._id);
//     const totalJobs = jobs.length;

//     // 4. Find Applications within date range
//     const applications = await Application.find({
//       company_id: companyId,
//       applied_at: { $gte: startDate, $lte: endDate },
//     });

//     const totalApplications = applications.length;

//     const statusCounts = {
//       pending: 0,
//       shortlisted: 0,
//       rejected: 0,
//       hired: 0,
//     };

//     applications.forEach((app) => {
//       if (statusCounts[app.status] !== undefined) {
//         statusCounts[app.status]++;
//       }
//     });

//     // 5. Response
//     return res.status(200).json({
//       company_id: companyId,
//       date_range: {
//         from: startDate,
//         to: endDate,
//       },
//       jobs_posted: totalJobs,
//       applications_received: totalApplications,
//       application_statuses: statusCounts,
//     });
//   } catch (err) {
//     console.error("Company report error:", err);
//     res.status(500).json({ error: "Internal server error" });
//   }
// };


// Helper function to generate weekly chart data
const generateWeeklyChartData = async (data, startDate, endDate, type) => {
  // Calculate number of weeks between startDate and endDate
  const msPerWeek = 7 * 24 * 60 * 60 * 1000;
  const weeks = Math.ceil((endDate - startDate) / msPerWeek);
  const chartData = [];
  
  for (let i = 0; i < weeks; i++) {
    const weekStart = new Date(startDate);
    weekStart.setDate(startDate.getDate() + (i * 7));
    
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);
    
    if (weekEnd > endDate) {
      weekEnd.setTime(endDate.getTime());
    }
    
    const weekData = { name: `Week ${i + 1}` };
    
    if (type === 'job') {
      // Jobs data
      const weeklyJobs = data.filter(job => {
        const jobDate = new Date(job.createdAt);
        return jobDate >= weekStart && jobDate <= weekEnd;
      });
      
      weekData.Jobs = weeklyJobs.length;
    } else if (type === 'application') {
      // Application data
      const weeklyApps = data.filter(app => {
        const appDate = new Date(app.applied_at);
        return appDate >= weekStart && appDate <= weekEnd;
      });
      
      weekData.Total = weeklyApps.length;
      weekData.Shortlisted = weeklyApps.filter(app => app.status === 'shortlisted').length;
      weekData.Rejected = weeklyApps.filter(app => app.status === 'rejected').length;
    }
    
    chartData.push(weekData);
  }
  
  return chartData;
};

const generateReport = async (req, res) => {
  try {
    const user = req.User;
    
    // 1. Auto-detect company_id based on profile_type
    let companyId;
    if (user.profile_type === "company") {
      companyId = user._id;
    } else if (user.profile_type === "hr") {
      companyId = user.company_id;
    } else {
      return res
        .status(403)
        .json({ error: "Access denied. Only HR or Company allowed." });
    }
    
   // Helper to parse DD/MM/YYYY format
    const parseDate = (str) => {
      if (!str) return null;
      const [day, month, year] = str.split('/');
      const date = new Date(`${year}-${month}-${day}`);
      return isNaN(date.getTime()) ? null : date;
    };

    // 2. Get date range or default to current month
    const startDate = parseDate(req.body.start_date) || new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const endDate = parseDate(req.body.end_date) || new Date();

    // 3. Find Jobs posted by the company
    const jobs = await Job.find({
      company_id: companyId,
      createdAt: { $gte: startDate, $lte: endDate },
    });
    const jobIds = jobs.map((job) => job._id);
    const totalJobs = jobs.length;


    
    // 4. Find Applications within date range
    const applications = await Application.find({
      company_id: companyId,
      applied_at: { $gte: startDate, $lte: endDate },
    }).populate('job_id candidate_id');
    
    const totalApplications = applications.length;
    
    // 5. Calculate application status counts
    const statusCounts = {
      pending: 0,
      interview: 0,
      shortlisted: 0,
      rejected: 0,
      hired: 0,
    };
    
    applications.forEach((app) => {
      if (statusCounts[app.status] !== undefined) {
        statusCounts[app.status]++;
      }
    });
    
    // 6. Get HR count for the company
    const totalHRs = await User.find({
       company_id: companyId,
      profile_type: "hr"
    }).countDocuments();
    // 7. Generate weekly job chart data
    const jobChartData = await generateWeeklyChartData(jobs, startDate, endDate, 'job');
    
    // 8. Generate weekly application chart data
    const applicationChartData = await generateWeeklyChartData(applications, startDate, endDate, 'application');
    
    // 9. Get recent jobs (last 5) - fetch directly from DB
    const recentJobsRaw = await Job.find({
      company_id: companyId,
      createdAt: { $gte: startDate, $lte: endDate }
    })
      .sort({ createdAt: -1 })
      .limit(5)
      .select('title job_type start_date end_date');

    const recentJobs = recentJobsRaw.map(job => ({
      title: job.title,
      job_type: job.job_type,
      start_date: job.start_date,
      end_date: job.end_date
    }));

    // 10. Get recent applications (last 5) - fetch directly from DB
    const recentApplicationsRaw = await Application.find({
      company_id: companyId,
      applied_at: { $gte: startDate, $lte: endDate }
    })
      .sort({ applied_at: -1 })
      .limit(5)
      .populate('job_id candidate_id');

    const recentApplications = recentApplicationsRaw.map(app => ({
      name: app.full_name || 'N/A',
      job_id: app.job_id && app.job_id._id ? {
        id: app.job_id._id,
        title: app.job_id.title || 'N/A'
      } : {
        id: null,
        title: 'N/A'
      },
      email: app.email || 'N/A',
      phone: app.phone || 'N/A'
    }));
    
    // 11. Get HR list
    const hrList = await User.find({
      company_id: companyId,
      profile_type: "hr"
    })
    .sort({ createdAt: -1 })
    .limit(5)
    .select('first_name last_name email createdAt')
    .lean();
    
    const formattedHrList = hrList.map(hr => ({
      name: `${hr.first_name} ${hr.last_name}`,
      email: hr.email,
      createdAt: hr.createdAt.toISOString().split('T')[0]
    }));
    
    // 12. Get pending interviews
    const pendingInterviews = applications
  .filter(app => app.status === 'interview')
  .slice(0, 5)
  .map(app => ({
    id: app._id?.toString(),
    full_name: app.full_name || 'N/A',
    email: app.email || 'N/A',
    phone: app.phone || 'N/A',
    job_id: app.job_id && app.job_id._id ? {
      id: app.job_id._id,
      title: app.job_id.title || 'N/A'
    } : {
      id: null,
      title: 'N/A'
    },
    status: app.status || 'N/A'
  }));

    
    // 13. Response
    return res.status(200).json({
      company_id: companyId,
      date_range: {
        from: startDate,
        to: endDate,
      },
      totalApplications,
      totalShortlisted: statusCounts.shortlisted,
      totalPostedJobs: totalJobs,
      totalHRs,
      jobChartData,
      applicationChartData,
      recentJobs,
      recentApplications,
      hrList: formattedHrList,
      pendingInterviews,
      application_statuses: statusCounts,
    });
  } catch (err) {
    console.error("Company report error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};




const updateApplicationStatus = async (req, res) => {
  try {
    const { status, application_id } = req.body;

    if (!status || !application_id) {
      return res
        .status(400)
        .json({ message: "Status and application_id are required." });
    }

    let company_id;
    if (req.User.profile_type === "hr") {
      company_id = req.User.company_id;
    } else if (req.User.profile_type === "company") {
      company_id = req.User._id;
    } else {
      return res.status(403).json({ message: "Unauthorized profile type." });
    }

    // Update the application status
    const updatedApplication = await Application.findOneAndUpdate(
      { _id: application_id, company_id },
      { status },
      { new: true }
    ).select("-resume_desc");

    if (!updatedApplication) {
      return res
        .status(404)
        .json({ message: "Application not found or access denied." });
    }

    res.status(200).json({
      message: "Status updated successfully.",
      application: updatedApplication,
    });
  } catch (error) {
    console.error("Update Error:", error);
    res.status(500).json({ message: "Internal server error." });
  }
};

module.exports = {
  createJob,
  getJobs,
  getSingleJob,
  getJobApplications,
  updateJob,
  deleteJob,
  getApplications,
  getSingleApplication,
  deleteApplication,
  scanApplication,
  addHrUser,
  removeHrUser,
  getHrList,
  getSingleHr,
  generateReport,
  updateApplicationStatus,
  updateHrUser,
};
