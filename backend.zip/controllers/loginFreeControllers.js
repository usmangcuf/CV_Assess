const { Job } = require("../models/Model");
const fs = require("fs");
const pdfParse = require("pdf-parse");


const getAllJobs = async (req, res) => {
  try {
    const {
      title,
      job_type,
      min_salary,
      max_salary,
      education,
      address,
      level,
      start_date,
      end_date,
      pay_type,
      job_location,
      keyword,
      page = 1,
    } = req.query;
console.log(req.query);
    const filter = {};
    // Helper to create a robust regex from query (handles underscores, hyphens, spaces)
    const buildFlexibleRegex = (value) => {
      if (!value) return undefined;
      // Replace _, -, and spaces with a pattern that matches any separator
      const pattern = value
        .toLowerCase()
        .replace(/[\s_-]+/g, '[\\s_-]?') // flexible separator
        .split(/\s+/)
        .filter(Boolean)
        .join('|');
      return new RegExp(pattern, 'i');
    };

    if (title) filter.title = { $regex: buildFlexibleRegex(title) };
    if (job_type) filter.job_type = { $regex: buildFlexibleRegex(job_type) };
    if (min_salary) filter.min_salary = { $gte: min_salary };
    if (max_salary) filter.max_salary = { $lte: max_salary };
    if (education) filter.education = { $regex: buildFlexibleRegex(education) };
    if (address) filter.address = { $regex: buildFlexibleRegex(address) };
    if (level) filter.level = level;
    if (start_date) filter.start_date = { $gte: start_date };
    if (end_date) filter.end_date = { $lte: end_date };
    if (pay_type) filter.pay_type = { $regex: buildFlexibleRegex(pay_type) };
    if (job_location)
      filter.job_location = { $regex: buildFlexibleRegex(job_location) };
    if (keyword) filter.$or = [{ title: { $regex: buildFlexibleRegex(keyword) } }, { description: { $regex: buildFlexibleRegex(keyword) } }, { key_responsibilities: { $regex: buildFlexibleRegex(keyword) } }, { skills: { $regex: buildFlexibleRegex(keyword) } }];

    const limit = 20;
    const skip = (page - 1) * limit;

    const jobs = await Job.find(filter)
      .populate({
        path: "company_id",
        select: "_id image_url first_name last_name company",
      })
      .skip(skip)
      .limit(limit);
    const totalJobs = await Job.countDocuments(filter);

    res.status(200).json({
      success: true,
      jobs,
      totalPages: Math.ceil(totalJobs / limit),
      totalJobs,
      currentPage: page,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const fileUploader = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const pdfBuffer = fs.readFileSync(req.file.path);
    const data = await pdfParse(pdfBuffer);

    res.json({ text: data.text });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getSimilarJobs = async (req, res) => {
  try {
    const {
      title,
      job_type,
      min_salary,
      max_salary,
      education,
      address,
      level,
      start_date,
      end_date,
      pay_type,
      job_location,
      page = 1,
    } = req.query;
    const {company_id} = req.body;

    const filter = {company_id};
    if (title) filter.title = { $regex: title, $options: "i" };
    if (job_type) filter.job_type = job_type;
    if (min_salary) filter.min_salary = { $gte: min_salary };
    if (max_salary) filter.max_salary = { $lte: max_salary };
    if (education) filter.education = { $regex: education, $options: "i" };
    if (address) filter.address = { $regex: address, $options: "i" };
    if (level) filter.level = level;
    if (start_date) filter.start_date = { $gte: start_date };
    if (end_date) filter.end_date = { $lte: end_date };
    if (pay_type) filter.pay_type = { $regex: pay_type, $options: "i" };
    if (job_location)
      filter.job_location = { $regex: job_location, $options: "i" };

    const limit = 20;
    const skip = (page - 1) * limit;

    const jobs = await Job.find(filter)
      .populate({
        path: "company_id",
        select: "_id image_url first_name last_name company",
      })
      .skip(skip)
      .limit(limit);
    const totalJobs = await Job.countDocuments(filter);

    res.status(200).json({
      success: true,
      jobs,
      totalPages: Math.ceil(totalJobs / limit),
      totalJobs,
      currentPage: page,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

module.exports = { getAllJobs, fileUploader, getSimilarJobs };
