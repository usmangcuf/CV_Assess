const {
  CompanyContactInformation,
  CompanyPersonalInformation,
} = require("../models/CompanyProfileModels");
const axios = require("axios");
const FormData = require("form-data");
const { User } = require("../models/Model");

const uploadToImgBB = async (base64String) => {
  const form = new FormData();
  form.append("key", "e31a43ea5d3cdef8a8fde4c33f2750fd");
  form.append("image", base64String);

  const res = await axios.post("https://api.imgbb.com/1/upload", form, {
    headers: form.getHeaders(),
  });

  return res.data.data.url;
};


const updateCompanyProfile = async (req, res) => {
  try {
    if(req.User.profile_type !== "company"){
      return res.status(401).json({ message: "only company can update company profile" });
    }
    const userId = req.User._id;

    let {
      personalInfo,
      contactInfo,
    } = req.body;

    let user = await User.findById(userId);
    let imageUrl = null;
    if (personalInfo?.image_url) {
      const isBlob = personalInfo.image_url.startsWith("blob:");
      if (isBlob) {
        return res
          .status(400)
          .json({ message: "Invalid image format. Please convert to base64." });
      }

      const isBase64 = personalInfo.image_url.startsWith("data:image");
      if (isBase64) {
        const base64Data = personalInfo.image_url.split(",")[1];
        imageUrl = await uploadToImgBB(base64Data);
        personalInfo.image_url = imageUrl;
      } else {
        imageUrl = personalInfo.image_url;
      }
    }


    const personalInformation = await CompanyPersonalInformation.findOneAndUpdate(
      { user: userId },
      { ...personalInfo, user: userId },
      { new: true }
    );

    if (imageUrl) {
      user = await User.findOneAndUpdate(
        { _id: userId },
        { image_url: imageUrl },
        { new: true }
      );
    }

    const contactInformation = await CompanyContactInformation.findOneAndUpdate(
      { user: userId },
      { ...contactInfo, user: userId },
      { new: true }
    );


    res.status(200).json({
      message: "Profile updated successfully",
      profile: {
        personalInformation,
        contactInformation,
        ...(user && { user }),
      },
    });
  } catch (error) {
    console.error("Update Profile Error:", error);
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};


const getCompanyProfile = async (req, res) => {
  try {
    const userId = req.User._id;

    const personalInfo = await CompanyPersonalInformation.findOne({ user: userId });
    const contactInfo = await CompanyContactInformation.findOne({ user: userId });

    res.status(200).json({
      message: "Profile fetched successfully",
      personalInfo,
      contactInfo,
    });
  } catch (error) {
    console.error("Get Profile Error:", error);
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};



module.exports = {
  updateCompanyProfile,
  getCompanyProfile,
};

