const { User } = require("../models/Model");
const bcrypt = require("bcryptjs");
const { hashPassword, comparePassword } = require("../utilis/passwordHash");
const jwt = require("jsonwebtoken");
const { sendMail } = require("../utilis/customMail");
const {
  PersonalInformation,
  Education,
  Certification,
  ContactInformation,
  WorkHistory,
} = require("../models/CandidateProfileModels");
const { CompanyPersonalInformation, CompanyContactInformation } = require("../models/CompanyProfileModels");

const signUp = async (req, res) => {
  const {
    first_name,
    last_name,
    email,
    password,
    profile_type,
    company,
    gender,
  } = req.body;

  const missingFields = [];
  if (!first_name) missingFields.push("first_name");
  if (!last_name) missingFields.push("last_name");
  if (!email) missingFields.push("email");
  if (!password) missingFields.push("password");
  if (!profile_type) missingFields.push("profile_type");

  if (missingFields.length > 0) {
    return res.status(400).json({
      message: `The following fields are required: ${missingFields.join(", ")}`,
    });
  }

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already exists" });
    }

    const hashedPassword = await hashPassword(password);

    const newUser = new User({
      first_name,
      last_name,
      email,
      password: hashedPassword,
      profile_type,
      company,
      gender,
    });

    await newUser.save();

    const userResponse = {
      first_name: newUser.first_name,
      last_name: newUser.last_name,
      email: newUser.email,
      profile_type: newUser.profile_type,
      createdAt: newUser.createdAt,
    };

    const token = jwt.sign(
      {
        id: newUser._id,
        email: newUser.email,
        profile_type: newUser.profile_type,
      },
      process.env.JWT_SECRET,
      { expiresIn: "30d" }
    );

    return res.status(201).json({
      message: "Account successfully created",
      user: userResponse,
      token,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "Invalid User" });
    }

    const isMatch = await comparePassword(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid password" });
    }

    const token = jwt.sign(
      { id: user._id, email: user.email, profile_type: user.profile_type },
      process.env.JWT_SECRET,
      { expiresIn: "30d" }
    );

    if (user.profile_type === "user") {
      const userId = user._id;

      const ensureOne = async (Model, data = {}) => {
        const exists = await Model.findOne({ user: userId });
        if (!exists) await new Model({ user: userId, ...data }).save();
      };

      await ensureOne(PersonalInformation, {
        full_name: `${user.first_name} ${user.last_name}`,
        email: user.email,
      });

      await ensureOne(ContactInformation);
    }

    if (user.profile_type === "company" || user.profile_type === "hr") {
      const userId = user._id;

      const ensureOne = async (Model, data = {}) => {
        const exists = await Model.findOne({ user: userId });
        if (!exists) await new Model({ user: userId, ...data }).save();
      };

      await ensureOne(CompanyPersonalInformation, {
        full_name: `${user.first_name} ${user.last_name}`,
        email: user.email,
      });

      await ensureOne(CompanyContactInformation);
    }
    const personalInfo = user.profile_type === "user" ? await PersonalInformation.findOne({ user: user._id }) : user.profile_type === "company" ? await CompanyPersonalInformation.findOne({ user: user._id }) : await CompanyPersonalInformation.findOne({ user: user._id });
    const userResponse = {
      first_name: user.first_name,
      last_name: user.last_name,
      email: user.email,
      profile_type: user.profile_type,
      company: user.company,
      gender: user.gender,
      personalInfo,
    };
    return res.status(200).json({
      message: "Login successful",
      token,
      user: userResponse,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: "Invalid email" });
    }

    const resetLink = `https://ai-portal-six.vercel.app/reset-password?email=${email}`;
    const messagePlain = `Hello, reset your password here: ${resetLink}`;
    const messageHtml = `<p>Hello <b>${email}</b>, reset your password <a href="${resetLink}" target="_blank">here</a></p>`;

    const result = await sendMail(
      email,
      "Reset Your Password",
      messagePlain,
      messageHtml
    );

    return res.status(200).json({
      message: "Reset link sent to your email",
      previewUrl: result.previewUrl,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
};

const resetPassword = async (req, res) => {
  try {
    const { email, newPassword, confirmPassword } = req.body;
    if ((!email, !newPassword, !confirmPassword)) {
      return res
        .status(400)
        .json({ message: "Email, New Password, Confirm Password is required" });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: "Invalid email" });
    }

    if (newPassword === confirmPassword) {
      const hashedPassword = await hashPassword(newPassword);
      await User.findOneAndUpdate(
        {
          email,
        },
        {
          password: hashedPassword,
        }
      );
      return res.status(200).json({
        message: "Your Password Has been update",
        redirect_link: "/login",
      });
    } else {
      return res.status(400).json({
        message: "New Password and Confirm Password must be same",
      });
    }
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
};

const verifyCode = (req, res) => {};

const changePassword = async (req, res) => {
  try {
    const userId = req.User._id;
    const { oldPassword, newPassword, confirmPassword } = req.body;

    if (newPassword !== confirmPassword) {
      return res
        .status(400)
        .json({ message: "New password and confirm password do not match." });
    }

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found." });

    const isMatch = await comparePassword(oldPassword, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Old password is incorrect." });
    }

    const hashed = await hashPassword(newPassword);
    user.password = hashed;
    await user.save();

    res.status(200).json({ message: "Password changed successfully." });
  } catch (error) {
    console.error("Change password error:", error);
    res.status(500).json({ message: "Server error." });
  }
};

module.exports = {
  signUp,
  login,
  forgotPassword,
  resetPassword,
  changePassword,
};
