const { Job, Application, MyJob, SavedJob } = require("../models/Model");
const fs = require("fs");
const pdfParse = require("pdf-parse");

const getAllJobs = async (req, res) => {
  try {
    const {
      title,
      job_type,
      min_salary,
      max_salary,
      education,
      address,
      level,
      keyword,
      page = 1,
    } = req.query;
    console.log(req.query);
    const filter = {};
    // Helper to create a robust regex from query (handles underscores, hyphens, spaces)
    const buildFlexibleRegex = (value) => {
      if (!value) return undefined;
      // Replace _, -, and spaces with a pattern that matches any separator
      const pattern = value
        .toLowerCase()
        .replace(/[\s_-]+/g, '[\\s_-]?') // flexible separator
        .split(/\s+/)
        .filter(Boolean)
        .join('|');
      return new RegExp(pattern, 'i');
    };

    if (title) filter.title = { $regex: buildFlexibleRegex(title) };
    if (job_type) filter.job_type = { $regex: buildFlexibleRegex(job_type) };
    if (min_salary) filter.min_salary = { $gte: min_salary };
    if (max_salary) filter.max_salary = { $lte: max_salary };
    if (education) filter.education = { $regex: buildFlexibleRegex(education) };
    if (address) filter.address = { $regex: buildFlexibleRegex(address) };
    if (level) filter.level = { $regex: buildFlexibleRegex(level) };
    if (keyword) filter.$or = [{ title: { $regex: buildFlexibleRegex(keyword) } }, { description: { $regex: buildFlexibleRegex(keyword) } }, { key_responsibilities: { $regex: buildFlexibleRegex(keyword) } }, { skills: { $regex: buildFlexibleRegex(keyword) } }];

    const limit = 20;
    const skip = (page - 1) * limit;

    const jobs = await Job.find(filter)
      .populate({
        path: "company_id",
        select: "_id image_url first_name last_name company",
      })
      .skip(skip)
      .limit(limit);
    const totalJobs = await Job.countDocuments(filter);

    res.status(200).json({
      success: true,
      jobs,
      totalPages: Math.ceil(totalJobs / limit),
      totalJobs,
      currentPage: page,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const fileUploader = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const pdfBuffer = fs.readFileSync(req.file.path);
    const data = await pdfParse(pdfBuffer);

    res.json({ text: data.text });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const applyJob = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No resume uploaded" });
    }

    // const pdfBuffer = fs.readFileSync(req.file.path);
    // const data = await pdfParse(pdfBuffer);

    const pdfBuffer = req.file.buffer;
    const data = await pdfParse(pdfBuffer);

    const { job_id, company_id, resume_url, name, email, phone } = req.body;

    if (!job_id || !company_id || !name || !email || !phone) {
      return res.status(400).json({
        error: "job_id, company_id, name, email, and phone are required",
      });
    }

    // Check if user already applied to this job
    const alreadyApplied = await Application.findOne({
      candidate_id: req.User._id,
      job_id
    });
    if (alreadyApplied) {
      return res.status(400).json({ error: "You have already apply to this job" });
    }

    const application = new Application({
      candidate_id: req.User._id,
      job_id,
      company_id,
      full_name: name,
      email,
      phone,
      resume_url,
      resume_desc: data.text,
    });

    await application.save();

    const existingJob = await MyJob.findOne({
      candidate: req.User._id,
      job: job_id,
    });

    if (existingJob) {
      existingJob.isApplied = true;
      existingJob.company = company_id;
      await existingJob.save();
    } else {
      const newMyJob = new MyJob({
        candidate: req.User._id,
        job: job_id,
        company: company_id,
        isApplied: true,
        isSaved: false,
      });
      await newMyJob.save();
    }

    res.status(201).json({ message: "Application created successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getMyJobs = async (req, res) => {
  try {
    const { page = 1 } = req.query;
    const candidateId = req.User._id;

    const filter = { candidate: candidateId };

    const limit = 20;
    const skip = (page - 1) * limit;

    const myJobs = await MyJob.find(filter)
      .populate({
        path: "job",
        populate: {
          path: "company_id",
          select: "_id image_url first_name last_name company",
        },
      })
      .skip(skip)
      .limit(limit);

    const totalJobs = await MyJob.countDocuments(filter);

    const jobs = myJobs
      .filter((item) => item.job !== null)
      .map((item) => ({
        ...item.job.toObject(),
        isSaved: item.isSaved,
        isApplied: item.isApplied,
      }));

    res.status(200).json({
      success: true,
      jobs,
      totalPages: Math.ceil(totalJobs / limit),
      totalJobs,
      currentPage: parseInt(page),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const toggleSaveJob = async (req, res) => {
  try {
    const { job_id, company_id, action } = req.body;

    if (!job_id || !company_id || !["save", "unsave"].includes(action)) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid request" });
    }

    const candidateId = req.User._id;
    const isSaved = action === "save";

    const existingJob = await MyJob.findOne({
      candidate: candidateId,
      job: job_id,
    });

    if (existingJob) {
      // Check if already in the same state
      if (existingJob.isSaved === isSaved) {
        return res.status(400).json({
          success: false,
          message: `Job already ${isSaved ? "saved" : "unsaved"}`,
        });
      }

      // Otherwise, update the state
      existingJob.isSaved = isSaved;
      existingJob.company = company_id;
      await existingJob.save();
    } else {
      const newMyJob = new MyJob({
        candidate: candidateId,
        job: job_id,
        company: company_id,
        isSaved,
        isApplied: false,
      });
      await newMyJob.save();
    }

    res
      .status(200)
      .json({ success: true, message: `Job ${action}d successfully` });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

module.exports = {
  getAllJobs,
  fileUploader,
  applyJob,
  getMyJobs,
  toggleSaveJob,
};
