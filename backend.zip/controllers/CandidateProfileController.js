const {
  PersonalInformation,
  Education,
  Certification,
  ContactInformation,
  WorkHistory,
} = require("../models/CandidateProfileModels");
const axios = require("axios");
const FormData = require("form-data");
const { User, Application, Job } = require("../models/Model");

const uploadToImgBB = async (base64String) => {
  const form = new FormData();
  form.append("key", "e31a43ea5d3cdef8a8fde4c33f2750fd");
  form.append("image", base64String);

  const res = await axios.post("https://api.imgbb.com/1/upload", form, {
    headers: form.getHeaders(),
  });

  return res.data.data.url;
};


const updateProfile = async (req, res) => {
  try {
    const userId = req.User._id;

    // Destructure and parse incoming form data
    let {
      personalInfo,
      educationList = [],
      certifications = [],
      contactInfo,
      workHistory = [],
    } = req.body;

    let user = await User.findById(userId);
    let imageUrl = null;
    if (personalInfo?.image_url) {
      const isBlob = personalInfo.image_url.startsWith("blob:");
      if (isBlob) {
        return res
          .status(400)
          .json({ message: "Invalid image format. Please convert to base64." });
      }

      const isBase64 = personalInfo.image_url.startsWith("data:image");
      if (isBase64) {
        // Extract base64 string
        const base64Data = personalInfo.image_url.split(",")[1];
        imageUrl = await uploadToImgBB(base64Data);
        personalInfo.image_url = imageUrl;
      } else {
        // Use existing URL (e.g., already hosted)
        imageUrl = personalInfo.image_url;
      }
    }


    // Update personal info
    const personalInformation = await PersonalInformation.findOneAndUpdate(
      { user: userId },
      { ...personalInfo, user: userId },
      { new: true }
    );

    // Update user image if changed
    if (imageUrl) {
      user = await User.findOneAndUpdate(
        { _id: userId },
        { image_url: imageUrl },
        { new: true }
      );
    }

    // Update contact info
    const contactInformation = await ContactInformation.findOneAndUpdate(
      { user: userId },
      { ...contactInfo, user: userId },
      { new: true }
    );

    // Replace education, work history, and certifications
    await Education.deleteMany({ user: userId });
    const savedEducation = educationList.length
      ? await Education.insertMany(educationList.map((edu) => ({ ...edu, user: userId })))
      : [];

    await WorkHistory.deleteMany({ user: userId });
    const savedWorkHistory = workHistory.length
      ? await WorkHistory.insertMany(workHistory.map((work) => ({ ...work, user: userId })))
      : [];

    await Certification.deleteMany({ user: userId });
    const savedCerts = certifications.length
      ? await Certification.insertMany(certifications.map((cert) => ({
          institute: cert.institute,
          title: cert.title,
          doc_url: cert.doc_url,
          description: cert.description,
          user: userId,
        })))
      : [];

    res.status(200).json({
      message: "Profile updated successfully",
      profile: {
        personalInformation,
        contactInformation,
        education: savedEducation,
        certifications: savedCerts,
        workHistory: savedWorkHistory,
        ...(user && { user }),
      },
    });
  } catch (error) {
    console.error("Update Profile Error:", error);
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};


const getProfile = async (req, res) => {
  try {
    const userId = req.User._id;

    const personalInfo = await PersonalInformation.findOne({ user: userId });
    const contactInfo = await ContactInformation.findOne({ user: userId });
    const educationList = await Education.find({ user: userId });
    const certifications = await Certification.find({ user: userId });
    const workHistory = await WorkHistory.find({ user: userId });

    res.status(200).json({
      message: "Profile fetched successfully",
      personalInfo,
      contactInfo,
      educationList,
      certifications,
      workHistory,
    });
  } catch (error) {
    console.error("Get Profile Error:", error);
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};


const getCandidateReport = async (req, res) => {
  try {
    const candidateId = req.User._id;
    const now = new Date();
    const lastMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const intervals = [
      { start: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000), end: new Date(now.getTime() - 20 * 24 * 60 * 60 * 1000) },
      { start: new Date(now.getTime() - 20 * 24 * 60 * 60 * 1000), end: new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000) },
      { start: new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000), end: now },
    ];
    intervals.forEach(interval => {
      interval.name = `${interval.start.toLocaleDateString()} - ${interval.end.toLocaleDateString()}`;
    });

    const applications = await Application.find({
      candidate_id: candidateId,
      applied_at: { $gte: lastMonth, $lte: now },
    }).populate({ path: "job_id", select: "title company_id location" });

    const chartData = intervals.map((interval) => {
      const appsInInterval = applications.filter(
        (a) => a.applied_at >= interval.start && a.applied_at < interval.end
      );
      return {
        name: interval.name,
        Applied: appsInInterval.length,
        Interviewed: appsInInterval.filter((a) => ["shortlisted", "hired"].includes(a.status)).length,
        Rejected: appsInInterval.filter((a) => a.status === "rejected").length,
      };
    });

    const totalStats = {
      totalApplied: applications.length,
      totalInterviewed: applications.filter((a) => ["shortlisted", "hired"].includes(a.status)).length,
      totalRejected: applications.filter((a) => a.status === "rejected").length,
    };

    const companyIds = [...new Set(applications.map((a) => a.company_id.toString()))];
    const companies = await User.find({ _id: { $in: companyIds } }).select("-password");

    const personal = await PersonalInformation.findOne({ user: candidateId });
    const contact = await ContactInformation.findOne({ user: candidateId });
    const workExperience = await WorkHistory.find({ user: candidateId });
    const certifications = await Certification.find({ user: candidateId });
    const education = await Education.find({ user: candidateId });

    let completion = 0;
    if (personal) completion += 20;
    if (contact) completion += 20;
    if (workExperience && workExperience.length > 0) completion += 20;
    if (certifications && certifications.length > 0) completion += 20;
    if (education && education.length > 0) completion += 20;
    const profileCompletion = completion;

    let basicCandidateInfo = {
      name: personal?.full_name || req.User.first_name + " " + req.User.last_name,
      email: personal?.email || req.User.email,
      profileImage: personal?.image_url || req.User.image_url,
      role: req.User.profile_type,
    };

    // Get up to 5 random jobs for recommendations
    let recommendedJobs = [];
    const totalJobs = await Job.countDocuments();
    let randomSkip = 0;
    if (totalJobs > 5) {
      randomSkip = Math.floor(Math.random() * (totalJobs - 5));
    }
    recommendedJobs = await Job.find().skip(randomSkip).limit(5).populate({ path: "company_id", select: "company first_name last_name image_url" });


    res.status(200).json({
      chartData,
      totalStats,
      companies,
      recommendedJobs,
      profileCompletion,
      basicCandidateInfo,
    });
  } catch (error) {
    console.error("Candidate Report Error:", error);
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};

module.exports = {
  updateProfile,
  getProfile,
  getCandidateReport,
};

// {
//   "personalInfo": {
//     "full_name": "John Doe",
//     "email": "john@example.com",
//     "image_url": "http://...",
//     "date_of_birth": "1995-01-01",
//     "gender": "Male",
//     "address": "New York",
//     "pay_rate": {
//       "period": "hourly",
//       "currency": "USD",
//       "amount": 50
//     },
//     "language": "English",
//     "about": "Software Developer",
//     "resume_url": "http://..."
//   },
//   "educationList": [
//     {
//       "institute": "ABC University",
//       "degree": "BS",
//       "field_of_study": "Computer Science",
//       "start_date": "2015-01-01",
//       "end_date": "2019-01-01",
//       "is_present": false,
//       "description": "Graduated with honors"
//     }
//   ],
//   "certifications": [
//     {
//       "institute": "Coursera",
//       "title": "React Developer",
//       "doc_url": "http://...",
//       "description": "Advanced React course"
//     }
//   ],
//   "contactInfo": {
//     "phone_num": "+123456789",
//     "phone_num_optional": "",
//     "email": "john@example.com",
//     "email_optional": "",
//     "portfolio_url": "http://portfolio.com",
//     "website_url": "http://website.com",
//     "social_media_urls": [
//       { "platform": "LinkedIn", "link": "https://linkedin.com/in/johndoe" },
//       { "platform": "GitHub", "link": "https://github.com/johndoe" }
//     ]
//   }
// }
